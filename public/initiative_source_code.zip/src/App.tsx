import React, { useState, useEffect, useRef } from 'react';
import {
  UNIT1_LESSONS,
  U,
  COMMON_MISTAKES_GUIDES,
  REMEDIAL_COMMON_QS,
  DAILY_CHALLENGE_PROGRESSION,
  DailyChallengeItem,
  QuestionItem
} from './data';
import { UNIT2_LESSONS, UNIT3_LESSONS } from './unitsData';
import { NAFES_STAGES, NafesStageExam } from './nafesBank';
import { SPLASH_SVG } from './splashImage';
import { CoverSplash } from './coverSplash';
import { fireCelebratoryFireworks } from './confetti';
import {
  db,
  auth,
  googleProvider,
  ADMIN_EMAIL,
  OperationType,
  handleFirestoreError,
  toSafeDocId,
  doc,
  collection,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  limit,
  signInWithPopup,
  signOut
} from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';

const OPTION_LABELS = ['أ-', 'ب-', 'ج-', 'د-', 'هـ-', 'و-'];

interface LastActivity {
  kind: 'unit' | 'nafes' | 'lesson' | 'remedial';
  n?: number;
  label: string;
}

interface FeedbackItem {
  id?: string;
  role: string;
  cls?: string;
  text: string;
  status: string;
  createdAt?: number;
}

interface MistakeRecord {
  question: QuestionItem;
  wrongChoiceIndex: number;
  sourceTitle: string;
  timestamp: string;
}

interface DailyChallengeState {
  currentIndex: number;
  nextUnlockMs: number;
  solvedDays: Record<number, { timeSpentSec: number; attempts: number; solvedAtMs: number }>;
}

interface StudentProfile {
  name: string;
  code: string;
  cls: string;
  points: number;
  badges: string[];
  correct: number;
  attempts: number;
  progress: number;
  completed: string[];
  lastActivity: LastActivity | null;
  seenQuestions?: Record<string, number[]>;
  feedback?: FeedbackItem[];
  mistakes?: MistakeRecord[];
  resolvedMistakesCount?: number;
  nafesStageIndex?: number;
  completedNafesStages?: string[];
  lastQuizTitle?: string;
  lastQuizScore?: number;
  lastQuizTotal?: number;
  isBlocked?: boolean;
  dailyChallenge?: DailyChallengeState;
}

interface CloudStudentRow {
  docId: string;
  profileId: string;
  name: string;
  code: string;
  cls: string;
  points: number;
  badges: string[];
  correct: number;
  attempts: number;
  progress: number;
  completed: string[];
  nafesStageIndex: number;
  dailyCurrentIndex: number;
  dailyNextUnlockMs: number;
  lastQuizTitle: string;
  lastQuizScore: number;
  lastQuizTotal: number;
  isBlocked: boolean;
  updatedAt: number;
}

interface AppSettings {
  announcement: string;
  enforce24hChallengeLock: boolean;
  enableGames: boolean;
  enableNafes: boolean;
  enableFeedback: boolean;
  adminPin: string;
  updatedAt: number;
}

interface QuizState {
  title: string;
  qs: QuestionItem[];
  type: string;
  isLesson: boolean;
  isRemedial?: boolean;
  hasPassage?: boolean;
  passageData?: {
    title: string;
    genre: string;
    paragraphs: string[];
  };
  nafesStageId?: string;
  nafesStageIdx?: number;
}

const DETECTIVE_QS: { prompt: string; options: string[]; answer: number; explain: string }[] = [
  {
    prompt: 'اختر الجملة الصحيحة إملائيًا:',
    options: ['هذا كتابٌ مفيدٌ.', 'هاذا كتابٌ مفيدٌ.', 'هاذا كتآبٌ مفيدٌ.'],
    answer: 0,
    explain: 'اسم الإشارة «هذا» فيه ألف تُنطق ولا تُكتب.'
  },
  {
    prompt: 'اختر الكلمة التي تمثل (جمع تكسير):',
    options: ['معلمون', 'كتب', 'طالبات'],
    answer: 1,
    explain: '«كتب» جمع تكسير لتغير صورة مفرده «كتاب».'
  },
  {
    prompt: 'اختر الجملة التي تمثل (أسلوب استفهام) صحيح:',
    options: ['اقرأ النص بتركيز.', 'ما أجمل القراءة!', 'هل قرأت النص؟'],
    answer: 2,
    explain: '«هل قرأت النص؟» بدأت بأداة الاستفهام «هل» وانتهت بعلامة استفهام.'
  }
];

const ORDER_SENTENCES: string[][] = [
  ['يحافظ', 'الطالب', 'على', 'وطنه'],
  ['الصدق', 'يهدي', 'إلى', 'البر'],
  ['العلم', 'يبني', 'بيوتًا', 'لا عماد لها']
];

const MEANING_PAIRS: [string, string, string[]][] = [
  ['العطاء', 'تقديم الخير', ['تقديم الخير', 'المكان الذي ننتمي إليه', 'قدرة يتميز بها الشخص']],
  ['الوطن', 'المكان الذي ننتمي إليه', ['المكان الذي ننتمي إليه', 'تقديم الخير', 'التأني في الحكم']],
  ['الموهبة', 'قدرة يتميز بها الشخص', ['قدرة يتميز بها الشخص', 'تقديم الخير', 'المكان الذي ننتمي إليه']]
];

const SPEED_QS: [string, string[], number][] = [
  ['جمع كتاب؟', ['كتب', 'كتابان', 'كاتب'], 0],
  ['مؤنث معلم؟', ['معلمة', 'معلمان', 'معلمون'], 0],
  ['استفهام؟', ['اكتب', 'هل قرأت؟', 'ما أجمل!'], 1],
  ['همزة وصل؟', ['استخرج', 'أحمد', 'إكرام'], 0]
];

const DEFAULT_SETTINGS: AppSettings = {
  announcement: 'مرحبًا بكم يا فرسان لغتي! تنافسوا في الاختبارات وتحدي الـ 24 ساعة لتتصدروا مضمار الخيل 🐎',
  enforce24hChallengeLock: true,
  enableGames: true,
  enableNafes: true,
  enableFeedback: true,
  adminPin: '1448',
  updatedAt: Date.now()
};

export default function App() {
  const [screenStage, setScreenStage] = useState<'cover' | 'welcome' | 'app'>('cover');
  const [profiles, setProfiles] = useState<Record<string, StudentProfile>>(() => {
    try {
      return JSON.parse(localStorage.getItem('LT_PROFILES') || '{}');
    } catch {
      return {};
    }
  });
  const [activeId, setActiveId] = useState<string>(() => {
    return localStorage.getItem('LT_ACTIVE') || '';
  });

  // Firebase Auth & Cloud Database State
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [adminUnlockedByPin, setAdminUnlockedByPin] = useState<boolean>(false);
  const [adminPinInput, setAdminPinInput] = useState<string>('');
  const [cloudStudents, setCloudStudents] = useState<CloudStudentRow[]>([]);
  const [customChallenges, setCustomChallenges] = useState<(DailyChallengeItem & { docId: string })[]>([]);
  const [appSettings, setAppSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [cloudFeedback, setCloudFeedback] = useState<FeedbackItem[]>([]);

  // Modals
  const [activeModal, setActiveModal] = useState<
    | null
    | 'profileModal'
    | 'lessonModal'
    | 'quizModal'
    | 'gamesModal'
    | 'feedbackModal'
    | 'badgesModal'
    | 'mistakesModal'
    | 'adminModal'
    | 'nafesStagesModal'
    | 'shareModal'
  >(null);
  const [selectedUnit, setSelectedUnit] = useState<number>(1);

  // Admin panel active tab
  const [adminTab, setAdminTab] = useState<'students' | 'challenges' | 'settings' | 'feedback'>('students');
  // New Custom Challenge Form in Admin
  const [newChDay, setNewChDay] = useState<number>(11);
  const [newChLevel, setNewChLevel] = useState<DailyChallengeItem['level']>('صعب جدًا');
  const [newChPoints, setNewChPoints] = useState<number>(35);
  const [newChTopic, setNewChTopic] = useState<string>('الوحدة الأولى والثانية — تطبيقات نحوية');
  const [newChQuestion, setNewChQuestion] = useState<string>('');
  const [newChOpt0, setNewChOpt0] = useState<string>('');
  const [newChOpt1, setNewChOpt1] = useState<string>('');
  const [newChOpt2, setNewChOpt2] = useState<string>('');
  const [newChOpt3, setNewChOpt3] = useState<string>('');
  const [newChAnswer, setNewChAnswer] = useState<number>(0);
  const [newChExplain, setNewChExplain] = useState<string>('');

  // Remedies modal tab
  const [mistakesTab, setMistakesTab] = useState<'myMistakes' | 'commonMistakes'>('myMistakes');

  // Toast / custom notice
  const [notice, setNotice] = useState<string | null>(null);
  const showNotice = (msg: string) => {
    setNotice(msg);
  };

  // Profile form state
  const [profileMode, setProfileMode] = useState<'chooser' | 'create' | 'login'>('chooser');
  const [newName, setNewName] = useState('');
  const [newCode, setNewCode] = useState('');
  const [newCls, setNewCls] = useState('أ');
  const [loginName, setLoginName] = useState('');
  const [loginPin, setLoginPin] = useState('');

  // Quiz state
  const [quiz, setQuiz] = useState<QuizState | null>(null);
  const [qi, setQi] = useState(0);
  const [score, setScore] = useState(0);
  const [userAnswers, setUserAnswers] = useState<
    Record<number, { selected?: number; essay?: string; isCorrect: boolean }>
  >({});
  const [essayDraft, setEssayDraft] = useState('');
  const [quizFinished, setQuizFinished] = useState(false);
  const [showPassage, setShowPassage] = useState(true);

  // Daily challenge strict 24h after answer state + stopwatch timer
  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  const [dailyElapsedSec, setDailyElapsedSec] = useState<number>(0);
  const [dailyTimerRunning, setDailyTimerRunning] = useState<boolean>(true);
  const [dailyWrongChoices, setDailyWrongChoices] = useState<number[]>([]);
  const [dailyAttempts, setDailyAttempts] = useState<number>(0);
  const [dailySolvedTime, setDailySolvedTime] = useState<number | null>(null);

  const [localDailyState, setLocalDailyState] = useState<DailyChallengeState>(() => {
    try {
      const raw = localStorage.getItem('LT_DAILY_STATE_V2');
      if (raw) return JSON.parse(raw);
    } catch {
      // ignore
    }
    return {
      currentIndex: 0,
      nextUnlockMs: 0,
      solvedDays: {}
    };
  });

  // Games state
  const [gameView, setGameView] = useState<'menu' | 'detective' | 'order' | 'meaning' | 'speed'>('menu');
  const [detIndex, setDetIndex] = useState(0);
  const [detScore, setDetScore] = useState(0);
  const [detSelected, setDetSelected] = useState<number | null>(null);
  const [detDone, setDetDone] = useState(false);

  const [orderRound, setOrderRound] = useState(0);
  const [orderWords, setOrderWords] = useState<string[]>([]);
  const [orderChosen, setOrderChosen] = useState<number[]>([]);

  const [meanIndex, setMeanIndex] = useState(0);
  const [meanScore, setMeanScore] = useState(0);
  const [meanOpts, setMeanOpts] = useState<string[]>([]);
  const [meanDone, setMeanDone] = useState(false);

  const [speedIndex, setSpeedIndex] = useState(0);
  const [speedScore, setSpeedScore] = useState(0);
  const [speedTime, setSpeedTime] = useState(30);
  const [speedDone, setSpeedDone] = useState(false);
  const speedTimerRef = useRef<number | null>(null);

  // Feedback state
  const [fbRole, setFbRole] = useState('ولي أمر طالب');
  const [fbCls, setFbCls] = useState('بدون تحديد');
  const [fbText, setFbText] = useState('');
  const [globalFeedback, setGlobalFeedback] = useState<FeedbackItem[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('LT_FEEDBACK') || '[]');
    } catch {
      return [];
    }
  });

  const currentProfile = activeId && profiles[activeId] ? profiles[activeId] : null;
  const studentMistakes = currentProfile?.mistakes || [];
  const isTeacherAdmin =
    adminUnlockedByPin ||
    Boolean(firebaseUser?.email && firebaseUser.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());

  // Combine default progression + teacher's custom challenges from Firestore
  const allDailyChallenges: DailyChallengeItem[] = [
    ...DAILY_CHALLENGE_PROGRESSION,
    ...customChallenges
  ].sort((a, b) => a.day - b.day);

  // Sync student profile to Firestore database
  const syncProfileToCloud = async (profileId: string, p: StudentProfile) => {
    const safeId = toSafeDocId(profileId);
    const daily = p.dailyChallenge || localDailyState;
    const payload = {
      profileId: profileId.slice(0, 100),
      name: p.name.slice(0, 80),
      code: p.code.slice(0, 4),
      cls: p.cls.slice(0, 10),
      points: Math.max(0, Math.min(1000000, p.points || 0)),
      badges: (p.badges || []).slice(0, 20),
      correct: Math.max(0, p.correct || 0),
      attempts: Math.max(0, p.attempts || 0),
      progress: Math.max(0, Math.min(100, p.progress || 0)),
      completed: (p.completed || []).slice(0, 50),
      nafesStageIndex: Math.max(0, p.nafesStageIndex || 0),
      dailyCurrentIndex: Math.max(0, daily.currentIndex || 0),
      dailyNextUnlockMs: Math.max(0, daily.nextUnlockMs || 0),
      lastQuizTitle: (p.lastQuizTitle || p.lastActivity?.label || 'لم يختبر بعد').slice(0, 120),
      lastQuizScore: Math.max(0, p.lastQuizScore || 0),
      lastQuizTotal: Math.max(0, p.lastQuizTotal || 0),
      isBlocked: Boolean(p.isBlocked),
      updatedAt: Date.now()
    };
    try {
      await setDoc(doc(db, 'students', safeId), payload);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `students/${safeId}`);
    }
  };

  // Listen to Firebase Auth state and real-time Firestore collections
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, u => {
      setFirebaseUser(u);
    });

    // Listen to students leaderboard & progress
    const qStudents = query(collection(db, 'students'));
    const unsubStudents = onSnapshot(
      qStudents,
      snap => {
        const rows: CloudStudentRow[] = [];
        snap.forEach(d => {
          const data = d.data();
          if (data && typeof data.points === 'number' && data.points >= 0) {
            rows.push({
              docId: d.id,
              profileId: data.profileId || d.id,
              name: data.name || 'طالب',
              code: data.code || '0000',
              cls: data.cls || 'أ',
              points: data.points || 0,
              badges: Array.isArray(data.badges) ? data.badges : [],
              correct: data.correct || 0,
              attempts: data.attempts || 0,
              progress: data.progress || 0,
              completed: Array.isArray(data.completed) ? data.completed : [],
              nafesStageIndex: data.nafesStageIndex || 0,
              dailyCurrentIndex: data.dailyCurrentIndex || 0,
              dailyNextUnlockMs: data.dailyNextUnlockMs || 0,
              lastQuizTitle: data.lastQuizTitle || '—',
              lastQuizScore: data.lastQuizScore || 0,
              lastQuizTotal: data.lastQuizTotal || 0,
              isBlocked: Boolean(data.isBlocked),
              updatedAt: data.updatedAt || 0
            });
          }
        });
        rows.sort((a, b) => b.points - a.points || b.correct - a.correct);
        setCloudStudents(rows);
      },
      err => {
        handleFirestoreError(err, OperationType.LIST, 'students');
      }
    );

    // Listen to custom challenges
    const qChallenges = query(collection(db, 'custom_challenges'));
    const unsubChallenges = onSnapshot(
      qChallenges,
      snap => {
        const list: (DailyChallengeItem & { docId: string })[] = [];
        snap.forEach(d => {
          const data = d.data();
          if (data && data.question && Array.isArray(data.options)) {
            list.push({
              docId: d.id,
              day: Number(data.day) || 11,
              level: data.level || 'صعب جدًا',
              points: Number(data.points) || 30,
              unitTopic: data.unitTopic || 'تحدي المعلم',
              question: data.question,
              options: data.options,
              answer: Number(data.answer) || 0,
              explanation: data.explanation || ''
            });
          }
        });
        setCustomChallenges(list);
      },
      err => {
        handleFirestoreError(err, OperationType.LIST, 'custom_challenges');
      }
    );

    // Listen to global app settings
    const unsubSettings = onSnapshot(
      doc(db, 'app_settings', 'global'),
      snap => {
        if (snap.exists()) {
          const data = snap.data() as AppSettings;
          setAppSettings(data);
        }
      },
      err => {
        handleFirestoreError(err, OperationType.GET, 'app_settings/global');
      }
    );

    // Listen to parent feedback
    const qFeedback = query(collection(db, 'feedback'));
    const unsubFeedback = onSnapshot(
      qFeedback,
      snap => {
        const items: FeedbackItem[] = [];
        snap.forEach(d => {
          const data = d.data();
          items.push({
            id: d.id,
            role: data.role || 'ولي أمر طالب',
            cls: data.cls || 'بدون تحديد',
            text: data.text || '',
            status: data.status || 'قيد المراجعة',
            createdAt: data.createdAt || 0
          });
        });
        items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setCloudFeedback(items);
      },
      err => {
        handleFirestoreError(err, OperationType.LIST, 'feedback');
      }
    );

    return () => {
      unsubAuth();
      unsubStudents();
      unsubChallenges();
      unsubSettings();
      unsubFeedback();
    };
  }, []);

  useEffect(() => {
    localStorage.setItem('LT_PROFILES', JSON.stringify(profiles));
    localStorage.setItem('LT_ACTIVE', activeId);
  }, [profiles, activeId]);

  useEffect(() => {
    localStorage.setItem('LT_FEEDBACK', JSON.stringify(globalFeedback));
  }, [globalFeedback]);

  useEffect(() => {
    localStorage.setItem('LT_DAILY_STATE_V2', JSON.stringify(localDailyState));
  }, [localDailyState]);

  // ============================================================================
  // STRICT 24-HOUR LOCK AFTER ANSWERING PREVIOUS DAILY CHALLENGE QUESTION
  // ============================================================================
  const activeDailyState: DailyChallengeState = currentProfile?.dailyChallenge || localDailyState;
  const solvedDaysMap = activeDailyState.solvedDays || {};

  // Auto-advance to the next question ONLY when 24 hours have passed since solving the current one
  useEffect(() => {
    const curIdx = activeDailyState.currentIndex || 0;
    const isCurrentSolved = Boolean(solvedDaysMap[curIdx]);
    const unlockMs = activeDailyState.nextUnlockMs || 0;

    if (isCurrentSolved && unlockMs > 0 && nowMs >= unlockMs) {
      const nextIdx = (curIdx + 1) % allDailyChallenges.length;
      // Clear solved record if cycling back or moving forward
      const updatedState: DailyChallengeState = {
        ...activeDailyState,
        currentIndex: nextIdx,
        nextUnlockMs: 0
      };
      if (currentProfile && activeId) {
        updateCurrentProfile(p => ({
          ...p,
          dailyChallenge: updatedState
        }));
      } else {
        setLocalDailyState(updatedState);
      }
    }
  }, [nowMs, activeDailyState, allDailyChallenges.length, activeId]);

  const currentDayIndex = (activeDailyState.currentIndex || 0) % Math.max(1, allDailyChallenges.length);
  const currentDailyChallenge =
    allDailyChallenges[currentDayIndex] || DAILY_CHALLENGE_PROGRESSION[0];
  const currentDaySolvedRecord = solvedDaysMap[currentDayIndex];
  const isWaitingFor24hUnlock =
    Boolean(currentDaySolvedRecord) &&
    activeDailyState.nextUnlockMs > nowMs &&
    appSettings.enforce24hChallengeLock;

  const msRemainingToUnlockNext = Math.max(0, (activeDailyState.nextUnlockMs || 0) - nowMs);
  const remHours = Math.floor(msRemainingToUnlockNext / (1000 * 60 * 60));
  const remMinutes = Math.floor((msRemainingToUnlockNext % (1000 * 60 * 60)) / (1000 * 60));
  const remSeconds = Math.floor((msRemainingToUnlockNext % (1000 * 60)) / 1000);

  // Reset stopwatch when question index changes or student switches
  useEffect(() => {
    const solved = solvedDaysMap[currentDayIndex];
    if (solved) {
      setDailySolvedTime(solved.timeSpentSec);
      setDailyElapsedSec(solved.timeSpentSec);
      setDailyAttempts(solved.attempts);
      setDailyWrongChoices([]);
      setDailyTimerRunning(false);
    } else {
      setDailySolvedTime(null);
      setDailyElapsedSec(0);
      setDailyAttempts(0);
      setDailyWrongChoices([]);
      setDailyTimerRunning(true);
    }
  }, [currentDayIndex, activeId, Boolean(currentDaySolvedRecord)]);

  // 1-second tick for 24-hour unlock countdown and student solution stopwatch
  useEffect(() => {
    if (screenStage !== 'app') return;
    const timer = window.setInterval(() => {
      setNowMs(Date.now());
      setDailyElapsedSec(prev => {
        if (dailyTimerRunning && dailySolvedTime === null && activeModal === null) {
          return prev + 1;
        }
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [screenStage, dailyTimerRunning, dailySolvedTime, activeModal]);

  const formatStopwatch = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const handleAnswerDailyChallenge = (optIdx: number) => {
    if (dailySolvedTime !== null || dailyWrongChoices.includes(optIdx)) return;
    const nextAttempts = dailyAttempts + 1;
    setDailyAttempts(nextAttempts);

    if (optIdx === currentDailyChallenge.answer) {
      fireCelebratoryFireworks();
      const finalSec = Math.max(1, dailyElapsedSec);
      const solvedAtMs = Date.now();
      // Next question opens strictly 24 hours after answering this question!
      const nextUnlockMs = solvedAtMs + 24 * 60 * 60 * 1000;

      setDailySolvedTime(finalSec);
      setDailyTimerRunning(false);

      const solvedEntry = { timeSpentSec: finalSec, attempts: nextAttempts, solvedAtMs };
      const newDailyState: DailyChallengeState = {
        currentIndex: currentDayIndex,
        nextUnlockMs,
        solvedDays: {
          ...solvedDaysMap,
          [currentDayIndex]: solvedEntry
        }
      };

      if (currentProfile && activeId) {
        updateCurrentProfile(p => {
          const nextBadges = [...p.badges];
          if (
            (currentDailyChallenge.level.includes('صعب جدًا') || currentDayIndex >= 6) &&
            !nextBadges.includes('قاهر التحدي الصعب')
          ) {
            nextBadges.push('قاهر التحدي الصعب');
          }
          if (finalSec <= 20 && !nextBadges.includes('سريع البديهة')) {
            nextBadges.push('سريع البديهة');
          }
          return {
            ...p,
            points: p.points + currentDailyChallenge.points,
            correct: p.correct + 1,
            attempts: p.attempts + 1,
            badges: nextBadges,
            dailyChallenge: newDailyState
          };
        });
      } else {
        setLocalDailyState(newDailyState);
      }

      showNotice(
        `🎉 أحسنت! وصلت للحل الصحيح في ${finalSec} ثانية وحصلت على +${currentDailyChallenge.points} نقطة! سيفتح لك السؤال التالي الأصعب بعد 24 ساعة من الآن.`
      );
    } else {
      setDailyWrongChoices(prev => [...prev, optIdx]);
    }
  };

  // Teacher override to unlock next daily challenge immediately if needed
  const handleAdminUnlockNextDaily = () => {
    const nextIdx = (currentDayIndex + 1) % allDailyChallenges.length;
    const updatedState: DailyChallengeState = {
      currentIndex: nextIdx,
      nextUnlockMs: 0,
      solvedDays: solvedDaysMap
    };
    if (currentProfile && activeId) {
      updateCurrentProfile(p => ({
        ...p,
        dailyChallenge: updatedState
      }));
    } else {
      setLocalDailyState(updatedState);
    }
    showNotice('تم فتح سؤال التحدي لليوم التالي بصلاحية المعلم.');
  };

  useEffect(() => {
    if (screenStage !== 'app') {
      document.body.classList.add('landing');
      document.body.classList.remove('appReady');
    } else {
      document.body.classList.remove('landing');
      document.body.classList.add('appReady');
    }
  }, [screenStage]);

  const updateCurrentProfile = (updater: (p: StudentProfile) => StudentProfile) => {
    if (!activeId || !profiles[activeId]) return;
    setProfiles(prev => {
      const updated = updater({ ...prev[activeId] });
      syncProfileToCloud(activeId, updated);
      return {
        ...prev,
        [activeId]: updated
      };
    });
  };

  const addPoints = (ptsToAdd: number) => {
    if (!currentProfile) return;
    updateCurrentProfile(p => {
      const nextBadges = [...p.badges];
      if (ptsToAdd >= 20 && !nextBadges.includes('لاعب لغوي')) {
        nextBadges.push('لاعب لغوي');
      }
      return {
        ...p,
        points: p.points + ptsToAdd,
        badges: nextBadges
      };
    });
  };

  const needProfile = (): boolean => {
    if (!currentProfile) {
      setProfileMode('chooser');
      setActiveModal('profileModal');
      return false;
    }
    if (currentProfile.isBlocked) {
      showNotice('عذرًا، هذا الملف موقوف مؤقتًا من قِبل المعلم.');
      return false;
    }
    return true;
  };

  const handleEnterApp = () => {
    setScreenStage('app');
    window.scrollTo(0, 0);
    setTimeout(() => {
      if (!currentProfile) {
        setProfileMode('chooser');
        setActiveModal('profileModal');
      }
    }, 350);
  };

  const handleCreateProfile = () => {
    const n = newName.trim();
    const c = newCode.trim();
    if (!n) return showNotice('اكتب اسم الطالب.');
    if (!/^\d{4}$/.test(c)) return showNotice('اكتب رمزًا من 4 أرقام.');
    const id = `${n}_${c}`;
    if (profiles[id]) return showNotice('يوجد ملف بهذا الاسم والرمز.');
    const created: StudentProfile = {
      name: n,
      code: c,
      cls: newCls,
      points: 0,
      badges: [],
      correct: 0,
      attempts: 0,
      progress: 0,
      completed: [],
      lastActivity: null,
      seenQuestions: {},
      feedback: [],
      mistakes: [],
      resolvedMistakesCount: 0,
      nafesStageIndex: 0,
      completedNafesStages: [],
      lastQuizTitle: 'انضم حديثًا',
      lastQuizScore: 0,
      lastQuizTotal: 0,
      isBlocked: false,
      dailyChallenge: {
        currentIndex: 0,
        nextUnlockMs: 0,
        solvedDays: {}
      }
    };
    setProfiles(prev => ({ ...prev, [id]: created }));
    setActiveId(id);
    syncProfileToCloud(id, created);
    setNewName('');
    setNewCode('');
    setActiveModal(null);
    showNotice('تم إنشاء ملف الطالب وحفظه في سباق الفرسان بنجاح.');
  };

  // Student login from another device using Name & 4-digit PIN
  const handleStudentLoginFromAnyDevice = () => {
    const n = loginName.trim();
    const c = loginPin.trim();
    if (!n) return showNotice('اكتب اسمك الكامل المسجل.');
    if (!/^\d{4}$/.test(c)) return showNotice('اكتب رمزك السري المكون من 4 أرقام.');

    // Look up in cloudStudents first (synced from Firestore)
    const foundCloud = cloudStudents.find(
      s => (s.name.trim() === n || s.profileId.startsWith(n)) && s.code === c
    );

    if (foundCloud) {
      if (foundCloud.isBlocked) {
        return showNotice('عذرًا، هذا الملف موقوف مؤقتًا من قِبل المعلم.');
      }
      const restoredProfile: StudentProfile = {
        name: foundCloud.name,
        code: foundCloud.code,
        cls: foundCloud.cls,
        points: foundCloud.points,
        badges: foundCloud.badges || [],
        correct: foundCloud.correct,
        attempts: foundCloud.attempts,
        progress: foundCloud.progress,
        completed: foundCloud.completed || [],
        lastActivity: null,
        seenQuestions: {},
        feedback: [],
        mistakes: [],
        resolvedMistakesCount: 0,
        nafesStageIndex: foundCloud.nafesStageIndex || 0,
        completedNafesStages: [],
        lastQuizTitle: foundCloud.lastQuizTitle,
        lastQuizScore: foundCloud.lastQuizScore,
        lastQuizTotal: foundCloud.lastQuizTotal,
        isBlocked: foundCloud.isBlocked,
        dailyChallenge: {
          currentIndex: foundCloud.dailyCurrentIndex || 0,
          nextUnlockMs: foundCloud.dailyNextUnlockMs || 0,
          solvedDays: {}
        }
      };

      setProfiles(prev => ({ ...prev, [foundCloud.profileId]: restoredProfile }));
      setActiveId(foundCloud.profileId);
      setLoginName('');
      setLoginPin('');
      setActiveModal(null);
      return showNotice(`🎉 مرحبًا بعودتك يا بطل (${foundCloud.name})! تم تحميل ملفك ونقاطك (${foundCloud.points}) بنجاح.`);
    }

    // Check local profiles
    const localId = `${n}_${c}`;
    if (profiles[localId]) {
      setActiveId(localId);
      setLoginName('');
      setLoginPin('');
      setActiveModal(null);
      return showNotice(`مرحبًا بعودتك يا ${profiles[localId].name}!`);
    }

    showNotice('لم يتم العثور على طالب بهذا الاسم والرمز في قاعدة البيانات السحابية. تأكد من صحة الاسم والرمز أو أنشئ ملفًا جديدًا.');
  };

  const startQuiz = (
    title: string,
    qs: QuestionItem[],
    type: string,
    isLesson = false,
    isRemedial = false,
    hasPassage = false,
    passageData?: { title: string; genre: string; paragraphs: string[] },
    nafesStageId?: string,
    nafesStageIdx?: number
  ) => {
    setQuiz({
      title,
      qs,
      type,
      isLesson,
      isRemedial,
      hasPassage,
      passageData,
      nafesStageId,
      nafesStageIdx
    });
    setQi(0);
    setScore(0);
    setUserAnswers({});
    setEssayDraft('');
    setQuizFinished(false);
    setShowPassage(true);
    setActiveModal('quizModal');
  };

  const handleUnit = (n: number) => {
    if (!needProfile()) return;
    setSelectedUnit(n);
    updateCurrentProfile(p => ({
      ...p,
      lastActivity: { kind: 'unit', n, label: `آخر نشاط: الوحدة ${n} — ${U[n]?.n || ''}` }
    }));
    setActiveModal('lessonModal');
  };

  const handleStartLesson = (title: string, bank: QuestionItem[]) => {
    if (!currentProfile) return;
    const key = `lesson_${title}`;
    const seenMap = { ...(currentProfile.seenQuestions || {}) };
    let seen = seenMap[key] || [];
    let unseen = bank.map((_, i) => i).filter(i => !seen.includes(i));
    if (!unseen.length) {
      seen = [];
      unseen = bank.map((_, i) => i);
    }
    const chosen: number[] = [];
    const pool = [...unseen];
    while (pool.length && chosen.length < 10) {
      const k = Math.floor(Math.random() * pool.length);
      chosen.push(pool.splice(k, 1)[0]);
    }
    seenMap[key] = [...seen, ...chosen];
    updateCurrentProfile(p => ({
      ...p,
      seenQuestions: seenMap,
      lastActivity: { kind: 'lesson', n: 1, label: `آخر نشاط: ${title}` }
    }));
    startQuiz(title, chosen.map(i => bank[i]), `درس — ${title}`, true);
  };

  // ============================================================================
  // PROGRESSIVE NON-REPEATING NAFES EXAMS (Unit 1 -> Unit 2 -> Unit 3 -> Renewable)
  // ============================================================================
  const currentNafesStageIdx = currentProfile?.nafesStageIndex || 0;
  const completedNafesStages = currentProfile?.completedNafesStages || [];

  const handleNafes = () => {
    if (!needProfile()) return;
    if (!appSettings.enableNafes) {
      showNotice('اختبار نافس مغلق حاليًا من قِبل المعلم.');
      return;
    }
    setActiveModal('nafesStagesModal');
  };

  const launchNafesStage = (stage: NafesStageExam, idx: number) => {
    if (!needProfile()) return;
    // Prevent returning to an already-completed Nafes exam unless teacher/admin
    if (completedNafesStages.includes(stage.id) && !isTeacherAdmin) {
      showNotice(
        'لقد أتممت هذا الاختبار بنجاح! انتقل الآن إلى المرحلة التالية ذات النص والأسئلة الجديدة.'
      );
      return;
    }
    updateCurrentProfile(p => ({
      ...p,
      lastActivity: { kind: 'nafes', label: `آخر نشاط: ${stage.title}` }
    }));
    startQuiz(
      stage.title,
      stage.questions,
      `${stage.unitLabel} (10 فهم + 10 قواعد + 10 صح/خطأ + 2 مقالي)`,
      false,
      false,
      true,
      stage.passage,
      stage.id,
      idx
    );
  };

  const openMistakesClinic = () => {
    if (!needProfile()) return;
    setMistakesTab('myMistakes');
    setActiveModal('mistakesModal');
  };

  const startMyMistakesRemedialQuiz = () => {
    if (!currentProfile) return;
    const list = currentProfile.mistakes || [];
    if (!list.length) {
      showNotice('لا توجد لديك أخطاء مسجلة حاليًا! يمكنك تجربة تدريب الأخطاء الشائعة.');
      return;
    }
    updateCurrentProfile(p => ({
      ...p,
      lastActivity: { kind: 'remedial', label: 'آخر نشاط: جلسة علاج الأخطاء' }
    }));
    startQuiz(
      'جلسة علاج أخطائي',
      list.map(m => m.question),
      'تدريب علاجي مخصص',
      false,
      true
    );
  };

  const startCommonMistakesQuiz = () => {
    if (!needProfile()) return;
    updateCurrentProfile(p => ({
      ...p,
      lastActivity: { kind: 'remedial', label: 'آخر نشاط: تدريب الأخطاء اللغوية الشائعة' }
    }));
    startQuiz(
      'تدريب علاج الأخطاء الشائعة',
      REMEDIAL_COMMON_QS,
      'تدريب علاجي',
      false,
      false
    );
  };

  const handleResumeLast = () => {
    if (!currentProfile || !currentProfile.lastActivity) return;
    const act = currentProfile.lastActivity;
    if (act.kind === 'unit' && act.n) handleUnit(act.n);
    else if (act.kind === 'nafes') handleNafes();
    else if (act.kind === 'lesson') setActiveModal('lessonModal');
    else if (act.kind === 'remedial') openMistakesClinic();
  };

  const currentQAnswer = userAnswers[qi];
  const isCurrentAnswered = !!currentQAnswer;

  const handleAnswerMcq = (idx: number) => {
    if (isCurrentAnswered || !quiz) return;
    const z = quiz.qs[qi];
    const isCorrect = idx === z[2];
    setUserAnswers(prev => ({
      ...prev,
      [qi]: { selected: idx, isCorrect }
    }));

    if (isCorrect) {
      setScore(s => s + 1);
      if (currentProfile) {
        updateCurrentProfile(p => {
          const existing = p.mistakes || [];
          const existed = existing.some(m => m.question[0] === z[0]);
          if (!existed) return p;
          const filtered = existing.filter(m => m.question[0] !== z[0]);
          const resolvedCount = (p.resolvedMistakesCount || 0) + 1;
          const nextBadges = [...p.badges];
          if (resolvedCount >= 3 && !nextBadges.includes('معالج الأخطاء')) {
            nextBadges.push('معالج الأخطاء');
          }
          return {
            ...p,
            mistakes: filtered,
            resolvedMistakesCount: resolvedCount,
            badges: nextBadges
          };
        });
      }
    } else {
      if (currentProfile) {
        updateCurrentProfile(p => {
          const existing = p.mistakes ? [...p.mistakes] : [];
          const foundIdx = existing.findIndex(m => m.question[0] === z[0]);
          const record: MistakeRecord = {
            question: z,
            wrongChoiceIndex: idx,
            sourceTitle: quiz.title,
            timestamp: new Date().toLocaleDateString('ar-SA')
          };
          if (foundIdx >= 0) {
            existing[foundIdx] = record;
          } else {
            existing.unshift(record);
          }
          return {
            ...p,
            mistakes: existing
          };
        });
      }
    }
  };

  const handleAnswerEssay = () => {
    if (isCurrentAnswered || !quiz) return;
    if (!essayDraft.trim()) return showNotice('اكتب إجابتك المقالية أولًا.');
    setUserAnswers(prev => ({
      ...prev,
      [qi]: { essay: essayDraft.trim(), isCorrect: true }
    }));
    setScore(s => s + 1);
  };

  const handleFinishQuiz = () => {
    if (!quiz || !currentProfile) return;
    const tot = quiz.qs.length;
    updateCurrentProfile(p => {
      const completed = p.completed ? [...p.completed] : [];
      if (!completed.includes(quiz.title)) {
        completed.push(quiz.title);
      }

      // If this was a Nafes Stage exam, mark it completed and unlock the next stage!
      const compNafes = p.completedNafesStages ? [...p.completedNafesStages] : [];
      let nextNafesStageIdx = p.nafesStageIndex || 0;
      if (quiz.nafesStageId && !compNafes.includes(quiz.nafesStageId)) {
        compNafes.push(quiz.nafesStageId);
      }
      if (quiz.nafesStageIdx !== undefined && quiz.nafesStageIdx >= nextNafesStageIdx) {
        nextNafesStageIdx = quiz.nafesStageIdx + 1;
      }

      const nextBadges = [...p.badges];
      if (score === tot && !nextBadges.includes('إتقان')) {
        nextBadges.push('إتقان');
      }
      if (quiz.nafesStageId && score >= Math.ceil(tot * 0.75) && !nextBadges.includes('فارس نافس')) {
        nextBadges.push('فارس نافس');
      }
      if (compNafes.length >= 3 && !nextBadges.includes('بطل مراحل نافس')) {
        nextBadges.push('بطل مراحل نافس');
      }
      if (quiz.isRemedial && score > 0 && !nextBadges.includes('معالج الأخطاء')) {
        nextBadges.push('معالج الأخطاء');
      }

      return {
        ...p,
        points: p.points + score * 10,
        correct: p.correct + score,
        attempts: p.attempts + 1,
        completed,
        completedNafesStages: compNafes,
        nafesStageIndex: nextNafesStageIdx,
        lastQuizTitle: quiz.title,
        lastQuizScore: score,
        lastQuizTotal: tot,
        progress: Math.min(100, completed.length * 12),
        badges: nextBadges
      };
    });
    setQuizFinished(true);
    if (quiz.nafesStageId || quiz.nafesStageIdx !== undefined || score === tot) {
      fireCelebratoryFireworks();
    }
  };

  // Games handlers
  const openGames = () => {
    if (!needProfile()) return;
    if (!appSettings.enableGames) {
      showNotice('مركز الألعاب مغلق مؤقتًا من قِبل المعلم.');
      return;
    }
    if (speedTimerRef.current) clearInterval(speedTimerRef.current);
    setGameView('menu');
    setActiveModal('gamesModal');
  };

  const startDetective = () => {
    setDetIndex(0);
    setDetScore(0);
    setDetSelected(null);
    setDetDone(false);
    setGameView('detective');
  };

  const answerDetective = (j: number) => {
    if (detSelected !== null) return;
    setDetSelected(j);
    const isCorrect = j === DETECTIVE_QS[detIndex].answer;
    if (isCorrect) setDetScore(s => s + 1);
  };

  const nextDetective = () => {
    if (detIndex + 1 < DETECTIVE_QS.length) {
      setDetIndex(detIndex + 1);
      setDetSelected(null);
    } else {
      setDetDone(true);
      addPoints(detScore * 10);
    }
  };

  const initOrderRound = (rIdx: number) => {
    const target = ORDER_SENTENCES[rIdx % ORDER_SENTENCES.length];
    const shuffled = [...target].sort(() => Math.random() - 0.5);
    setOrderRound(rIdx % ORDER_SENTENCES.length);
    setOrderWords(shuffled);
    setOrderChosen([]);
  };

  const startOrderGame = () => {
    initOrderRound(0);
    setGameView('order');
  };

  const checkOrderGame = () => {
    const target = ORDER_SENTENCES[orderRound].join(' ');
    const sentence = orderChosen.map(i => orderWords[i]).join(' ');
    if (sentence === target) {
      addPoints(20);
      showNotice('ترتيب صحيح! +20 نقطة');
      setGameView('menu');
    } else {
      showNotice('راجع ترتيب الكلمات، يمكنك الضغط على الكلمة المختارة أو زر تراجع لتعديلها.');
    }
  };

  const prepareMeaningStep = (idx: number) => {
    const opts = [...MEANING_PAIRS[idx][2]].sort(() => Math.random() - 0.5);
    setMeanOpts(opts);
  };

  const startMeaning = () => {
    setMeanIndex(0);
    setMeanScore(0);
    setMeanDone(false);
    prepareMeaningStep(0);
    setGameView('meaning');
  };

  const answerMeaning = (o: string) => {
    const nextScore = o === MEANING_PAIRS[meanIndex][1] ? meanScore + 1 : meanScore;
    if (meanIndex + 1 < MEANING_PAIRS.length) {
      setMeanScore(nextScore);
      const nextIdx = meanIndex + 1;
      setMeanIndex(nextIdx);
      prepareMeaningStep(nextIdx);
    } else {
      setMeanScore(nextScore);
      setMeanDone(true);
      addPoints(nextScore * 10);
    }
  };

  const startSpeed = () => {
    if (speedTimerRef.current) clearInterval(speedTimerRef.current);
    setSpeedIndex(0);
    setSpeedScore(0);
    setSpeedTime(30);
    setSpeedDone(false);
    setGameView('speed');
    speedTimerRef.current = window.setInterval(() => {
      setSpeedTime(prev => {
        if (prev <= 1) {
          if (speedTimerRef.current) clearInterval(speedTimerRef.current);
          setSpeedDone(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const answerSpeed = (j: number) => {
    const isCorrect = j === SPEED_QS[speedIndex][2];
    const nextScore = isCorrect ? speedScore + 1 : speedScore;
    if (speedIndex + 1 < SPEED_QS.length) {
      setSpeedScore(nextScore);
      setSpeedIndex(speedIndex + 1);
    } else {
      if (speedTimerRef.current) clearInterval(speedTimerRef.current);
      setSpeedScore(nextScore);
      setSpeedDone(true);
      addPoints(nextScore * 10);
    }
  };

  const handleSendFeedback = async () => {
    const t = fbText.trim();
    if (!t) return showNotice('اكتب الاقتراح أولًا.');
    const feedId = `fb_${Date.now()}`;
    const newItem: FeedbackItem = {
      role: fbRole.slice(0, 50),
      cls: (fbCls || 'بدون تحديد').slice(0, 30),
      text: t.slice(0, 500),
      status: 'قيد المراجعة',
      createdAt: Date.now()
    };
    try {
      await setDoc(doc(db, 'feedback', feedId), newItem);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `feedback/${feedId}`);
    }
    setFbText('');
    showNotice('تم حفظ الاقتراح في قاعدة البيانات للمراجعة.');
  };

  // ============================================================================
  // ADMIN / TEACHER DATABASE CONTROLS
  // ============================================================================
  const handleGoogleAdminLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      showNotice('تم تسجيل الدخول بحساب Google بنجاح.');
    } catch (err) {
      showNotice('تعذر تسجيل الدخول عبر نافذة Google، يمكنك استخدام رمز المعلم السريع.');
    }
  };

  const handlePinAdminLogin = () => {
    if (adminPinInput.trim() === (appSettings.adminPin || '1448')) {
      setAdminUnlockedByPin(true);
      setAdminPinInput('');
      showNotice('مرحبًا بك أستاذ مساعد! تم فتح لوحة التحكم الكاملة.');
    } else {
      showNotice('رمز المعلم غير صحيح.');
    }
  };

  const handleSaveSettingsToCloud = async (updated: AppSettings) => {
    const payload: AppSettings = {
      announcement: updated.announcement.slice(0, 400),
      enforce24hChallengeLock: Boolean(updated.enforce24hChallengeLock),
      enableGames: Boolean(updated.enableGames),
      enableNafes: Boolean(updated.enableNafes),
      enableFeedback: Boolean(updated.enableFeedback),
      adminPin: (updated.adminPin || '1448').slice(0, 12),
      updatedAt: Date.now()
    };
    try {
      await setDoc(doc(db, 'app_settings', 'global'), payload);
      showNotice('تم حفظ إعدادات التطبيق والصلاحيات في قاعدة البيانات.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'app_settings/global');
    }
  };

  const handleAddCustomChallenge = async () => {
    if (!newChQuestion.trim() || !newChOpt0.trim() || !newChOpt1.trim()) {
      return showNotice('يرجى تعبئة نص السؤال والاختيارات الأربعة.');
    }
    const chId = `ch_day_${newChDay}_${Date.now()}`;
    const payload = {
      day: Math.max(1, Math.min(365, Number(newChDay) || 11)),
      level: newChLevel.slice(0, 40),
      points: Math.max(5, Math.min(500, Number(newChPoints) || 30)),
      unitTopic: (newChTopic.trim() || 'تحدي المعلم').slice(0, 120),
      question: newChQuestion.trim().slice(0, 500),
      options: [
        newChOpt0.trim().slice(0, 240) || 'خيار 1',
        newChOpt1.trim().slice(0, 240) || 'خيار 2',
        newChOpt2.trim().slice(0, 240) || 'خيار 3',
        newChOpt3.trim().slice(0, 240) || 'خيار 4'
      ],
      answer: Math.max(0, Math.min(3, Number(newChAnswer) || 0)),
      explanation: (newChExplain.trim() || 'إجابة صحيحة وفق القاعدة النحوية.').slice(0, 500),
      authorEmail: firebaseUser?.email || ADMIN_EMAIL,
      createdAt: Date.now()
    };
    try {
      await setDoc(doc(db, 'custom_challenges', chId), payload);
      setNewChQuestion('');
      setNewChOpt0('');
      setNewChOpt1('');
      setNewChOpt2('');
      setNewChOpt3('');
      setNewChExplain('');
      setNewChDay(prev => prev + 1);
      showNotice('تمت إضافة سؤال التحدي الجديد إلى قاعدة البيانات بنجاح!');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `custom_challenges/${chId}`);
    }
  };

  const handleDeleteCustomChallenge = async (docId: string) => {
    try {
      await deleteDoc(doc(db, 'custom_challenges', docId));
      showNotice('تم حذف سؤال التحدي.');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `custom_challenges/${docId}`);
    }
  };

  const handleAdminModifyStudent = async (
    st: CloudStudentRow,
    changes: Partial<CloudStudentRow>
  ) => {
    const merged: CloudStudentRow = { ...st, ...changes, updatedAt: Date.now() };
    const payload = {
      profileId: merged.profileId.slice(0, 100),
      name: merged.name.slice(0, 80),
      code: merged.code.slice(0, 4),
      cls: merged.cls.slice(0, 10),
      points: Math.max(0, Math.min(1000000, merged.points)),
      badges: (merged.badges || []).slice(0, 20),
      correct: Math.max(0, merged.correct),
      attempts: Math.max(0, merged.attempts),
      progress: Math.max(0, Math.min(100, merged.progress)),
      completed: (merged.completed || []).slice(0, 50),
      nafesStageIndex: Math.max(0, merged.nafesStageIndex),
      dailyCurrentIndex: Math.max(0, merged.dailyCurrentIndex),
      dailyNextUnlockMs: Math.max(0, merged.dailyNextUnlockMs),
      lastQuizTitle: (merged.lastQuizTitle || '—').slice(0, 120),
      lastQuizScore: Math.max(0, merged.lastQuizScore),
      lastQuizTotal: Math.max(0, merged.lastQuizTotal),
      isBlocked: Boolean(merged.isBlocked),
      updatedAt: Date.now()
    };
    try {
      await setDoc(doc(db, 'students', st.docId), payload);
      // Also update local state if this student is on this device
      if (profiles[st.profileId]) {
        setProfiles(prev => ({
          ...prev,
          [st.profileId]: {
            ...prev[st.profileId],
            points: payload.points,
            nafesStageIndex: payload.nafesStageIndex,
            isBlocked: payload.isBlocked,
            dailyChallenge: {
              ...(prev[st.profileId].dailyChallenge || { currentIndex: 0, nextUnlockMs: 0, solvedDays: {} }),
              currentIndex: payload.dailyCurrentIndex,
              nextUnlockMs: payload.dailyNextUnlockMs
            }
          }
        }));
      }
      showNotice(`تم تحديث بيانات الطالب (${st.name}) في قاعدة البيانات.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `students/${st.docId}`);
    }
  };

  const handleToggleFeedbackApproval = async (fb: FeedbackItem) => {
    if (!fb.id) return;
    const nextStatus = fb.status === 'معتمد ومنشور' ? 'قيد المراجعة' : 'معتمد ومنشور';
    try {
      await setDoc(doc(db, 'feedback', fb.id), {
        role: fb.role,
        cls: fb.cls || 'بدون تحديد',
        text: fb.text,
        status: nextStatus,
        createdAt: fb.createdAt || Date.now()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `feedback/${fb.id}`);
    }
  };

  // Merge cloud students and local profiles for the Top 10 Horse Race Leaderboard
  const leaderboardStudents: CloudStudentRow[] = (() => {
    const map = new Map<string, CloudStudentRow>();
    cloudStudents.forEach(s => map.set(s.profileId, s));
    Object.entries(profiles).forEach(([pid, p]) => {
      if (!map.has(pid)) {
        map.set(pid, {
          docId: toSafeDocId(pid),
          profileId: pid,
          name: p.name,
          code: p.code,
          cls: p.cls,
          points: p.points || 0,
          badges: p.badges || [],
          correct: p.correct || 0,
          attempts: p.attempts || 0,
          progress: p.progress || 0,
          completed: p.completed || [],
          nafesStageIndex: p.nafesStageIndex || 0,
          dailyCurrentIndex: p.dailyChallenge?.currentIndex || 0,
          dailyNextUnlockMs: p.dailyChallenge?.nextUnlockMs || 0,
          lastQuizTitle: p.lastQuizTitle || p.lastActivity?.label || '—',
          lastQuizScore: p.lastQuizScore || 0,
          lastQuizTotal: p.lastQuizTotal || 0,
          isBlocked: Boolean(p.isBlocked),
          updatedAt: Date.now()
        });
      }
    });
    return Array.from(map.values()).sort((a, b) => b.points - a.points || b.correct - a.correct);
  })();

  const top10Racers = leaderboardStudents.slice(0, 10);
  const maxRacePoints = Math.max(100, ...(top10Racers.map(r => r.points) || [100]));

  const allFeedbackToDisplay =
    cloudFeedback.length > 0 ? cloudFeedback : [...(currentProfile?.feedback || []), ...globalFeedback];

  return (
    <>
      {screenStage === 'cover' && (
        <CoverSplash onEnter={() => setScreenStage('welcome')} />
      )}

      {screenStage === 'welcome' && (
        <div id="splash" className="splash" aria-label="واجهة الترحيب">
          <div className="splashCard">
            <div className="splashDecorTop" />
            <div className="splashDecorBot" />
            <div className="splashBadge">
              <span>🎓</span>
              <span>الصف الأول المتوسط • الفصل الدراسي الأول • 1448هـ</span>
            </div>
            <img className="splashHeroArt" alt="واجهة لُغتي تحكي" src={SPLASH_SVG} />
            <h1 className="splashTitle">📚 لُغتي تحكي</h1>
            <p className="splashSub">لغتي تحكي... وأنا أصنع الحكاية</p>
            <p className="splashDesc">
              منصة تعليمية تفاعلية تجمع بين متعة التعلّم، وإتقان القواعد النحوية والإملائية، وتحديات الفهم القرائي، ومعالجة الأخطاء بأسلوب شيّق.
            </p>
            <div className="splashPills">
              <span className="splashPill">📖 دروس وأنشطة تفاعلية</span>
              <span className="splashPill">🏆 مراحل نافس المتجددة</span>
              <span className="splashPill">🐎 مضمار سباق الفرسان</span>
              <span className="splashPill">🩺 عيادة علاج الأخطاء</span>
            </div>
            <button className="splashEnterBtn" aria-label="ابدأ رحلتك الآن" onClick={handleEnterApp}>
              <span>ابدأ رحلتك الآن</span>
              <span>←</span>
            </button>
            <div className="splashFooter">
              <span>
                ✨ إعداد وتنفيذ: <b>المعلم / مساعد سليمان الصخري</b>
              </span>
              <span>جميع الحقوق محفوظة © 2026/2027م</span>
            </div>
          </div>
        </div>
      )}

      {screenStage === 'app' && (
        <div id="appShell" style={{ display: 'block' }}>
          <header className="hero">
            <div className="wrap heroIn">
              <div className="art">📚🌿</div>
              <div className="title">
                <h1>📚 لُغتي تحكي</h1>
                <p>لغتي تحكي... وأنا أصنع الحكاية</p>
              </div>
              <div className="term">
                <b>🎓 الصف الأول المتوسط</b>
                <span>الفصل الدراسي الأول</span>
                <span>1448هـ – 2026/2027م</span>
                <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginTop: 8, flexWrap: 'wrap' }}>
                  <button
                    className="btn light"
                    style={{ padding: '5px 12px', fontSize: 12 }}
                    onClick={() => setActiveModal('adminModal')}
                  >
                    ⚙️ لوحة تحكم المعلم (خاص بالمعلم)
                  </button>
                  <button
                    className="btn gold"
                    style={{ padding: '5px 12px', fontSize: 12, display: 'inline-flex', alignItems: 'center', gap: 4 }}
                    onClick={() => setActiveModal('shareModal')}
                    title="مشاركة رابط المنصة مع الطلاب والمعلمين عبر الواتساب"
                  >
                    📱 مشاركة عبر الواتساب ورابط المنصة
                  </button>
                </div>
              </div>
            </div>
          </header>

          <main className="wrap">
            {/* Teacher Announcement Banner */}
            {appSettings.announcement && (
              <div
                style={{
                  marginTop: 16,
                  background: 'linear-gradient(90deg,#fff8e6,#fffdf7)',
                  border: '1px solid #f0d799',
                  borderRight: '5px solid #f7b832',
                  borderRadius: 16,
                  padding: '10px 16px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: 10
                }}
              >
                <div>
                  <b style={{ color: '#946200' }}>📣 رسالة المعلم: </b>
                  <span>{appSettings.announcement}</span>
                </div>
              </div>
            )}

            <section className="welcome">
              <div className="student">
                <div className="avatar">👤</div>
                <div>
                  <h2 id="wname">{currentProfile ? `مرحبًا ${currentProfile.name}` : 'مرحبًا بك'}</h2>
                  <p id="winfo">
                    {currentProfile
                      ? `أول متوسط • الفصل ${currentProfile.cls} • المرحلة الحالية في نافس: (${Math.min(
                          currentNafesStageIdx + 1,
                          NAFES_STAGES.length
                        )} من ${NAFES_STAGES.length})`
                      : 'أنشئ ملفك لتبدأ رحلتك ويظهر اسمك في مضمار سباق الفرسان.'}
                  </p>
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 4 }}>
                    <button
                      className="btn light"
                      onClick={() => {
                        setProfileMode('chooser');
                        setActiveModal('profileModal');
                      }}
                    >
                      👤 ملف الطالب
                    </button>
                    {studentMistakes.length > 0 && (
                      <button className="btn coral" onClick={openMistakesClinic}>
                        🩺 لديك ({studentMistakes.length}) أخطاء للمعالجة
                      </button>
                    )}
                  </div>
                </div>
              </div>
              <div className="stat">
                <i>⭐</i>
                <b id="pts">{currentProfile ? currentProfile.points : 0}</b>
                النقاط
              </div>
              <div
                className="stat"
                style={{ cursor: 'pointer' }}
                onClick={() => setActiveModal('badgesModal')}
                title="اضغط لعرض الشارات"
              >
                <i>🏅</i>
                <b id="badges">{currentProfile ? currentProfile.badges.length : 0}</b>
                الشارات
              </div>
            </section>

            {/* ================================================================= */}
            {/* HORSE RACE LEADERBOARD FOR TOP 10 STUDENTS & EXAM PROGRESS TABLE   */}
            {/* ================================================================= */}
            <section className="raceSection">
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  flexWrap: 'wrap',
                  gap: 10,
                  marginBottom: 12
                }}
              >
                <div>
                  <h2 style={{ margin: 0, fontSize: 24, color: 'var(--t)' }}>
                    🏇 مضمار سباق فرسان لغتي (أوائل الطلاب الـ 10)
                  </h2>
                  <p className="sub" style={{ margin: '2px 0 0' }}>
                    يتقدم جواد كل طالب في السباق تلقائيًا مع كل اختبار يجتازه وكل تحدٍّ يحلّه، ويُحفظ التقدم في قاعدة البيانات.
                  </p>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span className="splashBadge" style={{ margin: 0 }}>
                    👥 إجمالي الفرسان المسجلين: {leaderboardStudents.length}
                  </span>
                </div>
              </div>

              {top10Racers.length > 0 ? (
                <div className="raceTrack">
                  <div className="raceFinishLine" title="خط النهاية والصدارة" />
                  {top10Racers.map((racer, idx) => {
                    // Calculate horizontal progress from right (start = 4%) to left (finish = 76%)
                    const ratio = Math.min(1, Math.max(0.06, racer.points / maxRacePoints));
                    const rightPercent = Math.round(4 + ratio * 68);
                    const medal =
                      idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `${idx + 1}`;
                    return (
                      <div key={racer.profileId} className="raceLane">
                        <div
                          className="raceRankBadge"
                          style={{
                            background:
                              idx === 0
                                ? '#f7b832'
                                : idx === 1
                                ? '#d9e2ec'
                                : idx === 2
                                ? '#eab676'
                                : '#e2f1ee',
                            color: '#174c59'
                          }}
                        >
                          {medal}
                        </div>
                        <div className="raceRunnerWrap">
                          <div
                            className="raceHorseNode"
                            style={{
                              right: `${rightPercent}%`,
                              borderColor: idx === 0 ? '#e59812' : '#126b70',
                              background: idx === 0 ? '#fffbeb' : '#ffffffec'
                            }}
                          >
                            <span className="raceHorseIcon">🐎</span>
                            <b style={{ fontSize: 13, color: '#0d5960' }}>{racer.name}</b>
                            <span
                              style={{
                                fontSize: 11,
                                background: '#e6f6f3',
                                color: '#126b70',
                                padding: '1px 7px',
                                borderRadius: 999,
                                fontWeight: 800
                              }}
                            >
                              فصل {racer.cls} • ⭐ {racer.points}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="note" style={{ textAlign: 'center', padding: 16 }}>
                  🐎 المضمار جاهز للانطلاق! أنشئ ملف طالب وابدأ الاختبارات ليظهر جوادك في سباق العشرة الأوائل.
                </div>
              )}

              {/* Student Progress Table Across Exams */}
              {leaderboardStudents.length > 0 && (
                <div style={{ marginTop: 16, overflowX: 'auto' }}>
                  <h4 style={{ margin: '0 0 8px', color: 'var(--ink)' }}>
                    📊 سجل تقدم الطلاب في الاختبارات ومراحل نافس:
                  </h4>
                  <table
                    style={{
                      width: '100%',
                      borderCollapse: 'collapse',
                      background: '#fff',
                      borderRadius: 14,
                      overflow: 'hidden',
                      fontSize: 13
                    }}
                  >
                    <thead>
                      <tr style={{ background: '#126b70', color: '#fff', textAlign: 'right' }}>
                        <th style={{ padding: '8px 10px' }}>المركز</th>
                        <th style={{ padding: '8px 10px' }}>اسم الفارس</th>
                        <th style={{ padding: '8px 10px' }}>الفصل</th>
                        <th style={{ padding: '8px 10px' }}>النقاط</th>
                        <th style={{ padding: '8px 10px' }}>مراحل نافس المنجزة</th>
                        <th style={{ padding: '8px 10px' }}>آخر اختبار ونتيجته</th>
                        <th style={{ padding: '8px 10px' }}>نسبة التقدم</th>
                      </tr>
                    </thead>
                    <tbody>
                      {leaderboardStudents.slice(0, 15).map((st, i) => (
                        <tr
                          key={st.profileId}
                          style={{
                            borderBottom: '1px solid #e7f0ee',
                            background: st.profileId === activeId ? '#effaf7' : '#fff'
                          }}
                        >
                          <td style={{ padding: '8px 10px', fontWeight: 800 }}>#{i + 1}</td>
                          <td style={{ padding: '8px 10px', fontWeight: 800 }}>🐎 {st.name}</td>
                          <td style={{ padding: '8px 10px' }}>{st.cls}</td>
                          <td style={{ padding: '8px 10px', fontWeight: 800, color: '#197a56' }}>
                            ⭐ {st.points}
                          </td>
                          <td style={{ padding: '8px 10px' }}>
                            المرحلة {Math.min(st.nafesStageIndex + 1, NAFES_STAGES.length)} من{' '}
                            {NAFES_STAGES.length} ({st.nafesStageIndex} مكتمل)
                          </td>
                          <td style={{ padding: '8px 10px' }}>
                            {st.lastQuizTitle}{' '}
                            {st.lastQuizTotal > 0 ? `(${st.lastQuizScore}/${st.lastQuizTotal})` : ''}
                          </td>
                          <td style={{ padding: '8px 10px', fontWeight: 800 }}>{st.progress}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>

            {currentProfile && currentProfile.lastActivity && (
              <section id="resumeCard" className="resume">
                <div style={{ flex: 1 }}>
                  <b>↩️ تابع من حيث توقفت</b>
                  <div id="resumeText" className="sub" style={{ margin: '2px 0 0' }}>
                    {currentProfile.lastActivity.label}
                  </div>
                  <div className="progressWrap">
                    <i id="progressBar" style={{ width: `${currentProfile.progress || 0}%` }} />
                  </div>
                  <div className="progressLabel">
                    <span>تقدمك في الرحلة</span>
                    <span id="progressText">{currentProfile.progress || 0}%</span>
                  </div>
                </div>
                <button className="btn primary" onClick={handleResumeLast}>
                  متابعة
                </button>
              </section>
            )}

            <section>
              <div className="secTitle">
                <h2>📖 الوحدات الدراسية</h2>
                <span className="line" />
              </div>
              <p className="sub">ابدأ من الوحدة التي تريدها واستكشف دروسها وأنشطتها.</p>
              <div className="units">
                <article className="unit u1">
                  <div className="unitArt">🕌📖</div>
                  <h3>
                    الوحدة الأولى
                    <br />
                    القيم الإسلامية
                  </h3>
                  <p>قيمنا ومهاراتنا اللغوية في سياقات تربوية.</p>
                  <button className="btn green" onClick={() => handleUnit(1)}>
                    ابدأ الوحدة ←
                  </button>
                </article>
                <article className="unit u2">
                  <div className="unitArt">📚🪶</div>
                  <h3>
                    الوحدة الثانية
                    <br />
                    الأعلام
                  </h3>
                  <p>نتعرف على أعلامنا ونبني على إنجازاتهم.</p>
                  <button className="btn purple" onClick={() => handleUnit(2)}>
                    ابدأ الوحدة ←
                  </button>
                </article>
                <article className="unit u3">
                  <div className="unitArt">🇸🇦🏜️</div>
                  <h3>
                    الوحدة الثالثة
                    <br />
                    وطني
                  </h3>
                  <p>نحب وطننا ونعتز بموارده ومكانته.</p>
                  <button className="btn blue" onClick={() => handleUnit(3)}>
                    ابدأ الوحدة ←
                  </button>
                </article>
              </div>
            </section>

            <section className="features">
              <div className="secTitle">
                <h2>⭐ مميزات التطبيق</h2>
              </div>
              <div className="featureGrid">
                <div className="feature">
                  <i>🎯</i>
                  <b>مهارات لغوية متنوعة</b>
                </div>
                <div className="feature">
                  <i>📚</i>
                  <b>أنشطة مرتبطة بالمنهج</b>
                </div>
                <div className="feature">
                  <i>🩺</i>
                  <b>تشخيص وعلاج الأخطاء</b>
                </div>
                <div className="feature">
                  <i>🐎</i>
                  <b>مضمار سباق الفرسان</b>
                </div>
                <div className="feature">
                  <i>📊</i>
                  <b>قاعدة بيانات ومتابعة</b>
                </div>
              </div>
            </section>

            <section>
              <div className="secTitle">
                <h2>🚀 رحلتي في لغتي</h2>
              </div>
              <div className="quick">
                <div
                  className="card"
                  style={{ borderColor: '#f3d2d4', background: 'linear-gradient(#fff9f9,#fff)' }}
                >
                  <i>🩺</i>
                  <h3>علاج الأخطاء</h3>
                  <p>
                    دفتر أخطائك الشخصي ({studentMistakes.length}) وتدريبات علاجية للأخطاء الشائعة.
                  </p>
                  <button className="btn coral full" onClick={openMistakesClinic}>
                    افتح عيادة اللغة
                  </button>
                </div>
                <div className="card">
                  <i>🎮</i>
                  <h3>مركز الألعاب</h3>
                  <p>تحديات لغوية قصيرة وممتعة.</p>
                  <button className="btn green full" onClick={openGames}>
                    افتح الألعاب
                  </button>
                </div>
                <div className="card">
                  <i>🏆</i>
                  <h3>مراحل اختبار نافس المتجدد</h3>
                  <p>
                    نصوص متجددة لكل وحدة (10 فهم قرائي + 10 قواعد + 10 صح/خطأ + 2 مقالي) دون تكرار.
                  </p>
                  <button className="btn gold full" onClick={handleNafes}>
                    افتح مراحل نافس ({completedNafesStages.length}/{NAFES_STAGES.length})
                  </button>
                </div>
                <div className="card">
                  <i>💬</i>
                  <h3>صوت ولي الأمر</h3>
                  <p>اقتراحات وآراء محفوظة مع مراجعة المعلم.</p>
                  <button
                    className="btn purple full"
                    onClick={() => {
                      if (!appSettings.enableFeedback) {
                        showNotice('إرسال المقترحات مغلق مؤقتًا.');
                        return;
                      }
                      setActiveModal('feedbackModal');
                    }}
                  >
                    أرسل اقتراحًا
                  </button>
                </div>
              </div>
            </section>

            {/* ================================================================= */}
            {/* DAILY CHALLENGE: STRICT 24-HOUR LOCK AFTER PREVIOUS ANSWER        */}
            {/* ================================================================= */}
            <section className="daily">
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  flexWrap: 'wrap',
                  gap: 10,
                  marginBottom: 12
                }}
              >
                <div>
                  <h3 style={{ margin: 0, fontSize: 22 }}>
                    🎯 سؤال التحدي اليومي (اليوم {currentDailyChallenge.day} من {allDailyChallenges.length})
                  </h3>
                  <small style={{ color: 'var(--mut)', fontWeight: 700 }}>
                    📚 {currentDailyChallenge.unitTopic}
                  </small>
                </div>

                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                  <span
                    style={{
                      background:
                        currentDailyChallenge.level === 'سهل'
                          ? '#e6f8f1'
                          : currentDailyChallenge.level === 'متوسط'
                          ? '#eef5ff'
                          : currentDailyChallenge.level === 'صعب'
                          ? '#fff4e0'
                          : '#ffecee',
                      color:
                        currentDailyChallenge.level === 'سهل'
                          ? '#197a56'
                          : currentDailyChallenge.level === 'متوسط'
                          ? '#1f64b0'
                          : currentDailyChallenge.level === 'صعب'
                          ? '#b56c00'
                          : '#b4232c',
                      border: '1px solid currentColor',
                      borderRadius: 999,
                      padding: '4px 12px',
                      fontSize: 13,
                      fontWeight: 800
                    }}
                  >
                    🔥 المستوى: {currentDailyChallenge.level} (+{currentDailyChallenge.points} نقطة)
                  </span>

                  <span
                    style={{
                      background: dailySolvedTime !== null ? '#197a56' : '#174c59',
                      color: '#fff',
                      borderRadius: 999,
                      padding: '4px 14px',
                      fontSize: 14,
                      fontWeight: 800,
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 6
                    }}
                  >
                    <span>⏱️</span>
                    <span>
                      {dailySolvedTime !== null
                        ? `زمن الوصول للحل: ${formatStopwatch(dailySolvedTime)} (${dailySolvedTime} ثانية)`
                        : `عداد الوقت: ${formatStopwatch(dailyElapsedSec)}`}
                    </span>
                  </span>

                  {isWaitingFor24hUnlock && (
                    <span
                      style={{
                        background: '#fff0f2',
                        border: '1px solid #f2b8c0',
                        color: '#9e1c28',
                        borderRadius: 999,
                        padding: '4px 12px',
                        fontSize: 13,
                        fontWeight: 800
                      }}
                    >
                      🔒 يفتح السؤال التالي الأصعب بعد مرور 24 ساعة من إجابتك:{' '}
                      {String(remHours).padStart(2, '0')}:
                      {String(remMinutes).padStart(2, '0')}:
                      {String(remSeconds).padStart(2, '0')}
                    </span>
                  )}
                </div>
              </div>

              {/* Progression Ladder Bar */}
              <div
                style={{
                  display: 'flex',
                  gap: 5,
                  overflowX: 'auto',
                  paddingBottom: 8,
                  marginBottom: 12
                }}
              >
                {allDailyChallenges.map((item, idx) => {
                  const isSolved = Boolean(solvedDaysMap[idx]);
                  const isCurrent = idx === currentDayIndex;
                  return (
                    <div
                      key={`${item.day}_${idx}`}
                      style={{
                        flex: '1 0 auto',
                        minWidth: 78,
                        textAlign: 'center',
                        padding: '5px 8px',
                        borderRadius: 10,
                        fontSize: 11,
                        fontWeight: 800,
                        border: isCurrent ? '2px solid var(--t)' : '1px solid #e4d5aa',
                        background: isSolved ? '#e6f8f1' : isCurrent ? '#fff' : '#fcfaf3',
                        color: isSolved ? '#197a56' : isCurrent ? 'var(--t)' : '#7b8a90'
                      }}
                    >
                      <div>
                        يوم {item.day} {isSolved ? '✅' : isCurrent ? '📍' : '🔒'}
                      </div>
                      <div style={{ fontSize: 10, opacity: 0.85 }}>{item.level}</div>
                    </div>
                  );
                })}
              </div>

              <p style={{ fontSize: 18, fontWeight: 800, margin: '8px 0 12px', color: 'var(--ink)' }}>
                {currentDailyChallenge.question}
              </p>

              <div id="daily" className="options">
                {currentDailyChallenge.options.map((o, i) => {
                  const isCorrectOpt = i === currentDailyChallenge.answer;
                  const isWrongChosen = dailyWrongChoices.includes(i);
                  const isSolved = dailySolvedTime !== null;

                  let btnClass = 'option';
                  if (isSolved && isCorrectOpt) btnClass += ' ok';
                  else if (isWrongChosen) btnClass += ' bad';

                  return (
                    <button
                      key={i}
                      disabled={isSolved || isWrongChosen}
                      className={btnClass}
                      onClick={() => handleAnswerDailyChallenge(i)}
                    >
                      {OPTION_LABELS[i]} {o}
                    </button>
                  );
                })}
              </div>

              {dailySolvedTime === null && dailyWrongChoices.length > 0 && (
                <div
                  className="note"
                  style={{
                    background: '#fff0f2',
                    borderColor: '#f3c2c8',
                    color: '#a12834',
                    marginTop: 10,
                    fontWeight: 700
                  }}
                >
                  ❌ إجابة غير صحيحة! العداد لا يزال يحسب الوقت (⏱️ {formatStopwatch(dailyElapsedSec)}) — فكّر جيدًا وحاول مرة أخرى للوصول إلى الحل الصحيح!
                </div>
              )}

              {dailySolvedTime !== null && (
                <div
                  className="explain"
                  style={{ marginTop: 12, background: '#e8f8f0', border: '1px solid #9adbc0' }}
                >
                  <div style={{ fontWeight: 800, color: '#146c47', marginBottom: 4 }}>
                    ✅ أحسنت! وصلت إلى الحل الصحيح خلال ({dailySolvedTime} ثانية) من المحاولة رقم (
                    {dailyAttempts}).
                  </div>
                  <div style={{ marginBottom: 6 }}>
                    <b>💡 شرح القاعدة:</b> {currentDailyChallenge.explanation}
                  </div>
                  <div
                    style={{
                      background: '#fff',
                      padding: '8px 12px',
                      borderRadius: 10,
                      border: '1px dashed #299d82',
                      fontSize: 13,
                      color: '#0d5960',
                      fontWeight: 800
                    }}
                  >
                    🔒 تم إغلاق هذا التحدي بعد حلّه، وسيفتح لك السؤال التالي الأصعب تلقائيًا بعد مرور 24 ساعة من وقت إجابتك (المتبقي:{' '}
                    {String(remHours).padStart(2, '0')}:{String(remMinutes).padStart(2, '0')}:
                    {String(remSeconds).padStart(2, '0')}).
                  </div>
                  <div style={{ marginTop: 8, display: 'flex', gap: 8, alignItems: 'center' }}>
                    <button
                      className="btn gold"
                      style={{ padding: '6px 14px', fontSize: 13, display: 'inline-flex', alignItems: 'center', gap: 6 }}
                      onClick={() => fireCelebratoryFireworks()}
                    >
                      🎆 إطلاق ألعاب نارية احتفالية
                    </button>
                  </div>
                </div>
              )}

              {isTeacherAdmin && (
                <div
                  style={{
                    marginTop: 12,
                    paddingTop: 10,
                    borderTop: '1px dashed #e6d4a2',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}
                >
                  <small style={{ color: '#6b582d', fontWeight: 700 }}>
                    🔑 أدوات المعلم السريعة:
                  </small>
                  <button
                    className="btn gold"
                    style={{ padding: '5px 12px', fontSize: 12 }}
                    onClick={handleAdminUnlockNextDaily}
                  >
                    ⏭️ فتح السؤال التالي فورًا (تجاوز قفل الـ 24 ساعة للمعلم)
                  </button>
                </div>
              )}
            </section>
          </main>

          <footer>
            <p>♥</p>
            <p>
              <b>إعداد وتنفيذ: المعلم / مساعد سليمان الصخري</b>
            </p>
            <small>جميع الحقوق محفوظة © 1448هـ – 2026/2027م</small>
          </footer>
        </div>
      )}

      {/* ===================================================================== */}
      {/* NAFES PROGRESSIVE STAGES MODAL (Unit 1 -> Unit 2 -> Unit 3 -> Stage 4) */}
      {/* ===================================================================== */}
      <div
        id="nafesStagesModal"
        className={`modal ${activeModal === 'nafesStagesModal' ? 'show' : ''}`}
        onClick={e => {
          if (e.target === e.currentTarget) setActiveModal(null);
        }}
      >
        <div className="dialog">
          <div className="head" style={{ background: 'linear-gradient(135deg,#b57c00,#e59812)' }}>
            <h2>🏆 مراحل اختبار نافس المتجدد (لا يتكرر بعد الحل)</h2>
            <button className="close" onClick={() => setActiveModal(null)}>
              ×
            </button>
          </div>
          <div className="body">
            <p className="sub">
              عند إتمام كل مرحلة من اختبارات نافس، تُحفظ نتيجتك ولا تعود لنفس الاختبار مرة أخرى، بل تفتح لك المرحلة التالية بنص جديد و32 سؤالًا جديدًا (10 فهم قرائي + 10 قواعد من النص + 10 صح وخطأ + 2 سؤال مقالي):
            </p>
            <div style={{ display: 'grid', gap: 12 }}>
              {NAFES_STAGES.map((stg, idx) => {
                const isCompleted = completedNafesStages.includes(stg.id);
                const isUnlocked = idx <= currentNafesStageIdx || isTeacherAdmin;
                const isCurrentNext = idx === currentNafesStageIdx && !isCompleted;

                return (
                  <div
                    key={stg.id}
                    style={{
                      border: isCurrentNext
                        ? '2px solid #e59812'
                        : isCompleted
                        ? '2px solid #299d82'
                        : '1px solid #d6e7e5',
                      background: isCompleted
                        ? '#f2fbf7'
                        : isCurrentNext
                        ? '#fffdf5'
                        : '#f8fafb',
                      borderRadius: 18,
                      padding: 16,
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      gap: 12,
                      opacity: isUnlocked ? 1 : 0.65
                    }}
                  >
                    <div style={{ flex: 1, minWidth: 240 }}>
                      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                        <span
                          style={{
                            background: isCompleted
                              ? '#299d82'
                              : isCurrentNext
                              ? '#f7b832'
                              : '#cad8d8',
                            color: isCompleted ? '#fff' : '#174c59',
                            padding: '2px 10px',
                            borderRadius: 999,
                            fontSize: 12,
                            fontWeight: 800
                          }}
                        >
                          {isCompleted
                            ? '✅ مكتمل (تم الاجتياز)'
                            : isCurrentNext
                            ? '🔥 المرحلة الحالية المتاحة'
                            : '🔒 يفتح بعد إتمام المرحلة السابقة'}
                        </span>
                        <small style={{ color: 'var(--mut)', fontWeight: 700 }}>
                          {stg.unitLabel}
                        </small>
                      </div>
                      <h4 style={{ margin: '4px 0', fontSize: 18 }}>{stg.title}</h4>
                      <div style={{ fontSize: 13, color: 'var(--mut)' }}>
                        📖 {stg.passage.title} — (32 سؤالًا: 10 فهم + 10 قواعد + 10 صح/خطأ + 2 مقالي)
                      </div>
                    </div>

                    <div>
                      {isCompleted && !isTeacherAdmin ? (
                        <button className="btn light" disabled>
                          ✅ تم إتمام هذه المرحلة
                        </button>
                      ) : isUnlocked ? (
                        <button
                          className="btn gold"
                          onClick={() => launchNafesStage(stg, idx)}
                        >
                          {isCompleted ? 'فتح (صلاحية معلم)' : 'ابدأ الاختبار الآن ←'}
                        </button>
                      ) : (
                        <button className="btn light" disabled>
                          🔒 مغلق حتى إتمام المرحلة {idx}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* ===================================================================== */}
      {/* TEACHER / ADMIN DATABASE CONTROL PANEL MODAL                          */}
      {/* ===================================================================== */}
      <div
        id="adminModal"
        className={`modal ${activeModal === 'adminModal' ? 'show' : ''}`}
        onClick={e => {
          if (e.target === e.currentTarget) setActiveModal(null);
        }}
      >
        <div className="dialog" style={{ width: 'min(920px, 100%)' }}>
          <div className="head" style={{ background: 'linear-gradient(135deg,#0f4c5c,#1b7a8c)' }}>
            <h2>⚙️ لوحة تحكم المعلم وقاعدة البيانات السحابية</h2>
            <button className="close" onClick={() => setActiveModal(null)}>
              ×
            </button>
          </div>
          <div className="body">
            {!isTeacherAdmin ? (
              <div style={{ textAlign: 'center', padding: '16px 8px' }}>
                <h3>🔐 دخول المعلم المشرف (أ. مساعد سليمان الصخري)</h3>
                <p className="sub">
                  يمكنك الدخول عبر حساب Google المعتمد ({ADMIN_EMAIL}) أو عبر رمز المعلم السريع لإدارة قاعدة البيانات والتحديات والصلاحيات:
                </p>
                <div
                  style={{
                    maxWidth: 380,
                    margin: '16px auto',
                    display: 'grid',
                    gap: 10,
                    background: '#f5fbf9',
                    padding: 18,
                    borderRadius: 18,
                    border: '1px solid #cfe6e2'
                  }}
                >
                  <button className="btn primary full" onClick={handleGoogleAdminLogin}>
                    🔑 تسجيل الدخول بحساب Google للمعلم
                  </button>
                  <div style={{ fontSize: 13, color: 'var(--mut)', margin: '4px 0' }}>
                    — أو أدخل رمز المعلم السريع (الافتراضي: 1448) —
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <input
                      type="password"
                      placeholder="رمز المعلم..."
                      value={adminPinInput}
                      onChange={e => setAdminPinInput(e.target.value)}
                      style={{
                        flex: 1,
                        padding: '9px 12px',
                        borderRadius: 12,
                        border: '1px solid #c5deda'
                      }}
                    />
                    <button className="btn green" onClick={handlePinAdminLogin}>
                      دخول
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    gap: 8,
                    marginBottom: 14
                  }}
                >
                  <div className="tabRow" style={{ marginBottom: 0 }}>
                    <button
                      className={`btn ${adminTab === 'students' ? 'primary' : 'light'}`}
                      onClick={() => setAdminTab('students')}
                    >
                      🐎 إدارة الطلاب والفرسان ({leaderboardStudents.length})
                    </button>
                    <button
                      className={`btn ${adminTab === 'challenges' ? 'primary' : 'light'}`}
                      onClick={() => setAdminTab('challenges')}
                    >
                      🎯 إضافة وإدارة التحديات ({allDailyChallenges.length})
                    </button>
                    <button
                      className={`btn ${adminTab === 'settings' ? 'primary' : 'light'}`}
                      onClick={() => setAdminTab('settings')}
                    >
                      🛡️ الصلاحيات والتحديثات
                    </button>
                    <button
                      className={`btn ${adminTab === 'feedback' ? 'primary' : 'light'}`}
                      onClick={() => setAdminTab('feedback')}
                    >
                      💬 رسائل أولياء الأمور ({cloudFeedback.length})
                    </button>
                  </div>
                  <button
                    className="btn coral"
                    style={{ padding: '6px 12px', fontSize: 12 }}
                    onClick={() => {
                      setAdminUnlockedByPin(false);
                      if (firebaseUser) signOut(auth);
                    }}
                  >
                    تسجيل خروج المعلم
                  </button>
                </div>

                {/* TAB 1: STUDENTS & LEADERBOARD MANAGEMENT */}
                {adminTab === 'students' && (
                  <div>
                    <p className="sub">
                      تحكم في نقاط الطلاب، أو افتح لهم المرحلة التالية في نافس، أو تجاوز قفل الـ 24 ساعة لسؤال التحدي، أو أوقف/فعّل صلاحية أي طالب:
                    </p>
                    <div style={{ overflowX: 'auto' }}>
                      <table
                        style={{
                          width: '100%',
                          borderCollapse: 'collapse',
                          fontSize: 13
                        }}
                      >
                        <thead>
                          <tr style={{ background: '#eef7f5', textAlign: 'right' }}>
                            <th style={{ padding: 8 }}>#</th>
                            <th style={{ padding: 8 }}>الطالب</th>
                            <th style={{ padding: 8 }}>الفصل</th>
                            <th style={{ padding: 8 }}>النقاط</th>
                            <th style={{ padding: 8 }}>مرحلة نافس</th>
                            <th style={{ padding: 8 }}>يوم التحدي</th>
                            <th style={{ padding: 8 }}>الحالة</th>
                            <th style={{ padding: 8 }}>إجراءات المعلم</th>
                          </tr>
                        </thead>
                        <tbody>
                          {leaderboardStudents.map((st, idx) => (
                            <tr key={st.profileId} style={{ borderBottom: '1px solid #e5efed' }}>
                              <td style={{ padding: 8, fontWeight: 800 }}>{idx + 1}</td>
                              <td style={{ padding: 8, fontWeight: 800 }}>{st.name}</td>
                              <td style={{ padding: 8 }}>{st.cls}</td>
                              <td style={{ padding: 8, fontWeight: 800, color: '#197a56' }}>
                                {st.points}
                              </td>
                              <td style={{ padding: 8 }}>المرحلة {st.nafesStageIndex + 1}</td>
                              <td style={{ padding: 8 }}>اليوم {st.dailyCurrentIndex + 1}</td>
                              <td style={{ padding: 8 }}>
                                {st.isBlocked ? (
                                  <span style={{ color: '#b4232c', fontWeight: 800 }}>موقوف</span>
                                ) : (
                                  <span style={{ color: '#197a56', fontWeight: 800 }}>نشط</span>
                                )}
                              </td>
                              <td style={{ padding: 8, display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                                <button
                                  className="btn green"
                                  style={{ padding: '4px 8px', fontSize: 11 }}
                                  onClick={() =>
                                    handleAdminModifyStudent(st, { points: st.points + 20 })
                                  }
                                >
                                  +20 نقطة
                                </button>
                                <button
                                  className="btn gold"
                                  style={{ padding: '4px 8px', fontSize: 11 }}
                                  onClick={() =>
                                    handleAdminModifyStudent(st, {
                                      dailyCurrentIndex: st.dailyCurrentIndex + 1,
                                      dailyNextUnlockMs: 0
                                    })
                                  }
                                >
                                  فتح تحدي الغد
                                </button>
                                <button
                                  className="btn blue"
                                  style={{ padding: '4px 8px', fontSize: 11 }}
                                  onClick={() =>
                                    handleAdminModifyStudent(st, {
                                      nafesStageIndex: Math.min(
                                        NAFES_STAGES.length - 1,
                                        st.nafesStageIndex + 1
                                      )
                                    })
                                  }
                                >
                                  ترقية مرحلة نافس
                                </button>
                                <button
                                  className="btn coral"
                                  style={{ padding: '4px 8px', fontSize: 11 }}
                                  onClick={() =>
                                    handleAdminModifyStudent(st, { isBlocked: !st.isBlocked })
                                  }
                                >
                                  {st.isBlocked ? 'تفعيل' : 'إيقاف'}
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* TAB 2: ADD & MANAGE DAILY CHALLENGES */}
                {adminTab === 'challenges' && (
                  <div>
                    <div
                      style={{
                        background: '#f7fbfa',
                        border: '1px solid #d4eae6',
                        borderRadius: 16,
                        padding: 14,
                        marginBottom: 16
                      }}
                    >
                      <h4 style={{ margin: '0 0 10px', color: 'var(--t)' }}>
                        ➕ إضافة سؤال تحدٍّ جديد إلى قاعدة البيانات
                      </h4>
                      <div className="grid">
                        <div className="field">
                          <label>رقم اليوم في السلسلة</label>
                          <input
                            type="number"
                            value={newChDay}
                            onChange={e => setNewChDay(Number(e.target.value))}
                          />
                        </div>
                        <div className="field">
                          <label>مستوى الصعوبة</label>
                          <select
                            value={newChLevel}
                            onChange={e =>
                              setNewChLevel(e.target.value as DailyChallengeItem['level'])
                            }
                          >
                            <option value="سهل">سهل</option>
                            <option value="متوسط">متوسط</option>
                            <option value="صعب">صعب</option>
                            <option value="صعب جدًا">صعب جدًا</option>
                            <option value="تحدي العباقرة (صعب جدًا+)">
                              تحدي العباقرة (صعب جدًا+)
                            </option>
                          </select>
                        </div>
                        <div className="field">
                          <label>النقاط الممنوحة</label>
                          <input
                            type="number"
                            value={newChPoints}
                            onChange={e => setNewChPoints(Number(e.target.value))}
                          />
                        </div>
                        <div className="field">
                          <label>الوحدة والدرس المرتبط</label>
                          <input
                            value={newChTopic}
                            onChange={e => setNewChTopic(e.target.value)}
                            placeholder="مثال: الوحدة الثانية — الأفعال الناسخة"
                          />
                        </div>
                        <div className="field" style={{ gridColumn: '1/-1' }}>
                          <label>نص سؤال التحدي</label>
                          <input
                            value={newChQuestion}
                            onChange={e => setNewChQuestion(e.target.value)}
                            placeholder="اكتب السؤال الصعب هنا..."
                          />
                        </div>
                        <div className="field">
                          <label>الخيار (أ)</label>
                          <input value={newChOpt0} onChange={e => setNewChOpt0(e.target.value)} />
                        </div>
                        <div className="field">
                          <label>الخيار (ب)</label>
                          <input value={newChOpt1} onChange={e => setNewChOpt1(e.target.value)} />
                        </div>
                        <div className="field">
                          <label>الخيار (ج)</label>
                          <input value={newChOpt2} onChange={e => setNewChOpt2(e.target.value)} />
                        </div>
                        <div className="field">
                          <label>الخيار (د)</label>
                          <input value={newChOpt3} onChange={e => setNewChOpt3(e.target.value)} />
                        </div>
                        <div className="field">
                          <label>الخيار الصحيح</label>
                          <select
                            value={newChAnswer}
                            onChange={e => setNewChAnswer(Number(e.target.value))}
                          >
                            <option value={0}>أ (الخيار الأول)</option>
                            <option value={1}>ب (الخيار الثاني)</option>
                            <option value={2}>ج (الخيار الثالث)</option>
                            <option value={3}>د (الخيار الرابع)</option>
                          </select>
                        </div>
                        <div className="field">
                          <label>شرح القاعدة والتغذية الراجعة</label>
                          <input
                            value={newChExplain}
                            onChange={e => setNewChExplain(e.target.value)}
                            placeholder="تفسير الإجابة الصحيحة..."
                          />
                        </div>
                      </div>
                      <div className="actions">
                        <button className="btn green" onClick={handleAddCustomChallenge}>
                          💾 حفظ وإضافة التحدي لقاعدة البيانات
                        </button>
                      </div>
                    </div>

                    <h4>📋 قائمة التحديات المضافة من المعلم ({customChallenges.length}):</h4>
                    {customChallenges.length === 0 ? (
                      <div className="note">
                        تعمل حاليًا التحديات العشرة الأساسية المتدرجة، وأي تحدٍّ تضيفه هنا سيظهر للطلاب مباشرة.
                      </div>
                    ) : (
                      customChallenges.map(c => (
                        <div key={c.docId} className="commonCard" style={{ marginBottom: 8 }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <b>
                              اليوم {c.day} ({c.level} — +{c.points} نقطة): {c.question}
                            </b>
                            <button
                              className="btn coral"
                              style={{ padding: '4px 10px', fontSize: 12 }}
                              onClick={() => handleDeleteCustomChallenge(c.docId)}
                            >
                              حذف
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {/* TAB 3: APP SETTINGS & PERMISSIONS */}
                {adminTab === 'settings' && (
                  <div className="grid">
                    <div className="field" style={{ gridColumn: '1/-1' }}>
                      <label>📣 رسالة الإعلان والتحديثات في أعلى التطبيق للطلاب</label>
                      <input
                        value={appSettings.announcement}
                        onChange={e =>
                          setAppSettings(s => ({ ...s, announcement: e.target.value }))
                        }
                      />
                    </div>
                    <div className="field">
                      <label>🔒 قفل سؤال التحدي التالي لمدة 24 ساعة بعد الحل</label>
                      <select
                        value={appSettings.enforce24hChallengeLock ? 'yes' : 'no'}
                        onChange={e =>
                          setAppSettings(s => ({
                            ...s,
                            enforce24hChallengeLock: e.target.value === 'yes'
                          }))
                        }
                      >
                        <option value="yes">مفعّل (لا يفتح التالي إلا بعد 24 ساعة من الحل)</option>
                        <option value="no">مفتوح (السماح بالانتقال الفوري)</option>
                      </select>
                    </div>
                    <div className="field">
                      <label>🏆 صلاحية دخول اختبارات نافس</label>
                      <select
                        value={appSettings.enableNafes ? 'yes' : 'no'}
                        onChange={e =>
                          setAppSettings(s => ({ ...s, enableNafes: e.target.value === 'yes' }))
                        }
                      >
                        <option value="yes">متاح لجميع الطلاب</option>
                        <option value="no">مغلق مؤقتًا</option>
                      </select>
                    </div>
                    <div className="field">
                      <label>🎮 صلاحية مركز الألعاب اللغوية</label>
                      <select
                        value={appSettings.enableGames ? 'yes' : 'no'}
                        onChange={e =>
                          setAppSettings(s => ({ ...s, enableGames: e.target.value === 'yes' }))
                        }
                      >
                        <option value="yes">متاح لجميع الطلاب</option>
                        <option value="no">مغلق مؤقتًا</option>
                      </select>
                    </div>
                    <div className="field">
                      <label>🔑 رمز الدخول السريع للمعلم (PIN)</label>
                      <input
                        value={appSettings.adminPin}
                        maxLength={12}
                        onChange={e => setAppSettings(s => ({ ...s, adminPin: e.target.value }))}
                      />
                    </div>
                    <div className="actions" style={{ gridColumn: '1/-1' }}>
                      <button
                        className="btn green"
                        onClick={() => handleSaveSettingsToCloud(appSettings)}
                      >
                        💾 حفظ التحديثات والصلاحيات في قاعدة البيانات
                      </button>
                    </div>
                  </div>
                )}

                {/* TAB 4: PARENT FEEDBACK MODERATION */}
                {adminTab === 'feedback' && (
                  <div>
                    <p className="sub">إدارة مقترحات أولياء الأمور والموافقة على نشرها:</p>
                    {cloudFeedback.length === 0 ? (
                      <div className="note">لا توجد رسائل جديدة في قاعدة البيانات بعد.</div>
                    ) : (
                      cloudFeedback.map((fb, i) => (
                        <div
                          key={fb.id || i}
                          className="feedback"
                          style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center'
                          }}
                        >
                          <div>
                            <b>
                              {fb.role} ({fb.cls})
                            </b>
                            <small>{fb.status}</small>
                            <div>{fb.text}</div>
                          </div>
                          <button
                            className={`btn ${
                              fb.status === 'معتمد ومنشور' ? 'light' : 'green'
                            }`}
                            style={{ padding: '6px 12px', fontSize: 12 }}
                            onClick={() => handleToggleFeedbackApproval(fb)}
                          >
                            {fb.status === 'معتمد ومنشور' ? 'إلغاء النشر' : '✅ اعتماد ونشر'}
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Error Remediation Clinic Modal (علاج الأخطاء) */}
      <div
        id="mistakesModal"
        className={`modal ${activeModal === 'mistakesModal' ? 'show' : ''}`}
        onClick={e => {
          if (e.target === e.currentTarget) setActiveModal(null);
        }}
      >
        <div className="dialog">
          <div className="head" style={{ background: 'linear-gradient(135deg,#b93b40,#e0565b)' }}>
            <h2>🩺 عيادة لغتي — تشخيص وعلاج الأخطاء</h2>
            <button className="close" onClick={() => setActiveModal(null)}>
              ×
            </button>
          </div>
          <div className="body">
            <div className="tabRow">
              <button
                className={`btn ${mistakesTab === 'myMistakes' ? 'coral' : 'light'}`}
                onClick={() => setMistakesTab('myMistakes')}
              >
                📓 دفتر أخطائي ({studentMistakes.length})
              </button>
              <button
                className={`btn ${mistakesTab === 'commonMistakes' ? 'primary' : 'light'}`}
                onClick={() => setMistakesTab('commonMistakes')}
              >
                💡 الأخطاء اللغوية الشائعة وعلاجها
              </button>
            </div>

            {mistakesTab === 'myMistakes' ? (
              <div>
                <div className="quizMeta" style={{ background: '#fff5f5' }}>
                  <span>
                    📌 الأخطاء المتبقية: <b>{studentMistakes.length}</b>
                  </span>
                  <span>
                    ✅ أخطاء تمت معالجتها وإتقانها: <b>{currentProfile?.resolvedMistakesCount || 0}</b>
                  </span>
                </div>

                {studentMistakes.length > 0 ? (
                  <>
                    <p className="sub">
                      هذه الأسئلة أخطأت فيها سابقًا أثناء التدريبات. راجع الشرح العلاجي لكل سؤال، ثم اضغط على <b>«ابدأ جلسة العلاج»</b> لإعادة الإجابة عنها؛ وعند إجابتك بشكل صحيح ستختفي من قائمة الأخطاء وتكسب نقاطًا وشارة <b>«معالج الأخطاء»</b>!
                    </p>
                    <div className="actions" style={{ marginBottom: 16 }}>
                      <button className="btn green" onClick={startMyMistakesRemedialQuiz}>
                        🚀 ابدأ جلسة علاج أخطائي ({studentMistakes.length} أسئلة)
                      </button>
                    </div>
                    <div>
                      {studentMistakes.map((m, idx) => (
                        <div key={idx} className="mistakeItem">
                          <div className="mistakeMeta">
                            <span className="mistakeTag">{m.sourceTitle}</span>
                            <span>المستوى: {m.question[4] || 'متنوع'}</span>
                            <span>التاريخ: {m.timestamp}</span>
                          </div>
                          <h4>
                            {idx + 1}. {m.question[0]}
                          </h4>
                          <div style={{ fontSize: 14, color: '#b4383d', marginBottom: 4 }}>
                            ❌ إجابتك السابقة: «{m.question[1][m.wrongChoiceIndex]}»
                          </div>
                          <div
                            style={{
                              fontSize: 14,
                              color: '#1f7a58',
                              fontWeight: 700,
                              marginBottom: 6
                            }}
                          >
                            ✅ الصواب: «{m.question[1][m.question[2]]}»
                          </div>
                          <div className="explain" style={{ marginTop: 6 }}>
                            <b>💊 العلاج والقاعدة:</b> {m.question[3]}
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="score" style={{ background: '#f2fbf7' }}>
                    <strong style={{ fontSize: 42 }}>🎉 سجلّك خالٍ من الأخطاء!</strong>
                    <p>
                      أحسنت يا بطل! ليس لديك أي أخطاء متراكمة حاليًا. كلما أخطأت في سؤال أثناء حل الدروس أو الاختبارات، سيظهر هنا تلقائيًا لمساعدتك على معالجته.
                    </p>
                    <div className="actions" style={{ justifyContent: 'center' }}>
                      <button
                        className="btn primary"
                        onClick={() => setMistakesTab('commonMistakes')}
                      >
                        استعرض الأخطاء اللغوية الشائعة
                      </button>
                      <button className="btn green" onClick={startCommonMistakesQuiz}>
                        ابدأ تدريب الأخطاء الشائعة
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div>
                <p className="sub">
                  ملخص لأبرز الأخطاء الإملائية والنحوية الشائعة بين طلاب الصف الأول المتوسط مع القاعدة العلاجية لكل منها:
                </p>
                <div className="actions" style={{ marginBottom: 16 }}>
                  <button className="btn green" onClick={startCommonMistakesQuiz}>
                    📝 اختبر نفسك في علاج الأخطاء الشائعة (6 أسئلة)
                  </button>
                </div>
                {COMMON_MISTAKES_GUIDES.map((g, i) => (
                  <div key={i} className="commonCard">
                    <h4 style={{ margin: '0 0 8px', color: 'var(--t)' }}>📌 {g.title}</h4>
                    <div style={{ display: 'grid', gap: 6, fontSize: 14, marginBottom: 8 }}>
                      <div
                        style={{
                          background: '#fff0f2',
                          padding: '6px 10px',
                          borderRadius: 10,
                          color: '#9e2a35'
                        }}
                      >
                        <b>❌ خطأ شائع:</b> {g.wrong}
                      </div>
                      <div
                        style={{
                          background: '#e8f8f0',
                          padding: '6px 10px',
                          borderRadius: 10,
                          color: '#1b6b4a'
                        }}
                      >
                        <b>✅ الصواب:</b> {g.right}
                      </div>
                    </div>
                    <div style={{ fontSize: 14, color: 'var(--ink)' }}>
                      <b>💡 القاعدة العلاجية:</b> {g.rule}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Profile Modal */}
      <div
        id="profileModal"
        className={`modal ${activeModal === 'profileModal' ? 'show' : ''}`}
        onClick={e => {
          if (e.target === e.currentTarget) setActiveModal(null);
        }}
      >
        <div className="dialog">
          <div className="head">
            <h2>👤 ملف الطالب</h2>
            <button className="close" onClick={() => setActiveModal(null)}>
              ×
            </button>
          </div>
          <div className="body">
            {profileMode === 'chooser' ? (
              <div id="chooser">
                <p>اختر ملفًا محفوظًا على هذا الجهاز، أو سجّل دخولك من جهاز آخر، أو أنشئ ملفًا جديدًا:</p>
                <div id="profiles" className="options">
                  {Object.keys(profiles).length > 0 ? (
                    Object.keys(profiles).map(id => {
                      const x = profiles[id];
                      return (
                        <button
                          key={id}
                          className={`option ${activeId === id ? 'ok' : ''}`}
                          onClick={() => {
                            setActiveId(id);
                            syncProfileToCloud(id, x);
                            setActiveModal(null);
                          }}
                        >
                          👤 {x.name} — الفصل {x.cls} — ⭐ {x.points} نقطة — 🏅 {x.badges.length} شارات
                        </button>
                      );
                    })
                  ) : (
                    <div className="note">لا توجد ملفات محفوظة محليًا على هذا المتصفح. يمكنك تسجيل الدخول باسمك ورمزك أو إنشاء ملف جديد.</div>
                  )}
                </div>
                <div className="actions" style={{ marginTop: 14 }}>
                  <button className="btn green" onClick={() => setProfileMode('login')}>
                    📲 تسجيل دخول طالب من جهاز آخر (بالاسم والرمز)
                  </button>
                  <button className="btn primary" onClick={() => setProfileMode('create')}>
                    ➕ إنشاء ملف طالب جديد
                  </button>
                </div>
                <div className="note" style={{ marginTop: 12 }}>
                  ✨ جميع ملفات الطلاب ودرجاتهم ونقاطهم في سباق الفرسان متزامنة سحابيًا عبر قاعدة بيانات Firestore.
                </div>
              </div>
            ) : profileMode === 'login' ? (
              <div id="studentLogin">
                <p className="sub">
                  إذا كنت قد أنشأت ملفك مسبقًا من هاتف أو حاسوب آخر، اكتب اسمك ورمزك السري (4 أرقام) لتحميل درجاتك ونقاطك فورًا:
                </p>
                <div className="grid">
                  <div className="field" style={{ gridColumn: '1/-1' }}>
                    <label>اسم الطالب المسجل</label>
                    <input
                      placeholder="اكتب اسمك كما سجلته أول مرة..."
                      value={loginName}
                      onChange={e => setLoginName(e.target.value)}
                    />
                  </div>
                  <div className="field" style={{ gridColumn: '1/-1' }}>
                    <label>الرمز السري الخاص بك (4 أرقام)</label>
                    <input
                      type="password"
                      inputMode="numeric"
                      maxLength={4}
                      placeholder="مثال: 1234"
                      value={loginPin}
                      onChange={e => setLoginPin(e.target.value)}
                    />
                  </div>
                </div>
                <div className="actions" style={{ marginTop: 14 }}>
                  <button className="btn green" onClick={handleStudentLoginFromAnyDevice}>
                    🚀 دخول وتحميل ملفي السحابي
                  </button>
                  <button className="btn light" onClick={() => setProfileMode('chooser')}>
                    رجوع
                  </button>
                </div>
              </div>
            ) : (
              <div id="create">
                <div className="grid">
                  <div className="field">
                    <label>اسم الطالب</label>
                    <input
                      maxLength={40}
                      placeholder="مثال: محمد أحمد"
                      value={newName}
                      onChange={e => setNewName(e.target.value)}
                    />
                  </div>
                  <div className="field">
                    <label>رمز الطالب من 4 أرقام</label>
                    <input
                      inputMode="numeric"
                      maxLength={4}
                      placeholder="1234"
                      value={newCode}
                      onChange={e => setNewCode(e.target.value)}
                    />
                  </div>
                  <div className="field">
                    <label>الصف</label>
                    <select>
                      <option>أول متوسط</option>
                    </select>
                  </div>
                  <div className="field">
                    <label>الفصل</label>
                    <select value={newCls} onChange={e => setNewCls(e.target.value)}>
                      <option>أ</option>
                      <option>ب</option>
                      <option>ج</option>
                    </select>
                  </div>
                </div>
                <div className="actions">
                  <button className="btn green" onClick={handleCreateProfile}>
                    حفظ الملف
                  </button>
                  <button className="btn light" onClick={() => setProfileMode('chooser')}>
                    رجوع
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Badges Modal */}
      <div
        id="badgesModal"
        className={`modal ${activeModal === 'badgesModal' ? 'show' : ''}`}
        onClick={e => {
          if (e.target === e.currentTarget) setActiveModal(null);
        }}
      >
        <div className="dialog" style={{ maxWidth: 520 }}>
          <div className="head">
            <h2>🏅 شارات وإنجازات الطالب</h2>
            <button className="close" onClick={() => setActiveModal(null)}>
              ×
            </button>
          </div>
          <div className="body">
            {currentProfile ? (
              <>
                <p>
                  الطالب: <b>{currentProfile.name}</b> • الإجابات الصحيحة:{' '}
                  <b>{currentProfile.correct}</b> • المحاولات: <b>{currentProfile.attempts}</b>
                </p>
                {currentProfile.badges.length > 0 ? (
                  <div className="options">
                    {currentProfile.badges.map((b, i) => (
                      <div key={i} className="option ok">
                        🏅 <b>شارة {b}</b>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="note">
                    لم تحصل على شارات بعد. أكمل الدروس بدرجة كاملة للحصول على شارة «إتقان»، أو عالج أخطاءك للحصول على شارة «معالج الأخطاء»، أو تفوّق في مراحل نافس للحصول على شارة «فارس نافس»!
                  </div>
                )}
              </>
            ) : (
              <div className="note">يرجى اختيار أو إنشاء ملف طالب أولًا.</div>
            )}
          </div>
        </div>
      </div>

      {/* Lesson Modal (الدروس والاختبار الشامل لكل وحدة) */}
      <div
        id="lessonModal"
        className={`modal ${activeModal === 'lessonModal' ? 'show' : ''}`}
        onClick={e => {
          if (e.target === e.currentTarget) setActiveModal(null);
        }}
      >
        <div className="dialog">
          <div
            className="head"
            style={{
              background:
                selectedUnit === 1
                  ? 'linear-gradient(135deg,#126b70,#299d82)'
                  : selectedUnit === 2
                  ? 'linear-gradient(135deg,#7142b9,#9562dc)'
                  : 'linear-gradient(135deg,#2377b8,#3d96dd)'
            }}
          >
            <h2>
              📚 {selectedUnit === 1 ? 'الوحدة الأولى: القيم الإسلامية' : selectedUnit === 2 ? 'الوحدة الثانية: الأعلام' : 'الوحدة الثالثة: وطني'} — الدروس والتقويم
            </h2>
            <button className="close" onClick={() => setActiveModal(null)}>
              ×
            </button>
          </div>
          <div className="body">
            {/* Quick Unit Tabs inside Modal */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
              <button
                className={`btn ${selectedUnit === 1 ? 'green' : 'light'}`}
                style={{ padding: '6px 14px', fontSize: 13 }}
                onClick={() => setSelectedUnit(1)}
              >
                🕌 الوحدة 1: القيم الإسلامية
              </button>
              <button
                className={`btn ${selectedUnit === 2 ? 'purple' : 'light'}`}
                style={{ padding: '6px 14px', fontSize: 13 }}
                onClick={() => setSelectedUnit(2)}
              >
                📚 الوحدة 2: الأعلام
              </button>
              <button
                className={`btn ${selectedUnit === 3 ? 'blue' : 'light'}`}
                style={{ padding: '6px 14px', fontSize: 13 }}
                onClick={() => setSelectedUnit(3)}
              >
                🇸🇦 الوحدة 3: وطني
              </button>
            </div>

            <p className="sub">
              اختر الدرس، وسيعرض التطبيق تدريبات تفاعلية مستخرجة من بنك الأسئلة دون تكرار، أو ابدأ <b>التقويم الشامل للوحدة (10 أسئلة)</b>:
            </p>

            {(() => {
              const currentLessons =
                selectedUnit === 1
                  ? UNIT1_LESSONS
                  : selectedUnit === 2
                  ? UNIT2_LESSONS
                  : UNIT3_LESSONS;
              const unitInfo = U[selectedUnit] || U[1];
              const unitBg =
                selectedUnit === 1
                  ? '#effbf8'
                  : selectedUnit === 2
                  ? '#f8f3ff'
                  : '#eff8ff';
              const unitBorder =
                selectedUnit === 1
                  ? '#299d82'
                  : selectedUnit === 2
                  ? '#8051cf'
                  : '#378fd8';

              return (
                <div className="lessonGrid">
                  {currentLessons.map(lesson => (
                    <button
                      key={lesson.id}
                      className="lessonCard"
                      onClick={() => handleStartLesson(lesson.title, lesson.bank)}
                    >
                      <span>{lesson.icon}</span>
                      <b>{lesson.title}</b>
                      <small>{lesson.countText}</small>
                    </button>
                  ))}

                  {/* 10-Question Comprehensive Assessment for the Selected Unit */}
                  <button
                    className="lessonCard"
                    style={{
                      gridColumn: '1/-1',
                      background: unitBg,
                      borderColor: unitBorder,
                      borderWidth: 2,
                      padding: '18px 20px'
                    }}
                    onClick={() =>
                      startQuiz(
                        `الوحدة ${selectedUnit}: ${unitInfo.n} — تقويم شامل`,
                        unitInfo.q,
                        `الوحدة ${selectedUnit} (تقويم شامل - 10 أسئلة)`
                      )
                    }
                  >
                    <span style={{ fontSize: 32 }}>🌟</span>
                    <b style={{ fontSize: 18 }}>
                      التقويم الشامل للوحدة {selectedUnit} ({unitInfo.n})
                    </b>
                    <small style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)' }}>
                      10 أسئلة تقويمية شاملة لجميع مهارات ودروس وقواعد الوحدة
                    </small>
                  </button>
                </div>
              );
            })()}
          </div>
        </div>
      </div>

      {/* Quiz Modal */}
      <div
        id="quizModal"
        className={`modal ${activeModal === 'quizModal' ? 'show' : ''}`}
        onClick={e => {
          if (e.target === e.currentTarget) setActiveModal(null);
        }}
      >
        {quiz && (
          <div className="dialog">
            <div className="head">
              <h2 id="qtitle">{quiz.title}</h2>
              <button className="close" onClick={() => setActiveModal(null)}>
                ×
              </button>
            </div>
            <div className="body">
              <div className="quizMeta">
                <span id="qtype">{quiz.type}</span>
                <span id="qlevel">{quiz.qs[qi]?.[4] || 'متنوع'}</span>
                <span id="qnum">
                  السؤال {qi + 1} من {quiz.qs.length}
                </span>
              </div>
              <div className="bar">
                <i
                  id="qbar"
                  style={{
                    width: quizFinished ? '100%' : `${(qi / quiz.qs.length) * 100}%`
                  }}
                />
              </div>

              {!quizFinished ? (
                <div id="quiz">
                  {quiz.hasPassage && quiz.passageData && (
                    <div className="passage">
                      <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          marginBottom: showPassage ? 8 : 0
                        }}
                      >
                        <div>
                          <b style={{ fontSize: 17, color: 'var(--t)' }}>
                            📖 {quiz.passageData.title}
                          </b>
                          <small style={{ display: 'block', color: 'var(--mut)' }}>
                            ({quiz.passageData.genre}) — اقرأ النص بتركيز للإجابة عن الأسئلة
                          </small>
                        </div>
                        <button
                          className="btn light"
                          style={{ padding: '5px 12px', fontSize: 13 }}
                          onClick={() => setShowPassage(p => !p)}
                        >
                          {showPassage ? 'إخفاء النص ▲' : 'عرض النص ▼'}
                        </button>
                      </div>
                      {showPassage && (
                        <div
                          style={{
                            maxHeight: 220,
                            overflowY: 'auto',
                            paddingLeft: 6,
                            fontSize: 15,
                            lineHeight: 1.85
                          }}
                        >
                          {quiz.passageData.paragraphs.map((para, pIdx) => (
                            <p key={pIdx} style={{ margin: '0 0 8px' }}>
                              {para}
                            </p>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {(() => {
                    const z = quiz.qs[qi];
                    const isEssay = z[5] === 'essay';
                    return (
                      <>
                        <div className="q">
                          <h3>
                            {qi + 1}. {z[0]}
                          </h3>
                          {isEssay ? (
                            <>
                              <textarea
                                className="essayBox"
                                placeholder="اكتب إجابتك المقالية هنا من فهمك للنص والقواعد..."
                                disabled={isCurrentAnswered}
                                value={
                                  isCurrentAnswered ? currentQAnswer.essay || '' : essayDraft
                                }
                                onChange={e => setEssayDraft(e.target.value)}
                              />
                              <div className="essayHint">
                                اضغط على «إرسال الإجابة» لعرض النموذج الإرشادي واحتساب الدرجة.
                              </div>
                            </>
                          ) : (
                            <div className="options">
                              {z[1].map((o, i) => {
                                let cls = 'option';
                                if (isCurrentAnswered) {
                                  if (i === z[2]) cls += ' ok';
                                  else if (i === currentQAnswer.selected && i !== z[2])
                                    cls += ' bad';
                                }
                                return (
                                  <button
                                    key={i}
                                    className={cls}
                                    disabled={isCurrentAnswered}
                                    onClick={() => handleAnswerMcq(i)}
                                  >
                                    {OPTION_LABELS[i] || `${i + 1}-`} {o}
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          {isCurrentAnswered && (
                            <div className="explain">
                              {isEssay ? (
                                <>
                                  <b>📝 تم تسجيل إجابتك المقالية.</b> قارن إجابتك بالنموذج الإرشادي:
                                  <br />
                                  {z[3]}
                                </>
                              ) : (
                                <>
                                  <b>
                                    {currentQAnswer.selected === z[2]
                                      ? '✅ أحسنت! '
                                      : '❌ راجع إجابتك (تم حفظ السؤال في دفتر أخطائك لمعالجته). '}
                                  </b>
                                  {z[3]}
                                </>
                              )}
                              <br />
                              <button
                                className="btn light"
                                style={{ marginTop: 8 }}
                                onClick={() => showNotice(z[3])}
                              >
                                ⓘ شرح المهارة
                              </button>
                            </div>
                          )}
                        </div>

                        <div className="nav">
                          <button
                            className="btn light"
                            disabled={qi === 0}
                            onClick={() => {
                              if (qi > 0) {
                                setQi(qi - 1);
                                setEssayDraft(userAnswers[qi - 1]?.essay || '');
                              }
                            }}
                          >
                            السابق
                          </button>

                          {isEssay && !isCurrentAnswered ? (
                            <button className="btn primary" onClick={handleAnswerEssay}>
                              إرسال الإجابة
                            </button>
                          ) : (
                            <button
                              className="btn primary"
                              onClick={() => {
                                if (!isCurrentAnswered) {
                                  showNotice('أجب عن السؤال أولًا.');
                                  return;
                                }
                                if (qi < quiz.qs.length - 1) {
                                  setQi(qi + 1);
                                  setEssayDraft(userAnswers[qi + 1]?.essay || '');
                                } else {
                                  handleFinishQuiz();
                                }
                              }}
                            >
                              {qi === quiz.qs.length - 1 ? 'إنهاء الاختبار' : 'التالي'}
                            </button>
                          )}
                        </div>
                      </>
                    );
                  })()}
                </div>
              ) : (
                <div className="score">
                  <strong>
                    {score}/{quiz.qs.length}
                  </strong>
                  <p>نسبتك {Math.round((score / quiz.qs.length) * 100)}%</p>
                  <p>⭐ حصلت على {score * 10} نقاط وتقدّم جوادك في سباق الفرسان 🐎</p>
                  {quiz.nafesStageIdx !== undefined && (
                    <div
                      style={{
                        background: '#fffdf2',
                        border: '1px solid #f0d799',
                        padding: 12,
                        borderRadius: 14,
                        margin: '12px 0'
                      }}
                    >
                      🎉 <b>تم إتمام هذه المرحلة من اختبار نافس!</b> لن يتكرر لك هذا الاختبار، وقد فُتحت لك الآن المرحلة التالية بنص جديد وأسئلة جديدة.
                    </div>
                  )}
                  <div className="actions" style={{ justifyContent: 'center', flexWrap: 'wrap', gap: 8 }}>
                    <button
                      className="btn gold"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}
                      onClick={() => fireCelebratoryFireworks()}
                    >
                      🎆 ألعاب نارية احتفالية
                    </button>
                    {quiz.nafesStageIdx !== undefined &&
                      quiz.nafesStageIdx + 1 < NAFES_STAGES.length && (
                        <button
                          className="btn gold"
                          onClick={() => {
                            const nextIdx = quiz.nafesStageIdx! + 1;
                            launchNafesStage(NAFES_STAGES[nextIdx], nextIdx);
                          }}
                        >
                          🚀 انتقل للمرحلة التالية من نافس ({NAFES_STAGES[quiz.nafesStageIdx + 1].unitLabel}) ←
                        </button>
                      )}
                    {score < quiz.qs.length && (
                      <button className="btn coral" onClick={openMistakesClinic}>
                        🩺 راجع وعالج أخطاءك الآن
                      </button>
                    )}
                    <button className="btn primary" onClick={() => setActiveModal(null)}>
                      العودة للرئيسية
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Games Modal */}
      <div
        id="gamesModal"
        className={`modal ${activeModal === 'gamesModal' ? 'show' : ''}`}
        onClick={e => {
          if (e.target === e.currentTarget) {
            if (speedTimerRef.current) clearInterval(speedTimerRef.current);
            setActiveModal(null);
          }
        }}
      >
        <div className="dialog">
          <div className="head">
            <h2>🎮 مركز الألعاب اللغوية</h2>
            <button
              className="close"
              onClick={() => {
                if (speedTimerRef.current) clearInterval(speedTimerRef.current);
                setActiveModal(null);
              }}
            >
              ×
            </button>
          </div>
          <div className="body">
            {gameView === 'menu' && (
              <div id="gameMenu" className="gameGrid">
                <div className="game">
                  <h3>🔎 المحقق اللغوي</h3>
                  <p>اكتشف الصواب والخطأ اللغوي في الجمل.</p>
                  <button className="btn green full" onClick={startDetective}>
                    ابدأ
                  </button>
                </div>
                <div className="game">
                  <h3>🧩 ركّب الجملة</h3>
                  <p>رتب الكلمات المبعثرة لتكوين جملة سليمة.</p>
                  <button className="btn purple full" onClick={startOrderGame}>
                    ابدأ
                  </button>
                </div>
                <div className="game">
                  <h3>🧠 معنى الكلمة</h3>
                  <p>اختر المعنى المناسب للمفردات.</p>
                  <button className="btn blue full" onClick={startMeaning}>
                    ابدأ
                  </button>
                </div>
                <div className="game">
                  <h3>⚡ تحدي السرعة</h3>
                  <p>أسئلة قصيرة بزمن محدد (30 ثانية).</p>
                  <button className="btn gold full" onClick={startSpeed}>
                    ابدأ
                  </button>
                </div>
              </div>
            )}

            {gameView === 'detective' && (
              <div id="gameArea">
                {!detDone ? (
                  <>
                    <button className="btn light" onClick={() => setGameView('menu')}>
                      ← الألعاب
                    </button>
                    <h3>
                      🔎 المحقق اللغوي ({detIndex + 1}/{DETECTIVE_QS.length})
                    </h3>
                    <div className="word" style={{ fontSize: 22 }}>
                      {DETECTIVE_QS[detIndex].prompt}
                    </div>
                    <div className="options">
                      {DETECTIVE_QS[detIndex].options.map((o, j) => {
                        let cls = 'option';
                        if (detSelected !== null) {
                          if (j === DETECTIVE_QS[detIndex].answer) cls += ' ok';
                          else if (j === detSelected) cls += ' bad';
                        }
                        return (
                          <button
                            key={j}
                            className={cls}
                            disabled={detSelected !== null}
                            onClick={() => answerDetective(j)}
                          >
                            {OPTION_LABELS[j]} {o}
                          </button>
                        );
                      })}
                    </div>
                    {detSelected !== null && (
                      <>
                        <div className="explain">
                          <b>
                            {detSelected === DETECTIVE_QS[detIndex].answer
                              ? '✅ أحسنت! '
                              : '❌ غير صحيح. '}
                          </b>
                          {DETECTIVE_QS[detIndex].explain}
                        </div>
                        <div className="actions">
                          <button className="btn green" onClick={nextDetective}>
                            {detIndex + 1 < DETECTIVE_QS.length ? 'السؤال التالي ←' : 'عرض النتيجة'}
                          </button>
                        </div>
                      </>
                    )}
                  </>
                ) : (
                  <div className="score">
                    <strong>
                      {detScore}/{DETECTIVE_QS.length}
                    </strong>
                    <p>أحسنت أيها المحقق اللغوي!</p>
                    <button className="btn green" onClick={() => setGameView('menu')}>
                      العودة للألعاب
                    </button>
                  </div>
                )}
              </div>
            )}

            {gameView === 'order' && (
              <div id="gameArea">
                <button className="btn light" onClick={() => setGameView('menu')}>
                  ← الألعاب
                </button>
                <h3>🧩 ركّب الجملة</h3>
                <p className="sub">
                  اضغط على الكلمات بالترتيب الصحيح (ويمكنك الضغط على آخر كلمة لإزالتها):
                </p>
                <div
                  className="word"
                  style={{ cursor: orderChosen.length > 0 ? 'pointer' : 'default' }}
                  onClick={() => {
                    if (orderChosen.length > 0) {
                      setOrderChosen(prev => prev.slice(0, -1));
                    }
                  }}
                >
                  {orderChosen.length > 0 ? orderChosen.map(i => orderWords[i]).join(' ') : '—'}
                </div>
                <div className="options">
                  {orderWords.map((x, idx) => (
                    <button
                      key={idx}
                      className="option"
                      disabled={orderChosen.includes(idx)}
                      onClick={() => setOrderChosen(prev => [...prev, idx])}
                    >
                      {x}
                    </button>
                  ))}
                </div>
                <div className="actions">
                  <button className="btn green" onClick={checkOrderGame}>
                    تحقق
                  </button>
                  <button
                    className="btn light"
                    disabled={orderChosen.length === 0}
                    onClick={() => setOrderChosen(prev => prev.slice(0, -1))}
                  >
                    تراجع عن كلمة
                  </button>
                  <button className="btn light" onClick={() => initOrderRound(orderRound)}>
                    إعادة ترتيب
                  </button>
                  <button className="btn purple" onClick={() => initOrderRound(orderRound + 1)}>
                    جملة أخرى
                  </button>
                </div>
              </div>
            )}

            {gameView === 'meaning' && (
              <div id="gameArea">
                {!meanDone ? (
                  <>
                    <button className="btn light" onClick={() => setGameView('menu')}>
                      ← الألعاب
                    </button>
                    <h3>
                      🧠 معنى الكلمة ({meanIndex + 1}/{MEANING_PAIRS.length})
                    </h3>
                    <div className="word">{MEANING_PAIRS[meanIndex][0]}</div>
                    <div className="options">
                      {meanOpts.map((o, idx) => (
                        <button key={idx} className="option" onClick={() => answerMeaning(o)}>
                          {OPTION_LABELS[idx]} {o}
                        </button>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="score">
                    <strong>{meanScore}/3</strong>
                    <p>نتيجتك في اللعبة.</p>
                    <button className="btn green" onClick={() => setGameView('menu')}>
                      العودة
                    </button>
                  </div>
                )}
              </div>
            )}

            {gameView === 'speed' && (
              <div id="gameArea">
                {!speedDone ? (
                  <>
                    <button
                      className="btn light"
                      onClick={() => {
                        if (speedTimerRef.current) clearInterval(speedTimerRef.current);
                        setGameView('menu');
                      }}
                    >
                      ← الألعاب
                    </button>
                    <h3>
                      ⚡ تحدي السرعة <span>00:{String(speedTime).padStart(2, '0')}</span>
                    </h3>
                    <div className="word">{SPEED_QS[speedIndex][0]}</div>
                    <div className="options">
                      {SPEED_QS[speedIndex][1].map((o, j) => (
                        <button key={j} className="option" onClick={() => answerSpeed(j)}>
                          {OPTION_LABELS[j]} {o}
                        </button>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="score">
                    <strong>
                      {speedScore}/{SPEED_QS.length}
                    </strong>
                    <p>انتهى التحدي.</p>
                    <button className="btn green" onClick={() => setGameView('menu')}>
                      العودة
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Feedback Modal */}
      <div
        id="feedbackModal"
        className={`modal ${activeModal === 'feedbackModal' ? 'show' : ''}`}
        onClick={e => {
          if (e.target === e.currentTarget) setActiveModal(null);
        }}
      >
        <div className="dialog">
          <div className="head">
            <h2>💬 صوت ولي الأمر</h2>
            <button className="close" onClick={() => setActiveModal(null)}>
              ×
            </button>
          </div>
          <div className="body">
            <p>نرحب بآراء الأسرة ومقترحاتها.</p>
            <div className="grid">
              <div className="field">
                <label>الصفة</label>
                <select value={fbRole} onChange={e => setFbRole(e.target.value)}>
                  <option>ولي أمر طالب</option>
                  <option>ولي أمر طالبة</option>
                </select>
              </div>
              <div className="field">
                <label>الفصل</label>
                <select value={fbCls} onChange={e => setFbCls(e.target.value)}>
                  <option>بدون تحديد</option>
                  <option>أ</option>
                  <option>ب</option>
                  <option>ج</option>
                </select>
              </div>
              <div className="field" style={{ gridColumn: '1/-1' }}>
                <label>الاقتراح أو الرأي</label>
                <textarea
                  rows={4}
                  maxLength={500}
                  placeholder="اكتب مقترحك أو ملاحظتك هنا..."
                  value={fbText}
                  onChange={e => setFbText(e.target.value)}
                />
              </div>
            </div>
            <div className="actions">
              <button className="btn purple" onClick={handleSendFeedback}>
                إرسال للمراجعة وحفظ في قاعدة البيانات
              </button>
            </div>
            <h3>📣 آراء ومقترحات أولياء الأمور</h3>
            <div id="feedbackList">
              <div className="feedback">
                <b>💬 ولي أمر طالب</b>
                <small>معتمد ومنشور</small>
                <div>أقترح زيادة أنشطة فهم المقروء.</div>
              </div>
              <div className="feedback">
                <b>💬 ولي أمر طالبة</b>
                <small>معتمد ومنشور</small>
                <div>أتمنى إضافة أنشطة للتعبير الكتابي.</div>
              </div>
              {allFeedbackToDisplay.map((v, idx) => (
                <div key={idx} className="feedback">
                  <b>
                    🕊️ {v.role} {v.cls && v.cls !== 'بدون تحديد' ? `— فصل (${v.cls})` : ''}
                  </b>
                  <small>{v.status}</small>
                  <div>{v.text}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Share / WhatsApp Modal */}
      {activeModal === 'shareModal' && (
        <div
          className="modal show"
          style={{ zIndex: 90 }}
          onClick={e => {
            if (e.target === e.currentTarget) setActiveModal(null);
          }}
        >
          <div className="dialog" style={{ maxWidth: 580 }} onClick={e => e.stopPropagation()}>
            <div className="head" style={{ background: 'linear-gradient(135deg, #1f7a55, #126b70)' }}>
              <h2>📱 مشاركة المنصة عبر الواتساب</h2>
              <button className="close" onClick={() => setActiveModal(null)}>
                ×
              </button>
            </div>
            <div className="body" style={{ textAlign: 'right' }}>
              <div
                style={{
                  background: '#f0fdf4',
                  border: '1.5px solid #bbf7d0',
                  borderRadius: 16,
                  padding: '14px 16px',
                  marginBottom: 16
                }}
              >
                <h4 style={{ margin: '0 0 6px', color: '#166534', fontSize: 16 }}>
                  ✨ رابط المنصة العام والمباشر (شغال لجميع الطلاب والمعلمين بدون تسجيل دخول):
                </h4>
                <div
                  style={{
                    background: '#ffffff',
                    border: '1px solid #cbd5e1',
                    borderRadius: 12,
                    padding: '10px 12px',
                    fontFamily: 'monospace',
                    direction: 'ltr',
                    textAlign: 'left',
                    fontSize: 13,
                    wordBreak: 'break-all',
                    color: '#0f172a',
                    marginBottom: 10,
                    userSelect: 'all'
                  }}
                >
                  {(() => {
                    const cur = window.location.origin || window.location.href;
                    if (cur.includes('ais-dev-')) return cur.replace('ais-dev-', 'ais-pre-');
                    if (cur.includes('localhost') || cur.includes('127.0.0.1')) return 'https://ais-pre-zx4ojc322jmrrwbkpqxia3-923277338572.europe-west2.run.app';
                    return cur;
                  })()}
                </div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  <button
                    className="btn gold"
                    style={{ flex: 1, minWidth: 140, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
                    onClick={() => {
                      const cur = window.location.origin || window.location.href;
                      const shareUrl = cur.includes('ais-dev-')
                        ? cur.replace('ais-dev-', 'ais-pre-')
                        : (cur.includes('localhost') || cur.includes('127.0.0.1'))
                        ? 'https://ais-pre-zx4ojc322jmrrwbkpqxia3-923277338572.europe-west2.run.app'
                        : cur;
                      if (navigator.clipboard) {
                        navigator.clipboard.writeText(shareUrl);
                        showNotice('✅ تم نسخ الرابط العام بنجاح! يمكنك الآن لصقه في الواتساب أو الرسائل النصية للطلاب.');
                      } else {
                        showNotice(`الرابط: ${shareUrl}`);
                      }
                    }}
                  >
                    📋 نسخ الرابط العام المباشر
                  </button>
                  <button
                    className="btn green"
                    style={{
                      flex: 1.2,
                      minWidth: 170,
                      background: '#25D366',
                      color: '#fff',
                      display: 'inline-flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: 6
                    }}
                    onClick={() => {
                      const cur = window.location.origin || window.location.href;
                      const shareUrl = cur.includes('ais-dev-')
                        ? cur.replace('ais-dev-', 'ais-pre-')
                        : (cur.includes('localhost') || cur.includes('127.0.0.1'))
                        ? 'https://ais-pre-zx4ojc322jmrrwbkpqxia3-923277338572.europe-west2.run.app'
                        : cur;
                      const msg = `📚 *منصة لُغتي تحكي... وأنا أصنع الحكاية*\n🎓 للصف الأول المتوسط - إعداد وتنفيذ المعلم مساعد سليمان الصخري\n\n📌 رابط المنصة المباشر للطلاب:\n${shareUrl}`;
                      const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`;
                      window.open(whatsappUrl, '_blank');
                    }}
                  >
                    💬 إرسال رسالة جاهزة عبر واتساب
                  </button>
                  <a
                    href={(() => {
                      const cur = window.location.origin || window.location.href;
                      if (cur.includes('ais-dev-')) return cur.replace('ais-dev-', 'ais-pre-');
                      if (cur.includes('localhost') || cur.includes('127.0.0.1')) return 'https://ais-pre-zx4ojc322jmrrwbkpqxia3-923277338572.europe-west2.run.app';
                      return cur;
                    })()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn light"
                    style={{ flex: 1, minWidth: 140, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6, textDecoration: 'none' }}
                  >
                    🌐 تجربة وفتح الرابط في نافذة جديدة
                  </a>
                </div>
              </div>

              {/* Troubleshooting guide for why WhatsApp link might not open */}
              <div
                style={{
                  background: '#fff8eb',
                  border: '1px solid #fde68a',
                  borderRadius: 16,
                  padding: '14px 16px',
                  fontSize: 14,
                  lineHeight: '1.8'
                }}
              >
                <h4 style={{ margin: '0 0 8px', color: '#92400e', fontSize: 15, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span>⚠️</span>
                  <span>لماذا قد لا يفتح الرابط أحيانًا في الواتساب وكيف تحل المشكلة؟</span>
                </h4>
                <ol style={{ margin: '0 0 10px', paddingRight: 20, color: '#78350f' }}>
                  <li style={{ marginBottom: 8 }}>
                    <b>السبب الرئيسي لعدم فتح الرابط السابق (رابط التطوير مقابل الرابط العام):</b>
                    <br />
                    الرابط الذي كنت تنسخه من شريط المتصفح الداخلي يحتوي على كلمة (<code style={{ background: '#fee2e2', padding: '1px 5px', borderRadius: 4 }}>ais-dev</code>)، وهو رابط محمي ومغلق يتطلب تسجيل دخول حساب المطور!
                    <br />
                    <span style={{ color: '#047857' }}>
                      💡 <b>الحل:</b> الرابط المحدث بالأعلى يحتوي على (<code style={{ background: '#dcfce7', padding: '1px 5px', borderRadius: 4 }}>ais-pre</code>) وهو <b>الرابط العام المفتوح للجميع</b> بدون الحاجة لأي تسجيل دخول.
                    </span>
                  </li>
                  <li style={{ marginBottom: 8 }}>
                    <b>إرسال الرابط من رقم غير مسجل (حماية أمان الواتساب والرسائل):</b>
                    <br />
                    إذا كان الطالب أو ولي الأمر لا يحفظ رقم جوالك في جهات اتصاله، يقوم واتساب بتعطيل النقر على الروابط تلقائيًا كإجراء أمان.
                    <br />
                    <span style={{ color: '#047857' }}>
                      💡 <b>الحل:</b> اطلب من الطالب الرد على رسالتك بأي كلمة أو حفظ رقمك، وسيصبح الرابط فوراً أزرق وقابلاً للنقر، أو أن ينسخ الرابط ويلصقه في متصفح الجوال مباشرة.
                    </span>
                  </li>
                  <li style={{ marginBottom: 8 }}>
                    <b>هل لابد من رفعه على صفحة ويب / استضافة مستقلة؟</b>
                    <br />
                    <b>لا، ليس إجبارياً!</b> الرابط العام بالأعلى مرفوع ومستضاف بالفعل على سحابة جوجل السريعة ويعمل مباشرة من أي جهاز.
                    <br />
                    <span>
                      🌐 <i>اختياري:</i> إذا كنت ترغب برابط دائم ومختصر باسم مخصص (مثل <code dir="ltr">loghati.web.app</code>)، يمكنك رفعه بضغطة زر عبر خدمة الاستضافة المجانية (Firebase Hosting) لأن قاعدة البيانات مرتبطة بالفعل.
                    </span>
                  </li>
                </ol>
              </div>

              <div style={{ marginTop: 16, textAlign: 'center' }}>
                <button className="btn primary" onClick={() => setActiveModal(null)}>
                  إغلاق النافذة
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Custom Notification Modal */}
      {notice && (
        <div className="modal show" style={{ zIndex: 99 }} onClick={() => setNotice(null)}>
          <div className="dialog" style={{ maxWidth: 440 }} onClick={e => e.stopPropagation()}>
            <div className="head">
              <h2>💡 تنبيه</h2>
              <button className="close" onClick={() => setNotice(null)}>
                ×
              </button>
            </div>
            <div className="body" style={{ textAlign: 'center' }}>
              <p style={{ fontSize: 18, margin: '8px 0 18px' }}>{notice}</p>
              <button className="btn primary" onClick={() => setNotice(null)}>
                حسنًا
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
