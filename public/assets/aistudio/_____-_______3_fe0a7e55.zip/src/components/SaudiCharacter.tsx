import React from 'react';

export type OutfitId =
  | 'default_saudi'
  | 'najdi'
  | 'hijazi'
  | 'southern'
  | 'northern'
  | 'eastern'
  | 'sports_national';

export interface OutfitInfo {
  id: OutfitId;
  name: string;
  region: string;
  description: string;
  unlockRequirement: string;
  isUnlocked: boolean;
  thobeColor: string;
  accentColor: string;
  patternType: 'classic' | 'daglah' | 'hijazi_vest' | 'musannaf' | 'farwa' | 'bisht' | 'sport';
}

export const SAUDI_OUTFITS: Record<OutfitId, Omit<OutfitInfo, 'isUnlocked'>> = {
  default_saudi: {
    id: 'default_saudi',
    name: 'الثوب والشماغ السعودي الأصيل',
    region: 'الزي الوطني العام',
    description: 'ثوب أبيض ناصع مع ياقة رسمية وشماغ أحمر وأبيض مهدب وعقال أسود ملكي',
    unlockRequirement: 'متاح للجميع كزي افتراضي',
    thobeColor: '#ffffff',
    accentColor: '#b91c1c',
    patternType: 'classic'
  },
  najdi: {
    id: 'najdi',
    name: 'الدقلة النجدية التراثية',
    region: 'المنطقة الوسطى (نجد)',
    description: 'دقلة نجدية أنيقة بتطريزات الزري التراثية تعكس عراقة وأصالة نجد',
    unlockRequirement: 'تحقيق 10 نقاط تعليمية في المنصة',
    thobeColor: '#f8fafc',
    accentColor: '#854d0e',
    patternType: 'daglah'
  },
  hijazi: {
    id: 'hijazi',
    name: 'الزي الحجازي والعمامة',
    region: 'المنطقة الغربية (الحجاز)',
    description: 'ثوب أبيض مع سديرية مطرزة وعمامة الغبانة الحجازية الشهيرة',
    unlockRequirement: 'إتقان تدريبات الوحدة الأولى (القيم الإسلامية)',
    thobeColor: '#fefce8',
    accentColor: '#ca8a04',
    patternType: 'hijazi_vest'
  },
  southern: {
    id: 'southern',
    name: 'المصنف العسيري الجبلي',
    region: 'المنطقة الجنوبية (عسير والجنوب)',
    description: 'مصنف تراثي ملوّن وحزام أنيق فوق الثوب يجسد كرم وأصالة جبال الجنوب',
    unlockRequirement: 'تحقيق 20 نقطة تعليمية تراكمية',
    thobeColor: '#f0fdf4',
    accentColor: '#15803d',
    patternType: 'musannaf'
  },
  northern: {
    id: 'northern',
    name: 'الفروة الشمالية الأصيلة',
    region: 'المنطقة الشمالية',
    description: 'فروة شمالية مطرزة ومزخرفة بنقوش أصيلة توارثتها الأجيال',
    unlockRequirement: 'إكمال تحدي اليوم بنجاح',
    thobeColor: '#fafaf9',
    accentColor: '#78350f',
    patternType: 'farwa'
  },
  eastern: {
    id: 'eastern',
    name: 'البشت الحساوي المذهب',
    region: 'المنطقة الشرقية (الأحساء)',
    description: 'بشت حساوي فاخر مطرز بخيوط الذهب الفاخرة، رمز الهيبة والوقار',
    unlockRequirement: 'تحقيق 30 نقطة تعليمية أو إنهاء جميع الوحدات',
    thobeColor: '#1e293b',
    accentColor: '#eab308',
    patternType: 'bisht'
  },
  sports_national: {
    id: 'sports_national',
    name: 'طقم المنتخب السعودي الرياضي',
    region: 'الرياضة الوطنية',
    description: 'طقم رياضي محتشم بألوان الأخضر والأبيض مستوحى من صقور المنتخب الوطني',
    unlockRequirement: 'إحراز 3 أهداف في ركلات الترجيح الكروية',
    thobeColor: '#006c35',
    accentColor: '#ffffff',
    patternType: 'sport'
  }
};

interface SaudiCharacterProps {
  outfitId?: OutfitId;
  animState?: 'standing' | 'running' | 'waving' | 'celebrating';
  size?: number; // width in px
  name?: string;
  isRTL?: boolean;
}

export const SaudiCharacter: React.FC<SaudiCharacterProps> = ({
  outfitId = 'default_saudi',
  animState = 'standing',
  size = 120,
  name,
  isRTL = true
}) => {
  const outfit = SAUDI_OUTFITS[outfitId] || SAUDI_OUTFITS.default_saudi;
  const height = Math.round(size * 1.5);

  return (
    <div
      style={{
        display: 'inline-flex',
        flexDirection: 'column',
        alignItems: 'center',
        position: 'relative',
        userSelect: 'none'
      }}
    >
      {/* Student Name Tag over Head */}
      {name && (
        <div
          style={{
            background: 'rgba(15, 23, 42, 0.82)',
            color: '#ffffff',
            fontSize: '11px',
            fontWeight: 700,
            padding: '2px 8px',
            borderRadius: '9999px',
            marginBottom: '4px',
            boxShadow: '0 2px 6px rgba(0,0,0,0.25)',
            border: '1px solid rgba(255,255,255,0.3)',
            whiteSpace: 'nowrap'
          }}
        >
          {name}
        </div>
      )}

      {/* SVG Character Model */}
      <svg
        width={size}
        height={height}
        viewBox="0 0 100 150"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        style={{ overflow: 'visible' }}
      >
        <defs>
          {/* Head & Skin Gradient */}
          <radialGradient id="skinGrad" cx="50%" cy="40%" r="50%">
            <stop offset="0%" stopColor="#f7c8a3" />
            <stop offset="100%" stopColor="#e5a97d" />
          </radialGradient>

          {/* Red and White Shemagh Pattern */}
          <pattern id="shemaghPattern" width="4" height="4" patternUnits="userSpaceOnUse">
            <rect width="4" height="4" fill="#ffffff" />
            <path d="M0 0L4 4M4 0L0 4" stroke="#c0392b" strokeWidth="1" />
          </pattern>

          {/* Gold Embroidery Pattern */}
          <linearGradient id="goldZari" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fde047" />
            <stop offset="50%" stopColor="#ca8a04" />
            <stop offset="100%" stopColor="#eab308" />
          </linearGradient>

          {/* Saudi Green Gradient */}
          <linearGradient id="saudiGreen" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#007a3d" />
            <stop offset="100%" stopColor="#00562b" />
          </linearGradient>
        </defs>

        {/* Shadow on Ground */}
        <ellipse cx="50" cy="144" rx={animState === 'celebrating' ? 18 : 26} ry="6" fill="rgba(0,0,0,0.22)" />

        {/* LEGS & SHOES */}
        {outfit.patternType === 'sport' ? (
          // Athletic Shorts & Socks
          <g>
            {/* White Athletic Shorts */}
            <rect x="36" y="88" width="13" height="24" rx="3" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1" />
            <rect x="51" y="88" width="13" height="24" rx="3" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1" />
            {/* Legs */}
            <rect x="39" y="112" width="7" height="18" fill="url(#skinGrad)" rx="3" />
            <rect x="54" y="112" width="7" height="18" fill="url(#skinGrad)" rx="3" />
            {/* Green Sports Socks & Football Shoes */}
            <rect x="38" y="124" width="9" height="14" fill="#006c35" rx="2" />
            <rect x="53" y="124" width="9" height="14" fill="#006c35" rx="2" />
            {/* Shoes */}
            <path d="M35 138 C35 138, 48 138, 48 141 C48 144, 34 144, 34 141 Z" fill="#111827" />
            <path d="M52 138 C52 138, 65 138, 65 141 C65 144, 51 144, 51 141 Z" fill="#111827" />
          </g>
        ) : (
          // Traditional Footwear under Thobe
          <g>
            <path d="M36 138 C36 137, 47 137, 47 141 C47 143, 34 143, 34 141 Z" fill="#5c3818" />
            <path d="M53 138 C53 137, 64 137, 64 141 C64 143, 51 143, 51 141 Z" fill="#5c3818" />
          </g>
        )}

        {/* THOBE / MAIN BODY */}
        {outfit.patternType === 'sport' ? (
          // Sports Jersey
          <g>
            <path
              d="M32 58 L68 58 L66 90 L34 90 Z"
              fill="url(#saudiGreen)"
              stroke="#00562b"
              strokeWidth="1.5"
            />
            {/* White collar & center number 10 */}
            <path d="M44 58 L50 66 L56 58 Z" fill="#ffffff" />
            <text x="50" y="80" textAnchor="middle" fill="#ffffff" fontSize="12" fontWeight="900">
              🇸🇦
            </text>
          </g>
        ) : (
          // Saudi Traditional Thobe
          <g>
            {/* Main Thobe Body */}
            <path
              d="M32 58 L68 58 L72 136 C72 138, 28 138, 28 136 Z"
              fill={outfit.thobeColor}
              stroke="#e2e8f0"
              strokeWidth="1.2"
            />
            {/* Thobe Placket & Buttons */}
            <line x1="50" y1="58" x2="50" y2="88" stroke="#cbd5e1" strokeWidth="1.5" />
            <circle cx="50" cy="64" r="1.2" fill="#94a3b8" />
            <circle cx="50" cy="72" r="1.2" fill="#94a3b8" />
            <circle cx="50" cy="80" r="1.2" fill="#94a3b8" />
            {/* High Saudi Collar (قلاب/سادة) */}
            <rect x="44" y="55" width="12" height="5" rx="1.5" fill={outfit.thobeColor} stroke="#cbd5e1" strokeWidth="1" />

            {/* REGIONAL OVERLAY STYLES */}
            {outfit.patternType === 'daglah' && (
              // Najdi Daglah Coat
              <g>
                <path d="M30 60 L45 60 L42 120 L28 118 Z" fill="#713f12" stroke="url(#goldZari)" strokeWidth="1.5" />
                <path d="M70 60 L55 60 L58 120 L72 118 Z" fill="#713f12" stroke="url(#goldZari)" strokeWidth="1.5" />
                <line x1="45" y1="60" x2="42" y2="120" stroke="url(#goldZari)" strokeWidth="2" />
                <line x1="55" y1="60" x2="58" y2="120" stroke="url(#goldZari)" strokeWidth="2" />
              </g>
            )}

            {outfit.patternType === 'hijazi_vest' && (
              // Hijazi Sadriyah Vest
              <g>
                <path d="M32 60 L45 60 L44 92 L32 88 Z" fill="#854d0e" />
                <path d="M68 60 L55 60 L56 92 L68 88 Z" fill="#854d0e" />
                <circle cx="50" cy="66" r="2" fill="url(#goldZari)" />
                <circle cx="50" cy="76" r="2" fill="url(#goldZari)" />
              </g>
            )}

            {outfit.patternType === 'musannaf' && (
              // Asiri Musannaf Sash & Traditional Belt
              <g>
                {/* Cross Sash */}
                <path d="M33 60 L68 100 L65 106 L30 66 Z" fill="#dc2626" />
                <path d="M35 62 L66 98 L64 102 L33 66 Z" fill="#facc15" />
                {/* Traditional Belt (حزام سبتة) */}
                <rect x="32" y="88" width="36" height="6" rx="2" fill="#78350f" stroke="#eab308" strokeWidth="1" />
                <rect x="47" y="87" width="6" height="8" rx="1" fill="#eab308" />
              </g>
            )}

            {outfit.patternType === 'farwa' && (
              // Northern Farwa Coat
              <g>
                <path d="M26 60 L43 60 L39 130 L22 126 Z" fill="#451a03" stroke="#b45309" strokeWidth="1.5" />
                <path d="M74 60 L57 60 L61 130 L78 126 Z" fill="#451a03" stroke="#b45309" strokeWidth="1.5" />
                {/* Fur Lining Collar */}
                <rect x="25" y="58" width="8" height="50" rx="3" fill="#fef3c7" />
                <rect x="67" y="58" width="8" height="50" rx="3" fill="#fef3c7" />
              </g>
            )}

            {outfit.patternType === 'bisht' && (
              // Hasawi Royal Bisht with Gold Zari
              <g>
                <path d="M26 60 L45 60 L40 134 L22 130 Z" fill="#18181b" opacity="0.95" />
                <path d="M74 60 L55 60 L60 134 L78 130 Z" fill="#18181b" opacity="0.95" />
                {/* Heavy Gold Zari Collar & Edges */}
                <path d="M45 60 L50 78 L55 60 Z" fill="url(#goldZari)" />
                <line x1="45" y1="60" x2="40" y2="134" stroke="url(#goldZari)" strokeWidth="2.5" />
                <line x1="55" y1="60" x2="60" y2="134" stroke="url(#goldZari)" strokeWidth="2.5" />
                {/* Gold Tassel (قيطان) */}
                <circle cx="50" cy="80" r="2.5" fill="url(#goldZari)" />
                <line x1="50" y1="80" x2="50" y2="94" stroke="url(#goldZari)" strokeWidth="1.5" />
              </g>
            )}
          </g>
        )}

        {/* ARMS & HANDS */}
        {animState === 'celebrating' ? (
          // Raised Arms Celebrating
          <g>
            <path d="M32 62 L18 36 L24 33 L36 58 Z" fill={outfit.patternType === 'sport' ? '#006c35' : outfit.thobeColor} stroke="#cbd5e1" strokeWidth="1" />
            <circle cx="19" cy="33" r="5" fill="url(#skinGrad)" />
            <path d="M68 62 L82 36 L76 33 L64 58 Z" fill={outfit.patternType === 'sport' ? '#006c35' : outfit.thobeColor} stroke="#cbd5e1" strokeWidth="1" />
            <circle cx="81" cy="33" r="5" fill="url(#skinGrad)" />
          </g>
        ) : animState === 'waving' ? (
          // One Hand Waving (السلام عليكم)
          <g>
            <path d="M32 62 L20 84 L26 86 L36 66 Z" fill={outfit.patternType === 'sport' ? '#006c35' : outfit.thobeColor} />
            <circle cx="21" cy="88" r="4.5" fill="url(#skinGrad)" />
            <path d="M68 62 L84 40 L88 44 L72 68 Z" fill={outfit.patternType === 'sport' ? '#006c35' : outfit.thobeColor} />
            <circle cx="87" cy="38" r="5" fill="url(#skinGrad)" />
          </g>
        ) : (
          // Natural Standing / Running Arm posture
          <g>
            <path d="M32 62 L22 84 L28 86 L36 66 Z" fill={outfit.patternType === 'sport' ? '#006c35' : outfit.thobeColor} />
            <circle cx="24" cy="88" r="4.5" fill="url(#skinGrad)" />
            <path d="M68 62 L78 84 L72 86 L64 66 Z" fill={outfit.patternType === 'sport' ? '#006c35' : outfit.thobeColor} />
            <circle cx="76" cy="88" r="4.5" fill="url(#skinGrad)" />
          </g>
        )}

        {/* HEAD & FACE */}
        <g>
          {/* Neck */}
          <rect x="45" y="48" width="10" height="12" fill="url(#skinGrad)" />

          {/* Face Base */}
          <ellipse cx="50" cy="36" rx="14" ry="16" fill="url(#skinGrad)" />

          {/* Friendly Eyes */}
          <ellipse cx="44" cy="35" rx="2" ry="2.5" fill="#1c1917" />
          <circle cx="44.8" cy="34" r="0.8" fill="#ffffff" />
          <ellipse cx="56" cy="35" rx="2" ry="2.5" fill="#1c1917" />
          <circle cx="56.8" cy="34" r="0.8" fill="#ffffff" />

          {/* Modest Eyebrows */}
          <path d="M41 30 Q44 28 47 30" stroke="#292524" strokeWidth="1.5" strokeLinecap="round" fill="none" />
          <path d="M53 30 Q56 28 59 30" stroke="#292524" strokeWidth="1.5" strokeLinecap="round" fill="none" />

          {/* Nose */}
          <path d="M50 34 L49 39 L52 39" stroke="#b45309" strokeWidth="1" strokeLinecap="round" fill="none" />

          {/* Polite Smile */}
          <path d="M46 43 Q50 47 54 43" stroke="#991b1b" strokeWidth="1.5" strokeLinecap="round" fill="none" />

          {/* HEADWEAR (الشماغ أو العمامة أو الغترة) */}
          {outfit.patternType === 'hijazi_vest' ? (
            // Hijazi Ghabbanag Turban
            <g>
              <ellipse cx="50" cy="22" rx="17" ry="11" fill="#facc15" stroke="#ca8a04" strokeWidth="1" />
              <path d="M33 22 Q50 14 67 22 Q50 28 33 22" fill="#ca8a04" />
              <ellipse cx="50" cy="22" rx="14" ry="8" fill="#fef08a" />
              <circle cx="50" cy="18" r="2.5" fill="#ca8a04" />
            </g>
          ) : outfit.patternType === 'sport' ? (
            // Athletic Haircut
            <g>
              <path d="M35 30 C35 16, 65 16, 65 30 C65 24, 35 24, 35 30 Z" fill="#1c1917" />
              <path d="M34 27 Q50 16 66 27 Z" fill="#292524" />
            </g>
          ) : (
            // Traditional Saudi Shemagh & Agal
            <g>
              {/* Shemagh Falling behind and over shoulders */}
              <path
                d="M31 22 C22 35, 23 58, 25 78 L34 76 C34 56, 35 35, 40 25 Z"
                fill="url(#shemaghPattern)"
                stroke="#c0392b"
                strokeWidth="0.8"
              />
              <path
                d="M69 22 C78 35, 77 58, 75 78 L66 76 C66 56, 65 35, 60 25 Z"
                fill="url(#shemaghPattern)"
                stroke="#c0392b"
                strokeWidth="0.8"
              />

              {/* Main Shemagh Dome */}
              <path
                d="M33 26 C33 14, 67 14, 67 26 C67 33, 33 33, 33 26 Z"
                fill="url(#shemaghPattern)"
                stroke="#c0392b"
                strokeWidth="0.8"
              />

              {/* Double Royal Black Agal (عقال أسود ملكي) */}
              <ellipse cx="50" cy="21" rx="16" ry="5.5" fill="none" stroke="#111827" strokeWidth="3" />
              <ellipse cx="50" cy="24" rx="16.5" ry="5.5" fill="none" stroke="#18181b" strokeWidth="2.8" />
              {/* Agal Back String (الكركوشة) */}
              <line x1="50" y1="26" x2="50" y2="44" stroke="#111827" strokeWidth="1.5" />
              <circle cx="50" cy="44" r="1.5" fill="#111827" />
            </g>
          )}
        </g>
      </svg>
    </div>
  );
};
