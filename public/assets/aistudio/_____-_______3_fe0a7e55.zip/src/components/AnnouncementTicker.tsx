import React, { useEffect, useState } from 'react';

export interface AnnouncementItem {
  id: string;
  isTeacher: boolean;
  author: string;
  text: string;
  date?: string;
}

interface AnnouncementTickerProps {
  customTeacherAnnouncement?: string;
}

export const AnnouncementTicker: React.FC<AnnouncementTickerProps> = ({
  customTeacherAnnouncement
}) => {
  const [announcements, setAnnouncements] = useState<AnnouncementItem[]>([]);

  useEffect(() => {
    // 1. Read stored teacher announcements from localStorage
    let storedTeacherList: string[] = [];
    try {
      const raw = localStorage.getItem('pk_teacher_announcements');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) storedTeacherList = parsed;
      }
    } catch {
      // ignore
    }

    // Default active teacher announcement from Teacher Mosaed Al-Sakhri
    const defaultTeacherAnnouncement =
      'الأستاذ مساعد الصخري: مرحباً بكم يا أبطال الصف الأول المتوسط في منصة «لغتي تحكي»، استمروا في حل تدريبات الوحدات التعليمية ومنافسات ركلات الترجيح لتعزيز مهاراتكم اللغوية وفتح أزياء مناطق المملكة التراثية!';

    const activeTeacherTexts = [
      ...(customTeacherAnnouncement ? [customTeacherAnnouncement] : []),
      ...storedTeacherList,
      defaultTeacherAnnouncement
    ];

    // Priority 1: Teacher Announcements always appear first!
    const prioritizedList: AnnouncementItem[] = activeTeacherTexts.map((txt, idx) => ({
      id: `teacher-${idx}`,
      isTeacher: true,
      author: 'المعلم',
      text: txt
    }));

    // Priority 2: General educational announcements & tips
    const generalTips: string[] = [
      'اللغة العربية لغة القرآن الكريم وأساس هويتنا وفخرنا الوطني والتربوي.',
      'تحدي اليوم متاح الآن، أجب عن الأسئلة اليومية لكسب نقاط إضافية والتقدم في مضمار السباق!',
      'كل نقطة تعليمية تكسبها ترفع تصنيفك وتفتح أزياء التراث الإقليمي للمملكة في مضمارك.',
      'عيادة الأخطاء تتيح لك مراجعة أي سؤال تعثرت فيه لترسيخ الفهم بلا درجات سلبية.'
    ];

    generalTips.forEach((tip, idx) => {
      prioritizedList.push({
        id: `tip-${idx}`,
        isTeacher: false,
        author: 'إضاءة تعليمية',
        text: tip
      });
    });

    // 8.1 STRICT FILTER: Strictly filter out the two forbidden phrases:
    // “نتائج السباق” and “توجيهات المعلم”
    const sanitizedList = prioritizedList.map(item => {
      let cleanText = item.text;
      cleanText = cleanText.replaceAll('نتائج السباق', '');
      cleanText = cleanText.replaceAll('توجيهات المعلم', 'إعلان المعلم');
      return {
        ...item,
        text: cleanText.trim()
      };
    }).filter(item => item.text.length > 0);

    setAnnouncements(sanitizedList);
  }, [customTeacherAnnouncement]);

  return (
    <div className="announcement-ticker-container">
      {/* Ticker Icon & Title Badge */}
      <div className="ticker-badge">
        <span className="ticker-pulse-dot" />
        <span className="ticker-badge-text">📢 لوحة الإعلانات</span>
      </div>

      {/* Ticker Viewport (Continuous Smooth Slow Scrolling) */}
      <div className="ticker-track-viewport">
        <div className="ticker-scroll-content">
          {announcements.map((item, i) => (
            <span key={`${item.id}-${i}`} className="ticker-item">
              {item.isTeacher ? (
                <span className="teacher-announcement-pill">
                  <span className="teacher-icon">👨‍🏫</span>
                  <span className="teacher-label">إعلان المعلم:</span>
                  <span className="announcement-body-teacher">{item.text}</span>
                </span>
              ) : (
                <span className="general-announcement-pill">
                  <span className="general-icon">💡</span>
                  <span className="announcement-body-general">{item.text}</span>
                </span>
              )}
              <span className="ticker-divider">✦</span>
            </span>
          ))}

          {/* Duplicated items to ensure seamless endless loop */}
          {announcements.map((item, i) => (
            <span key={`dup-${item.id}-${i}`} className="ticker-item" aria-hidden="true">
              {item.isTeacher ? (
                <span className="teacher-announcement-pill">
                  <span className="teacher-icon">👨‍🏫</span>
                  <span className="teacher-label">إعلان المعلم:</span>
                  <span className="announcement-body-teacher">{item.text}</span>
                </span>
              ) : (
                <span className="general-announcement-pill">
                  <span className="general-icon">💡</span>
                  <span className="announcement-body-general">{item.text}</span>
                </span>
              )}
              <span className="ticker-divider">✦</span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
