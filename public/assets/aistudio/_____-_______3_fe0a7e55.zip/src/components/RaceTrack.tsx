import React, { useEffect, useState } from 'react';
import { OutfitId, SAUDI_OUTFITS, SaudiCharacter } from './SaudiCharacter';

export type EnvironmentType = 'daytime' | 'nighttime' | 'celebration' | 'national_day' | 'founding_day';

interface EnvironmentConfig {
  id: EnvironmentType;
  name: string;
  badge: string;
  skyBackground: string;
  trackColor: string;
  laneColor: string;
  landscapeElements: React.ReactNode;
}

interface RaceTrackProps {
  studentName: string;
  totalEduScore: number; // 0 to 50
  unlockedOutfits?: OutfitId[];
  currentOutfit: OutfitId;
  onSelectOutfit: (outfitId: OutfitId) => void;
  onOpenOutfitModal: () => void;
}

export const RaceTrack: React.FC<RaceTrackProps> = ({
  studentName,
  totalEduScore,
  currentOutfit,
  onOpenOutfitModal
}) => {
  const [currentEnv, setCurrentEnv] = useState<EnvironmentType>('daytime');
  const [characterAnim, setCharacterAnim] = useState<'standing' | 'running' | 'waving' | 'celebrating'>('running');

  // Automatic environment rotation every 25 seconds
  useEffect(() => {
    const envOrder: EnvironmentType[] = ['daytime', 'nighttime', 'celebration', 'national_day', 'founding_day'];
    const timer = setInterval(() => {
      setCurrentEnv(prev => {
        const nextIdx = (envOrder.indexOf(prev) + 1) % envOrder.length;
        return envOrder[nextIdx];
      });
    }, 25000);

    return () => clearInterval(timer);
  }, []);

  // Animate character standing vs waving occasionally
  useEffect(() => {
    const waveTimer = setInterval(() => {
      setCharacterAnim(prev => (prev === 'running' ? 'waving' : 'running'));
    }, 4500);
    return () => clearInterval(waveTimer);
  }, []);

  // Real progress calculation: strictly from actual student score out of 50
  // Student position along track (5% to 88% width so character is safely inside canvas)
  const maxScore = 50;
  const progressRatio = Math.min(1, Math.max(0, totalEduScore / maxScore));
  const characterLeftPercent = 5 + progressRatio * 80;

  // Environment configurations
  const environments: Record<EnvironmentType, EnvironmentConfig> = {
    daytime: {
      id: 'daytime',
      name: 'مضمار النهار الرياضي',
      badge: '☀️ نهار رياضي',
      skyBackground: 'linear-gradient(180deg, #60a5fa 0%, #bae6fd 65%, #e0f2fe 100%)',
      trackColor: '#c2410c',
      laneColor: 'rgba(255,255,255,0.7)',
      landscapeElements: (
        <>
          {/* Sun */}
          <circle cx="580" cy="35" r="24" fill="#facc15" opacity="0.9" filter="drop-shadow(0 0 12px #fde047)" />
          {/* Clouds */}
          <path d="M60 30 Q75 18 95 24 Q115 15 135 28 Q150 25 155 35 Q120 40 60 30 Z" fill="#ffffff" opacity="0.85" />
          <path d="M320 22 Q335 12 355 18 Q375 10 395 22 Q410 20 415 28 Q380 34 320 22 Z" fill="#ffffff" opacity="0.8" />
          {/* Green Rolling Hills */}
          <path d="M0 80 Q140 45 300 70 T640 65 L640 120 L0 120 Z" fill="#22c55e" opacity="0.75" />
          <path d="M0 90 Q180 65 380 90 T640 85 L640 120 L0 120 Z" fill="#15803d" />
          {/* Colorful Bunting Flags */}
          <path d="M20 18 Q320 38 620 18" stroke="#cbd5e1" strokeWidth="1" fill="none" />
          {[40, 100, 160, 220, 280, 340, 400, 460, 520, 580].map((x, i) => (
            <polygon
              key={i}
              points={`${x},${20 + Math.sin(i) * 3} ${x + 16},${20 + Math.sin(i) * 3} ${x + 8},${34 + Math.sin(i) * 3}`}
              fill={['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6'][i % 5]}
            />
          ))}
        </>
      )
    },
    nighttime: {
      id: 'nighttime',
      name: 'مضمار الليل والأضواء الكاشفة',
      badge: '🌙 ليل وأضواء كاشفة',
      skyBackground: 'linear-gradient(180deg, #090d16 0%, #0f172a 60%, #1e1b4b 100%)',
      trackColor: '#1e293b',
      laneColor: 'rgba(56, 189, 248, 0.75)',
      landscapeElements: (
        <>
          {/* Crescent Moon */}
          <path d="M570 20 A 18 18 0 1 0 590 45 A 14 14 0 1 1 570 20 Z" fill="#fef08a" filter="drop-shadow(0 0 10px #fef9c3)" />
          {/* Twinkling Stars */}
          {[[40, 20], [110, 15], [190, 28], [250, 14], [310, 25], [390, 18], [470, 26], [520, 12]].map(([sx, sy], idx) => (
            <circle key={idx} cx={sx} cy={sy} r={idx % 2 === 0 ? 1.5 : 2.2} fill="#ffffff" opacity={0.75 + (idx % 3) * 0.1} />
          ))}
          {/* Stadium Floodlight Towers */}
          <g>
            {/* Left Tower */}
            <line x1="80" y1="35" x2="80" y2="95" stroke="#94a3b8" strokeWidth="3" />
            <polygon points="70,30 90,30 85,38 75,38" fill="#f8fafc" />
            <polygon points="65,35 95,35 220,130 0,130" fill="url(#floodlightBeam)" opacity="0.18" />
            {/* Right Tower */}
            <line x1="560" y1="35" x2="560" y2="95" stroke="#94a3b8" strokeWidth="3" />
            <polygon points="550,30 570,30 565,38 555,38" fill="#f8fafc" />
            <polygon points="545,35 575,35 640,130 420,130" fill="url(#floodlightBeam)" opacity="0.18" />
          </g>
        </>
      )
    },
    celebration: {
      id: 'celebration',
      name: 'مضمار الاحتفال والتتويج',
      badge: '🎉 احتفال وإنجاز',
      skyBackground: 'linear-gradient(180deg, #311042 0%, #4c1d95 50%, #6b21a8 100%)',
      trackColor: '#701a75',
      laneColor: 'rgba(250, 204, 21, 0.85)',
      landscapeElements: (
        <>
          {/* Fireworks bursts */}
          <g>
            <circle cx="120" cy="30" r="14" fill="none" stroke="#f43f5e" strokeWidth="2" strokeDasharray="3 3" />
            <circle cx="280" cy="22" r="18" fill="none" stroke="#facc15" strokeWidth="2" strokeDasharray="4 4" />
            <circle cx="480" cy="28" r="16" fill="none" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 3" />
          </g>
          {/* Festive Ribbon Banners */}
          <path d="M10 20 Q320 40 630 20" stroke="#facc15" strokeWidth="1.5" strokeDasharray="6 4" fill="none" />
          {/* Floating Celebration Stars */}
          {[60, 160, 240, 360, 440, 540, 600].map((fx, fi) => (
            <text key={fi} x={fx} y={22 + (fi % 3) * 6} fontSize="12" fill={['#fde047', '#f43f5e', '#a78bfa', '#4ade80'][fi % 4]}>
              ✨
            </text>
          ))}
        </>
      )
    },
    national_day: {
      id: 'national_day',
      name: 'مضمار اليوم الوطني السعودي ٩٤',
      badge: '🇸🇦 اليوم الوطني',
      skyBackground: 'linear-gradient(180deg, #022c16 0%, #064e28 55%, #006c35 100%)',
      trackColor: '#044222',
      laneColor: 'rgba(255, 255, 255, 0.85)',
      landscapeElements: (
        <>
          {/* Green & White Decorative Lighting */}
          <g>
            <text x="320" y="32" textAnchor="middle" fill="#ffffff" fontSize="13" fontWeight="900" letterSpacing="1">
              🇸🇦 نحلم ونحقق — اليوم الوطني السعودي 🇸🇦
            </text>
            <path d="M20 38 Q320 52 620 38" stroke="#4ade80" strokeWidth="1.5" fill="none" />
          </g>
          {/* Green Laser Spotlights */}
          <polygon points="120,40 130,40 260,130 80,130" fill="#22c55e" opacity="0.12" />
          <polygon points="520,40 530,40 580,130 400,130" fill="#22c55e" opacity="0.12" />
          {/* Saudi Palm & Swords Motif */}
          <text x="180" y="26" fontSize="16">🌴</text>
          <text x="460" y="26" fontSize="16">🌴</text>
        </>
      )
    },
    founding_day: {
      id: 'founding_day',
      name: 'مضمار يوم التأسيس والتراث',
      badge: '🏛️ يوم التأسيس',
      skyBackground: 'linear-gradient(180deg, #451a03 0%, #78350f 50%, #92400e 100%)',
      trackColor: '#713f12',
      laneColor: 'rgba(254, 240, 138, 0.8)',
      landscapeElements: (
        <>
          {/* Heritage Title */}
          <text x="320" y="28" textAnchor="middle" fill="#fef08a" fontSize="13" fontWeight="900">
            🏛️ يوم بدينا — ثلاثة قرون من العز والفخر 🏛️
          </text>
          {/* Najdi Heritage Triangular Merlons (شرفات الطين النجدية) */}
          <g fill="#a16207" opacity="0.9">
            {Array.from({ length: 22 }).map((_, i) => (
              <polygon key={i} points={`${i * 30},75 ${i * 30 + 15},56 ${i * 30 + 30},75`} />
            ))}
          </g>
          {/* Warm Desert Silhouette */}
          <path d="M0 75 Q160 50 320 65 T640 60 L640 120 L0 120 Z" fill="#854d0e" opacity="0.8" />
        </>
      )
    }
  };

  const activeEnvConfig = environments[currentEnv] || environments.daytime;

  return (
    <div className="race-track-wrapper">
      {/* Top Header of the Race Track */}
      <div className="race-track-header">
        <div className="track-title-group">
          <div className="track-main-title">
            <span>🏇 مضمار سباق الفرسان — رحلة التفوق</span>
            <span className="track-env-badge">{activeEnvConfig.badge}</span>
          </div>
          <div className="track-score-info">
            المستوى التعليمي: <b>{totalEduScore}</b> من 50 نقطة ({Math.round(progressRatio * 100)}% من المضمار)
          </div>
        </div>

        {/* Action Controls: Change Outfit & Environment Selector */}
        <div className="track-controls-group">
          <button
            type="button"
            className="outfit-customizer-btn"
            onClick={onOpenOutfitModal}
            title="تخصيص وارتداء الأزياء التراثية السعودية"
          >
            🎽 الأزياء التراثية ({SAUDI_OUTFITS[currentOutfit]?.name.split(' ')[0]})
          </button>

          {/* Quick Manual Environment Chips */}
          <div className="env-selector-chips">
            {(Object.keys(environments) as EnvironmentType[]).map(envKey => (
              <button
                key={envKey}
                type="button"
                className={`env-chip-btn ${currentEnv === envKey ? 'active' : ''}`}
                onClick={() => setCurrentEnv(envKey)}
              >
                {environments[envKey].badge.split(' ')[0]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Track Viewport Canvas/SVG */}
      <div className="race-track-viewport">
        <svg
          viewBox="0 0 640 190"
          className="race-track-svg"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="floodlightBeam" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="trackGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={activeEnvConfig.trackColor} stopOpacity="0.85" />
              <stop offset="100%" stopColor={activeEnvConfig.trackColor} stopOpacity="1" />
            </linearGradient>
          </defs>

          {/* Dynamic Sky Background */}
          <rect x="0" y="0" width="640" height="110" fill="url(#skyFill)" />
          <foreignObject x="0" y="0" width="640" height="110">
            <div style={{ width: '100%', height: '100%', background: activeEnvConfig.skyBackground }} />
          </foreignObject>

          {/* Environment-Specific Landscape Elements */}
          {activeEnvConfig.landscapeElements}

          {/* Running Track Surface */}
          <rect x="0" y="110" width="640" height="80" fill="url(#trackGrad)" />

          {/* Track Lanes */}
          <line x1="0" y1="134" x2="640" y2="134" stroke={activeEnvConfig.laneColor} strokeWidth="1.5" strokeDasharray="14 10" />
          <line x1="0" y1="158" x2="640" y2="158" stroke={activeEnvConfig.laneColor} strokeWidth="1.5" strokeDasharray="14 10" />
          <line x1="0" y1="182" x2="640" y2="182" stroke={activeEnvConfig.laneColor} strokeWidth="2" />

          {/* Distance & Educational Milestone Markers */}
          {/* Start Line */}
          <g>
            <rect x="24" y="110" width="6" height="80" fill="#ffffff" />
            <text x="27" y="105" textAnchor="middle" fill="#64748b" fontSize="9.5" fontWeight="700">
              البداية 🏁
            </text>
          </g>

          {/* Milestone 1: 10 pts (الوحدة 1) */}
          <g>
            <line x1="145" y1="110" x2="145" y2="190" stroke="rgba(255,255,255,0.4)" strokeWidth="1.5" strokeDasharray="4 4" />
            <circle cx="145" cy="110" r="7" fill={totalEduScore >= 10 ? '#16a34a' : '#64748b'} />
            <text x="145" y="104" textAnchor="middle" fill={totalEduScore >= 10 ? '#15803d' : '#64748b'} fontSize="9.5" fontWeight="800">
              10ن (القيم)
            </text>
          </g>

          {/* Milestone 2: 20 pts (الوحدة 2) */}
          <g>
            <line x1="285" y1="110" x2="285" y2="190" stroke="rgba(255,255,255,0.4)" strokeWidth="1.5" strokeDasharray="4 4" />
            <circle cx="285" cy="110" r="7" fill={totalEduScore >= 20 ? '#16a34a' : '#64748b'} />
            <text x="285" y="104" textAnchor="middle" fill={totalEduScore >= 20 ? '#15803d' : '#64748b'} fontSize="9.5" fontWeight="800">
              20ن (الأعلام)
            </text>
          </g>

          {/* Milestone 3: 30 pts (الوحدة 3) */}
          <g>
            <line x1="425" y1="110" x2="425" y2="190" stroke="rgba(255,255,255,0.4)" strokeWidth="1.5" strokeDasharray="4 4" />
            <circle cx="425" cy="110" r="7" fill={totalEduScore >= 30 ? '#16a34a' : '#64748b'} />
            <text x="425" y="104" textAnchor="middle" fill={totalEduScore >= 30 ? '#15803d' : '#64748b'} fontSize="9.5" fontWeight="800">
              30ن (الوطن)
            </text>
          </g>

          {/* Finish Line (50 pts / Grand Final) */}
          <g>
            {/* Checkered Finish Line */}
            {Array.from({ length: 10 }).map((_, i) => (
              <rect
                key={i}
                x="575"
                y={110 + i * 8}
                width="8"
                height="8"
                fill={i % 2 === 0 ? '#000000' : '#ffffff'}
              />
            ))}
            <text x="579" y="104" textAnchor="middle" fill="#eab308" fontSize="10.5" fontWeight="900">
              🏆 النهاية (50)
            </text>
          </g>
        </svg>

        {/* Real Student Racer Character Positioned along the Track */}
        <div
          className="racer-character-container"
          style={{
            position: 'absolute',
            bottom: '12px',
            left: `${characterLeftPercent}%`,
            transform: 'translateX(-50%)',
            transition: 'left 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)',
            zIndex: 10
          }}
        >
          <SaudiCharacter
            outfitId={currentOutfit}
            animState={characterAnim}
            size={76}
            name={studentName || 'فارس لغتي'}
          />
        </div>
      </div>

      {/* Track Footnote with Educational Progress Context */}
      <div className="track-footer-status">
        <span>💡 يتقدم فارسك في المضمار تلقائياً بناءً على نقاطك التعليمية الحقيقية في المنصة.</span>
        <span className="current-outfit-badge">
          الزي المرتدى: <b>{SAUDI_OUTFITS[currentOutfit]?.name}</b> ({SAUDI_OUTFITS[currentOutfit]?.region})
        </span>
      </div>
    </div>
  );
};
