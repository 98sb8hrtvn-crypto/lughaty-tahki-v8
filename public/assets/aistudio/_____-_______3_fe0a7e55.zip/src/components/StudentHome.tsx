import React, { useState } from 'react';
import { AnnouncementTicker } from './AnnouncementTicker';
import { RaceTrack } from './RaceTrack';
import { OutfitId } from './SaudiCharacter';
import {
  DailyChallengeModal,
  NafesModal,
  ErrorClinicModal,
  GamesHubModal
} from './ActivitiesModals';
import { OutfitSelectorModal } from './OutfitSelectorModal';

interface StudentHomeProps {
  studentName: string;
  onUpdateStudentName: (name: string) => void;
  totalEduScore: number;
  stageLocks: boolean[];
  onOpenStage: (stageIdx: number) => void;
  onOpenShootout: () => void;
  onOpenTeacherAuth: () => void;
  onOpenLeaderboard: () => void;
  isTeacherAuthenticated: boolean;
  onRewardPoint: (points: number) => void;
}

export const StudentHome: React.FC<StudentHomeProps> = ({
  studentName,
  onUpdateStudentName,
  totalEduScore,
  stageLocks,
  onOpenStage,
  onOpenShootout,
  onOpenTeacherAuth,
  onOpenLeaderboard,
  isTeacherAuthenticated,
  onRewardPoint
}) => {
  // Modal states for Homepage features
  const [showDailyChallenge, setShowDailyChallenge] = useState(false);
  const [showNafesModal, setShowNafesModal] = useState(false);
  const [showErrorClinic, setShowErrorClinic] = useState(false);
  const [showGamesHub, setShowGamesHub] = useState(false);
  const [showOutfitModal, setShowOutfitModal] = useState(false);

  // Equipped outfit state (persisted in localStorage)
  const [currentOutfit, setCurrentOutfit] = useState<OutfitId>(() => {
    try {
      const saved = localStorage.getItem('pk_current_outfit');
      if (saved) return saved as OutfitId;
    } catch {
      // ignore
    }
    return 'default_saudi';
  });

  const handleSelectOutfit = (id: OutfitId) => {
    setCurrentOutfit(id);
    try {
      localStorage.setItem('pk_current_outfit', id);
    } catch {
      // ignore
    }
  };

  return (
    <div className="student-home-container" dir="rtl">
      {/* 1. TOP HEADER & IDENTITY BAR */}
      <header className="home-top-header">
        <div className="brand-logo-group">
          <div className="brand-icon-emblem">📖</div>
          <div className="brand-titles">
            <h1 className="brand-title">لغتي تحكي</h1>
            <p className="brand-subtitle">الصف الأول المتوسط · الفصل الدراسي الأول</p>
          </div>
        </div>

        {/* Student Profile & Quick Actions */}
        <div className="header-student-profile">
          <div className="student-badge-pill">
            <span className="student-avatar-mini">🇸🇦</span>
            <input
              type="text"
              value={studentName}
              placeholder="اسم البطل..."
              onChange={e => onUpdateStudentName(e.target.value)}
              className="student-name-input"
              maxLength={22}
              title="انقر لتعديل اسمك"
            />
            <span className="student-score-tag">
              ⭐ <b>{totalEduScore}</b>/50 ن
            </span>
          </div>

          <div className="header-actions-group">
            <button
              type="button"
              className="header-btn leaderboard-btn"
              onClick={onOpenLeaderboard}
            >
              🏅 الأبطال
            </button>
            <button
              type="button"
              className={`header-btn teacher-btn ${isTeacherAuthenticated ? 'active' : ''}`}
              onClick={onOpenTeacherAuth}
            >
              👨‍🏫 {isTeacherAuthenticated ? 'لوحة المعلم (مفعّلة)' : 'دخول المعلم'}
            </button>
          </div>
        </div>
      </header>

      {/* 2. ANNOUNCEMENT TICKER (Slow, Prioritizes Teacher, Strictly no forbidden phrases) */}
      <AnnouncementTicker />

      {/* MAIN HOMEPAGE SECTIONS (3 HORIZONTAL ROWS) */}
      <main className="home-sections-layout">
        {/* ========================================================
            ROW 1: MAIN ACTIVITIES (الأنشطة الرئيسية)
            Two large, visually attractive icons side by side:
            1. Daily Challenge (تحدي اليوم)
            2. Penalty Shootout (ركلات الترجيح)
           ======================================================== */}
        <section className="activities-row-main" aria-label="الأنشطة الرئيسية">
          {/* Card 1: Daily Challenge */}
          <div
            className="main-activity-card card-challenge"
            onClick={() => setShowDailyChallenge(true)}
            role="button"
            tabIndex={0}
          >
            <div className="activity-card-icon-wrap gold-glow">
              <span className="activity-card-icon">⚡</span>
            </div>
            <div className="activity-card-content">
              <div className="activity-tag challenge-tag">تحدٍّ يومي متجدد</div>
              <h2 className="activity-title">تحدي اليوم</h2>
              <p className="activity-desc">
                3 أسئلة سريعة يومية لاختبار معلوماتك وكسب نقاط التحدي الإضافية لتقدم فارسك.
              </p>
              <div className="activity-card-footer">
                <span className="activity-btn-action">ابدأ التحدي ◀</span>
              </div>
            </div>
          </div>

          {/* Card 2: Penalty Shootout (Uses existing student identity) */}
          <div
            className="main-activity-card card-shootout"
            onClick={onOpenShootout}
            role="button"
            tabIndex={0}
          >
            <div className="activity-card-icon-wrap emerald-glow">
              <span className="activity-card-icon">⚽</span>
            </div>
            <div className="activity-card-content">
              <div className="activity-tag football-tag">البطولة الخماسية الرسمية</div>
              <h2 className="activity-title">ركلات الترجيح</h2>
              <p className="activity-desc">
                التحدي الكروي التفاعلي مع التعليق الصوتي وأجواء البث التلفزيوني الحماسي.
              </p>
              <div className="activity-card-footer">
                <span className="activity-btn-action football-act">ادخل الملعب ⚽</span>
              </div>
            </div>
          </div>
        </section>

        {/* ========================================================
            ROW 2: EDUCATIONAL UNITS (الوحدات التعليمية)
            Title: “الوحدات التعليمية”
            Three cards side by side (ordered right to left):
            1. Islamic Values (القيم الإسلامية)
            2. Figures (الأعلام)
            3. Homeland (الوطن)
           ======================================================== */}
        <section className="units-section-wrapper" aria-label="الوحدات التعليمية">
          <div className="section-title-bar">
            <div className="section-title-right">
              <span className="section-title-icon">📚</span>
              <h2 className="section-heading">الوحدات التعليمية</h2>
            </div>
            <span className="section-subtitle-badge">مقرر لغتي الخالدة المعتمد</span>
          </div>

          <div className="units-grid-three">
            {/* Unit 1: Islamic Values (القيم الإسلامية) */}
            <div
              className={`unit-card-item ${stageLocks[0] ? 'unlocked' : 'locked'}`}
              onClick={() => {
                if (stageLocks[0]) onOpenStage(0);
              }}
              role="button"
              tabIndex={0}
            >
              <div className="unit-card-top">
                <span className="unit-card-badge">الوحدة الأولى</span>
                {stageLocks[0] ? (
                  <span className="unit-status-open">🔓 مفتوحة</span>
                ) : (
                  <span className="unit-status-locked">🔒 مغلقة بقرار المعلم</span>
                )}
              </div>
              <div className="unit-card-symbol">📖</div>
              <h3 className="unit-card-title">القيم الإسلامية</h3>
              <p className="unit-card-desc">
                دروس الصنف اللغوي: المذكر والمؤنث، أسلوب الأمر، والأسماء الموصولة.
              </p>
              <div className="unit-card-footer">
                {stageLocks[0] ? (
                  <span className="unit-action-text open">دخول الوحدة ◀</span>
                ) : (
                  <span className="unit-action-text locked">بانتظار إتاحة المعلم</span>
                )}
              </div>
            </div>

            {/* Unit 2: Figures (الأعلام) */}
            <div
              className={`unit-card-item ${stageLocks[1] ? 'unlocked' : 'locked'}`}
              onClick={() => {
                if (stageLocks[1]) onOpenStage(1);
              }}
              role="button"
              tabIndex={0}
            >
              <div className="unit-card-top">
                <span className="unit-card-badge">الوحدة الثانية</span>
                {stageLocks[1] ? (
                  <span className="unit-status-open">🔓 مفتوحة</span>
                ) : (
                  <span className="unit-status-locked">🔒 مغلقة بقرار المعلم</span>
                )}
              </div>
              <div className="unit-card-symbol">🌟</div>
              <h3 className="unit-card-title">الأعلام</h3>
              <p className="unit-card-desc">
                المفرد والمثنى والجمع، الضمائر المتصلة والمنفصلة، وتراجم أعلام التاريخ.
              </p>
              <div className="unit-card-footer">
                {stageLocks[1] ? (
                  <span className="unit-action-text open">دخول الوحدة ◀</span>
                ) : (
                  <span className="unit-action-text locked">بانتظار إتاحة المعلم</span>
                )}
              </div>
            </div>

            {/* Unit 3: Homeland (الوطن) */}
            <div
              className={`unit-card-item ${stageLocks[2] ? 'unlocked' : 'locked'}`}
              onClick={() => {
                if (stageLocks[2]) onOpenStage(2);
              }}
              role="button"
              tabIndex={0}
            >
              <div className="unit-card-top">
                <span className="unit-card-badge">الوحدة الثالثة</span>
                {stageLocks[2] ? (
                  <span className="unit-status-open">🔓 مفتوحة</span>
                ) : (
                  <span className="unit-status-locked">🔒 مغلقة بقرار المعلم</span>
                )}
              </div>
              <div className="unit-card-symbol">🇸🇦</div>
              <h3 className="unit-card-title">الوطن</h3>
              <p className="unit-card-desc">
                النكرة والمعرفة، أسماء الإشارة، حب الوطن والاعتزاز براية التوحيد.
              </p>
              <div className="unit-card-footer">
                {stageLocks[2] ? (
                  <span className="unit-action-text open">دخول الوحدة ◀</span>
                ) : (
                  <span className="unit-action-text locked">بانتظار إتاحة المعلم</span>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* ========================================================
            ROW 3: ADDITIONAL LEARNING ACTIVITIES
            Three cards side by side (ordered right to left):
            1. Nafes Test (اختبار نافس)
            2. Games (الألعاب)
            3. Error Clinic (عيادة الأخطاء)
           ======================================================== */}
        <section className="extra-activities-section" aria-label="الأنشطة الإثرائية">
          <div className="section-title-bar">
            <div className="section-title-right">
              <span className="section-title-icon">🎯</span>
              <h2 className="section-heading">الأنشطة الإثرائية والمهارية</h2>
            </div>
            <span className="section-subtitle-badge">تطوير مستمر للمهارات</span>
          </div>

          <div className="extra-grid-three">
            {/* 1. Nafes Test (اختبار نافس) */}
            <div
              className="extra-activity-card card-nafes"
              onClick={() => setShowNafesModal(true)}
              role="button"
              tabIndex={0}
            >
              <div className="extra-card-icon-wrap nafes-glow">
                <span className="extra-icon">📝</span>
              </div>
              <div className="extra-card-content">
                <h3 className="extra-title">اختبار نافس</h3>
                <p className="extra-desc">
                  محاكي الاختبارات الوطنية المعيارية لقياس نواتج التعلم وتراكيب اللغة.
                </p>
                <span className="extra-action-link">بدء الاختبار التجريبي ◀</span>
              </div>
            </div>

            {/* 2. Games (الألعاب) */}
            <div
              className="extra-activity-card card-games"
              onClick={() => setShowGamesHub(true)}
              role="button"
              tabIndex={0}
            >
              <div className="extra-card-icon-wrap games-glow">
                <span className="extra-icon">🎮</span>
              </div>
              <div className="extra-card-content">
                <h3 className="extra-title">الألعاب</h3>
                <p className="extra-desc">
                  مركز الألعاب اللغوية التنافسية لتعلم القواعد بأسلوب تفاعلي ممتع.
                </p>
                <span className="extra-action-link">دخول مركز الألعاب ◀</span>
              </div>
            </div>

            {/* 3. Error Clinic (عيادة الأخطاء) */}
            <div
              className="extra-activity-card card-clinic"
              onClick={() => setShowErrorClinic(true)}
              role="button"
              tabIndex={0}
            >
              <div className="extra-card-icon-wrap clinic-glow">
                <span className="extra-icon">🩺</span>
              </div>
              <div className="extra-card-content">
                <h3 className="extra-title">عيادة الأخطاء</h3>
                <p className="extra-desc">
                  مراجعة الفروق النحوية والإملائية الدقيقة لترسيخ الفهم بلا درجات سلبية.
                </p>
                <span className="extra-action-link">زيارة العيادة اللغوية ◀</span>
              </div>
            </div>
          </div>
        </section>

        {/* ========================================================
            BOTTOM SECTION: STUDENT RACE TRACK EVOLUTION
            The race track with rotating environments, milestones,
            and the authentic male Saudi student character.
           ======================================================== */}
        <section className="race-track-section" aria-label="مضمار السباق التعليمي">
          <RaceTrack
            studentName={studentName}
            totalEduScore={totalEduScore}
            currentOutfit={currentOutfit}
            onSelectOutfit={handleSelectOutfit}
            onOpenOutfitModal={() => setShowOutfitModal(true)}
          />
        </section>
      </main>

      {/* POPUP MODALS FOR ACTIVITIES */}
      {showDailyChallenge && (
        <DailyChallengeModal
          onClose={() => setShowDailyChallenge(false)}
          onRewardPoint={pts => onRewardPoint(pts)}
        />
      )}

      {showNafesModal && (
        <NafesModal onClose={() => setShowNafesModal(false)} />
      )}

      {showErrorClinic && (
        <ErrorClinicModal onClose={() => setShowErrorClinic(false)} />
      )}

      {showGamesHub && (
        <GamesHubModal
          onLaunchShootout={onOpenShootout}
          onClose={() => setShowGamesHub(false)}
        />
      )}

      {showOutfitModal && (
        <OutfitSelectorModal
          currentOutfit={currentOutfit}
          totalEduScore={totalEduScore}
          onSelectOutfit={handleSelectOutfit}
          onClose={() => setShowOutfitModal(false)}
        />
      )}
    </div>
  );
};
