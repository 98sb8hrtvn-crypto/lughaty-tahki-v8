import React, { useState } from 'react';
import questionBank from '../data/question_bank.json';
import { QuestionItem } from '../App';

const trainingQuestions = questionBank.training_questions as QuestionItem[];

// ==========================================
// 1. DAILY CHALLENGE MODAL (تحدي اليوم)
// ==========================================
interface DailyChallengeModalProps {
  onClose: () => void;
  onRewardPoint: (points: number) => void;
}

export const DailyChallengeModal: React.FC<DailyChallengeModalProps> = ({
  onClose,
  onRewardPoint
}) => {
  // Take 3 diverse questions
  const [dailyQs] = useState<QuestionItem[]>(() => {
    const q1 = trainingQuestions.find(q => q.unit.includes('الأولى')) || trainingQuestions[0];
    const q2 = trainingQuestions.find(q => q.unit.includes('الثانية')) || trainingQuestions[5];
    const q3 = trainingQuestions.find(q => q.unit.includes('الثالثة')) || trainingQuestions[10];
    return [q1, q2, q3];
  });

  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const currentQ = dailyQs[currentIdx];

  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);
    if (idx === currentQ.answer) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = () => {
    if (currentIdx < dailyQs.length - 1) {
      setCurrentIdx(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setIsFinished(true);
      if (score > 0) {
        onRewardPoint(score);
      }
    }
  };

  return (
    <div className="ov" style={{ display: 'flex', zIndex: 70 }}>
      <div className="card" style={{ maxWidth: '500px', width: 'min(94vw, 500px)', textAlign: 'right', direction: 'rtl' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--bd)', paddingBottom: '10px' }}>
          <div>
            <h2 style={{ margin: '0 0 2px', fontSize: '18px' }}>⚡ تحدي اليوم التعليمي</h2>
            <div style={{ fontSize: '12px', color: '#6b7280' }}>
              3 أسئلة سريعة يومية لتعزيز الفهم والتقدم في مضمار السباق
            </div>
          </div>
          <button type="button" className="sm" onClick={onClose} style={{ margin: 0 }}>
            ✕ إغلاق
          </button>
        </div>

        {!isFinished ? (
          <div style={{ marginTop: '12px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12.5px', color: '#4b5563', marginBottom: '8px' }}>
              <span>السؤال {currentIdx + 1} من {dailyQs.length}</span>
              <span>الدرجة الحالية: <b>{score}</b></span>
            </div>

            <div style={{ background: 'var(--bg)', padding: '12px', borderRadius: '10px', fontWeight: 700, fontSize: '14.5px', marginBottom: '12px', color: '#1f2937' }}>
              {currentQ.question}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {currentQ.options.map((opt, idx) => {
                let btnBg = '#ffffff';
                let btnBorder = '1px solid var(--bd)';
                let btnColor = '#1f2937';

                if (isAnswered) {
                  if (idx === currentQ.answer) {
                    btnBg = 'rgba(34, 197, 94, 0.15)';
                    btnBorder = '2px solid #16a34a';
                    btnColor = '#15803d';
                  } else if (idx === selectedOption) {
                    btnBg = 'rgba(239, 68, 68, 0.15)';
                    btnBorder = '2px solid #dc2626';
                    btnColor = '#b91c1c';
                  }
                }

                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectOption(idx)}
                    disabled={isAnswered}
                    style={{
                      padding: '10px 14px',
                      borderRadius: '8px',
                      background: btnBg,
                      border: btnBorder,
                      color: btnColor,
                      fontSize: '13.5px',
                      fontWeight: 600,
                      textAlign: 'right',
                      cursor: isAnswered ? 'default' : 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>

            {isAnswered && (
              <div style={{ marginTop: '12px', background: 'rgba(0,0,0,0.03)', padding: '10px', borderRadius: '8px', fontSize: '12.5px', color: '#374151' }}>
                <b>💡 التفسير:</b> {currentQ.explanation}
              </div>
            )}

            {isAnswered && (
              <button
                type="button"
                onClick={handleNext}
                style={{
                  width: '100%',
                  marginTop: '14px',
                  padding: '10px',
                  background: '#16a34a',
                  color: '#ffffff',
                  fontWeight: 700,
                  fontSize: '14px',
                  borderRadius: '8px',
                  border: 'none',
                  cursor: 'pointer'
                }}
              >
                {currentIdx < dailyQs.length - 1 ? 'السؤال التالي ◀' : 'عرض النتيجة والتكريم 🏆'}
              </button>
            )}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '16px 8px' }}>
            <div style={{ fontSize: '42px', marginBottom: '8px' }}>🎉</div>
            <h3 style={{ margin: '0 0 6px', fontSize: '18px', color: '#15803d' }}>
              أحسنت يا بطل! أتممت تحدي اليوم بنجاح
            </h3>
            <p style={{ fontSize: '14px', color: '#4b5563', margin: '4px 0 14px' }}>
              أجبت عن <b>{score}</b> من 3 أسئلة بصورة صحيحة وتمت إضافة النقاط لرصيدك في المضمار!
            </p>
            <button
              type="button"
              onClick={onClose}
              style={{
                padding: '10px 24px',
                background: '#16a34a',
                color: '#ffffff',
                fontWeight: 700,
                fontSize: '14px',
                borderRadius: '8px',
                border: 'none',
                cursor: 'pointer'
              }}
            >
              متابعة الرحلة التعليمية
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// ==========================================
// 2. NAFES TEST MODAL (اختبار نافس)
// ==========================================
interface NafesModalProps {
  onClose: () => void;
}

export const NafesModal: React.FC<NafesModalProps> = ({ onClose }) => {
  const [nafesQuestions] = useState<QuestionItem[]>(() => {
    return trainingQuestions.slice(0, 10);
  });
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [isFinished, setIsFinished] = useState(false);

  const handleSelect = (qIdx: number, optIdx: number) => {
    setSelectedAnswers(prev => ({ ...prev, [qIdx]: optIdx }));
  };

  const calculateScore = () => {
    let s = 0;
    nafesQuestions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.answer) s++;
    });
    return s;
  };

  return (
    <div className="ov" style={{ display: 'flex', zIndex: 70 }}>
      <div className="card" style={{ maxWidth: '580px', width: 'min(94vw, 580px)', textAlign: 'right', direction: 'rtl', maxHeight: '88vh', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--bd)', paddingBottom: '10px' }}>
          <div>
            <h2 style={{ margin: '0 0 2px', fontSize: '18px' }}>📝 محاكي الاختبارات الوطنية (نافس)</h2>
            <div style={{ fontSize: '12px', color: '#6b7280' }}>
              تدريب معياري على أسئلة القراءة والفهم القرائي والتراكيب اللغوية
            </div>
          </div>
          <button type="button" className="sm" onClick={onClose} style={{ margin: 0 }}>
            ✕ إغلاق
          </button>
        </div>

        {!isFinished ? (
          <div style={{ flex: 1, overflowY: 'auto', padding: '10px 4px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12.5px', color: '#4b5563', marginBottom: '10px' }}>
              <span>السؤال {currentIdx + 1} من {nafesQuestions.length}</span>
              <span style={{ color: '#2563eb', fontWeight: 700 }}>
                {nafesQuestions[currentIdx].lesson}
              </span>
            </div>

            <div style={{ background: 'var(--bg)', padding: '14px', borderRadius: '10px', fontWeight: 700, fontSize: '14.5px', marginBottom: '14px', color: '#1f2937', lineHeight: '1.5' }}>
              {nafesQuestions[currentIdx].question}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {nafesQuestions[currentIdx].options.map((opt, oIdx) => {
                const isSelected = selectedAnswers[currentIdx] === oIdx;
                return (
                  <button
                    key={oIdx}
                    type="button"
                    onClick={() => handleSelect(currentIdx, oIdx)}
                    style={{
                      padding: '10px 14px',
                      borderRadius: '8px',
                      background: isSelected ? 'rgba(37, 99, 235, 0.12)' : '#ffffff',
                      border: isSelected ? '2px solid #2563eb' : '1px solid var(--bd)',
                      color: isSelected ? '#1d4ed8' : '#1f2937',
                      fontSize: '13.5px',
                      fontWeight: 600,
                      textAlign: 'right',
                      cursor: 'pointer'
                    }}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>

            <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
              {currentIdx > 0 && (
                <button
                  type="button"
                  onClick={() => setCurrentIdx(prev => prev - 1)}
                  style={{ flex: 1, padding: '10px', background: '#e2e8f0', color: '#334151', borderRadius: '8px', border: 'none', fontWeight: 700 }}
                >
                  السابق
                </button>
              )}
              {currentIdx < nafesQuestions.length - 1 ? (
                <button
                  type="button"
                  onClick={() => setCurrentIdx(prev => prev + 1)}
                  style={{ flex: 1, padding: '10px', background: '#2563eb', color: '#ffffff', borderRadius: '8px', border: 'none', fontWeight: 700 }}
                >
                  التالي
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsFinished(true)}
                  style={{ flex: 1, padding: '10px', background: '#16a34a', color: '#ffffff', borderRadius: '8px', border: 'none', fontWeight: 700 }}
                >
                  إنهاء الاختبار وتحليل النتيجة
                </button>
              )}
            </div>
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '18px 8px' }}>
            <div style={{ fontSize: '42px', marginBottom: '8px' }}>📊</div>
            <h3 style={{ margin: '0 0 6px', fontSize: '18px', color: '#1d4ed8' }}>
              نتيجة تقييم مقياس نافس الوطني
            </h3>
            <div style={{ fontSize: '26px', fontWeight: 900, color: '#16a34a', margin: '8px 0' }}>
              {calculateScore()} / 10
            </div>
            <p style={{ fontSize: '13.5px', color: '#4b5563', margin: '4px 0 16px' }}>
              {calculateScore() >= 8
                ? 'مستوى متقدم ومتميز جداً! تمتلك مهارات لغوية متينة تتوافق مع معايير الاختبارات الوطنية.'
                : calculateScore() >= 5
                ? 'مستوى جيد ومتقن! يمكنك تدعيم مهاراتك بمراجعة الوحدات التعليمية وعيادة الأخطاء.'
                : 'أمامك فرصة كبيرة للتحسن! عُد لمراجعة دروس المذكر والمؤنث وهمزة الوصل لرفع درجتك.'}
            </p>
            <button
              type="button"
              onClick={onClose}
              style={{ padding: '10px 24px', background: '#2563eb', color: '#ffffff', fontWeight: 700, borderRadius: '8px', border: 'none', cursor: 'pointer' }}
            >
              العودة للرئيسية
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// ==========================================
// 3. ERROR CLINIC MODAL (عيادة الأخطاء)
// ==========================================
interface ErrorClinicModalProps {
  onClose: () => void;
}

export const ErrorClinicModal: React.FC<ErrorClinicModalProps> = ({ onClose }) => {
  // Frequently misunderstood questions from unit 1 and 2
  const clinicCases = [
    {
      title: 'الفرق بين المذكر الحقيقي والمذكر المجازي',
      rule: 'المذكر الحقيقي: ما دل على ذكر من إنسان أو حيوان ويتكاثر (مثل: رجل، جمل، أسد). أما المذكر المجازي: ما يعامل معاملة الذكر لفظاً ولكنه جماد أو نبات (مثل: قلم، باب، بدر، ليل).',
      example: 'كلمة «قلم» تعامل كمذكر مجازي لأننا نقول «هذا قلم جميل» وليس له أنثى من جنسه.'
    },
    {
      title: 'الفرق بين المؤنث اللفظي والمؤنث المعنوي',
      rule: 'المؤنث اللفظي: اسم لمذكر لحقته علامة تأنيث كالتاء المربوطة (مثل: حمزة، طلحة، أسامة). أما المؤنث المعنوي: ما دل على مؤنث وليس فيه علامة تأنيث (مثل: مريم، هند، شمس، عين).',
      example: '«حمزة» مذكر في معناه لكنه مؤنث لفظاً بسبب التاء المربوطة في آخره.'
    },
    {
      title: 'التمييز بين همزة الوصل وهمزة القطع',
      rule: 'ضع حرف الواو أو الفاء قبل الكلمة: إذا نطقت الهمزة فهي همزة قطع (وأحمد، فأقبل). وإذا سقطت في النطق ووصلت الحرف بما بعده فهي همزة وصل (وانطلق، فاستمع).',
      example: '«انطلق» -> «وانطلق» (سقطت الهمزة لفظاً، فهي همزة وصل بلا رأس عين).'
    }
  ];

  return (
    <div className="ov" style={{ display: 'flex', zIndex: 70 }}>
      <div className="card" style={{ maxWidth: '580px', width: 'min(94vw, 580px)', textAlign: 'right', direction: 'rtl', maxHeight: '88vh', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--bd)', paddingBottom: '10px' }}>
          <div>
            <h2 style={{ margin: '0 0 2px', fontSize: '18px' }}>🩺 عيادة الأخطاء اللغوية</h2>
            <div style={{ fontSize: '12px', color: '#6b7280' }}>
              علاج وتصحيح المفاهيم النحوية والإملائية الشائعة لترسيخ الفهم بلا درجات سلبية
            </div>
          </div>
          <button type="button" className="sm" onClick={onClose} style={{ margin: 0 }}>
            ✕ إغلاق
          </button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '10px 4px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {clinicCases.map((item, idx) => (
            <div key={idx} style={{ background: 'var(--bg)', border: '1px solid var(--bd)', borderRadius: '10px', padding: '12px' }}>
              <div style={{ fontSize: '14px', fontWeight: 800, color: '#1e40af', marginBottom: '6px' }}>
                💡 {item.title}
              </div>
              <div style={{ fontSize: '13px', color: '#374151', lineHeight: '1.5', marginBottom: '6px' }}>
                <b>القاعدة النحوية:</b> {item.rule}
              </div>
              <div style={{ fontSize: '12px', background: 'rgba(34, 197, 94, 0.1)', color: '#166534', padding: '6px 10px', borderRadius: '6px', fontWeight: 600 }}>
                🔍 <b>تطبيق توضيحي:</b> {item.example}
              </div>
            </div>
          ))}
        </div>

        <div style={{ borderTop: '1px solid var(--bd)', paddingTop: '10px', textAlign: 'center' }}>
          <button
            type="button"
            onClick={onClose}
            style={{ width: '100%', maxWidth: '240px', padding: '8px 16px', background: '#334151', color: '#ffffff', borderRadius: '8px', border: 'none', cursor: 'pointer', fontWeight: 700 }}
          >
            إغلاق العيادة والعودة
          </button>
        </div>
      </div>
    </div>
  );
};

// ==========================================
// 4. GAMES HUB MODAL (الألعاب)
// ==========================================
interface GamesHubModalProps {
  onLaunchShootout: () => void;
  onClose: () => void;
}

export const GamesHubModal: React.FC<GamesHubModalProps> = ({
  onLaunchShootout,
  onClose
}) => {
  return (
    <div className="ov" style={{ display: 'flex', zIndex: 70 }}>
      <div className="card" style={{ maxWidth: '540px', width: 'min(94vw, 540px)', textAlign: 'right', direction: 'rtl' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--bd)', paddingBottom: '10px' }}>
          <div>
            <h2 style={{ margin: '0 0 2px', fontSize: '18px' }}>🎮 مركز الألعاب التعليمية</h2>
            <div style={{ fontSize: '12px', color: '#6b7280' }}>
              المنافسة الكروية الحصرية لتعزيز مهارات لغتي الخالدة
            </div>
          </div>
          <button type="button" className="sm" onClick={onClose} style={{ margin: 0 }}>
            ✕ إغلاق
          </button>
        </div>

        <div style={{ margin: '16px 0' }}>
          {/* Penalty Shootout - The ONLY Exclusive Game */}
          <div style={{
            background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.12), rgba(16, 185, 129, 0.05))',
            border: '2px solid #16a34a',
            borderRadius: '16px',
            padding: '16px',
            boxShadow: '0 4px 14px rgba(22, 163, 74, 0.12)'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '10px' }}>
              <div style={{
                width: '52px',
                height: '52px',
                borderRadius: '14px',
                background: '#16a34a',
                color: '#ffffff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '28px',
                boxShadow: '0 4px 10px rgba(22, 163, 74, 0.3)'
              }}>
                ⚽
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                  <h3 style={{ margin: 0, fontWeight: 800, fontSize: '16.5px', color: '#15803d' }}>
                    ركلات الترجيح الكروية (البطولة الحصرية)
                  </h3>
                  <span style={{ fontSize: '11px', background: '#dcfce7', color: '#166534', padding: '2px 8px', borderRadius: '6px', fontWeight: 700 }}>
                    🏆 اللعبة الرسمية
                  </span>
                </div>
                <div style={{ fontSize: '12px', color: '#4b5563', marginTop: '3px' }}>
                  البطولة الخماسية الرسمية · نظام الـ 5 مراحل التعليمية والتنافس التلفزيوني
                </div>
              </div>
            </div>

            <div style={{ fontSize: '12.5px', color: '#374151', lineHeight: '1.6', margin: '10px 0 14px', background: 'rgba(255,255,255,0.7)', padding: '10px 12px', borderRadius: '10px', border: '1px solid rgba(22, 163, 74, 0.2)' }}>
              <div style={{ fontWeight: 700, color: '#166534', marginBottom: '6px' }}>
                🌟 مراحل البطولة الخمس للمنافسة والتأهل:
              </div>
              <ul style={{ margin: 0, paddingRight: '18px', listStyleType: 'disc', fontSize: '12px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                <li><b>المرحلة الأولى:</b> ربع النهائي · القيم الإسلامية (القميص الأصفر والشورت الأزرق)</li>
                <li><b>المرحلة الثانية:</b> نصف النهائي · الأعلام (القميص الأزرق والشورت الأبيض)</li>
                <li><b>المرحلة الثالثة:</b> النهائي المصغر · الوطن (الأصفر المقلم والشورت الأسود)</li>
                <li><b>المرحلة الرابعة:</b> الملحق التأهيلي · التحدي النحوي (الأخضر والأبيض)</li>
                <li><b>المرحلة الخامسة:</b> النهائي الكبير · درة الملاعب وكأس التفوق (طقم صقور الوطن 🇸🇦)</li>
              </ul>
            </div>

            <button
              type="button"
              onClick={() => {
                onClose();
                onLaunchShootout();
              }}
              style={{
                width: '100%',
                padding: '12px 18px',
                background: 'linear-gradient(135deg, #16a34a, #15803d)',
                color: '#ffffff',
                borderRadius: '10px',
                border: 'none',
                fontWeight: 800,
                fontSize: '14px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                boxShadow: '0 4px 12px rgba(22, 163, 74, 0.35)',
                transition: 'all 0.15s ease'
              }}
            >
              <span>⚽ ابدأ ركلات الترجيح واختر مرحلتك</span>
              <span style={{ fontSize: '16px' }}>◀</span>
            </button>
          </div>
        </div>

        <div style={{ borderTop: '1px solid var(--bd)', paddingTop: '10px', textAlign: 'center' }}>
          <button
            type="button"
            onClick={onClose}
            style={{ padding: '8px 24px', background: '#334151', color: '#ffffff', borderRadius: '8px', border: 'none', cursor: 'pointer', fontWeight: 700 }}
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
