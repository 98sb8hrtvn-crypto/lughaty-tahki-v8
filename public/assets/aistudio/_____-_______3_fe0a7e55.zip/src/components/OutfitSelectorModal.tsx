import React from 'react';
import { OutfitId, SAUDI_OUTFITS, SaudiCharacter } from './SaudiCharacter';

interface OutfitSelectorModalProps {
  currentOutfit: OutfitId;
  totalEduScore: number;
  onSelectOutfit: (outfitId: OutfitId) => void;
  onClose: () => void;
}

export const OutfitSelectorModal: React.FC<OutfitSelectorModalProps> = ({
  currentOutfit,
  totalEduScore,
  onSelectOutfit,
  onClose
}) => {
  // Determine unlock status based strictly on genuine educational achievements
  const checkIsUnlocked = (id: OutfitId): boolean => {
    switch (id) {
      case 'default_saudi':
        return true; // Always unlocked as national default
      case 'najdi':
        return totalEduScore >= 10;
      case 'hijazi':
        return totalEduScore >= 15;
      case 'southern':
        return totalEduScore >= 20;
      case 'northern':
        return totalEduScore >= 5; // Unlocked by completing daily challenge or 5 points
      case 'eastern':
        return totalEduScore >= 30;
      case 'sports_national':
        return totalEduScore >= 8; // Unlocked by scoring goals in shootout or 8 points
      default:
        return false;
    }
  };

  const outfitList = Object.values(SAUDI_OUTFITS);

  return (
    <div className="ov" style={{ display: 'flex', zIndex: 70 }}>
      <div
        className="card"
        style={{
          maxWidth: '560px',
          width: 'min(94vw, 560px)',
          maxHeight: '90vh',
          display: 'flex',
          flexDirection: 'column',
          textAlign: 'right',
          direction: 'rtl'
        }}
      >
        {/* Modal Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--bd)', paddingBottom: '10px' }}>
          <div>
            <h2 style={{ margin: '0 0 4px', fontSize: '18px' }}>🎽 أزياء مناطق المملكة التراثية</h2>
            <div style={{ fontSize: '12px', color: '#6b7280' }}>
              اختر وارتدِ زي منطقتك المفضلة لفارسك في مضمار السباق
            </div>
          </div>
          <button
            type="button"
            className="sm"
            onClick={onClose}
            style={{ margin: 0, padding: '4px 10px', background: '#64748b' }}
          >
            ✕ إغلاق
          </button>
        </div>

        {/* Free & Educational Notice */}
        <div style={{ background: 'rgba(34, 197, 94, 0.1)', border: '1px solid rgba(34, 197, 94, 0.25)', borderRadius: '8px', padding: '8px 12px', margin: '10px 0 6px', fontSize: '12px', color: '#166534', lineHeight: '1.4' }}>
          💡 <b>مكافآت التفوق:</b> تُفتح جميع الأزياء التراثية تلقائياً بتحصيلك للنقاط وإنجازك للدروس، دون أي خصم للنقاط أو رسوم إضافية.
        </div>

        {/* Outfits Grid */}
        <div style={{ flex: 1, overflowY: 'auto', paddingRight: '4px', margin: '8px 0', display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {outfitList.map(outfit => {
            const unlocked = checkIsUnlocked(outfit.id);
            const isEquipped = currentOutfit === outfit.id;

            return (
              <div
                key={outfit.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  background: isEquipped ? 'rgba(34, 197, 94, 0.12)' : 'var(--bg)',
                  border: isEquipped
                    ? '2px solid #16a34a'
                    : unlocked
                    ? '1px solid var(--bd)'
                    : '1px dashed #cbd5e1',
                  borderRadius: '12px',
                  padding: '10px 12px',
                  opacity: unlocked ? 1 : 0.72,
                  transition: 'all 0.2s ease'
                }}
              >
                {/* Character Preview Thumbnail */}
                <div style={{ width: '56px', display: 'flex', justifyContent: 'center' }}>
                  <SaudiCharacter
                    outfitId={outfit.id}
                    size={46}
                    animState={isEquipped ? 'celebrating' : 'standing'}
                  />
                </div>

                {/* Outfit Info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
                    <span style={{ fontWeight: 800, fontSize: '14px', color: '#1f2937' }}>
                      {outfit.name}
                    </span>
                    <span
                      style={{
                        fontSize: '11px',
                        background: 'rgba(0,0,0,0.06)',
                        padding: '1px 6px',
                        borderRadius: '4px',
                        color: '#4b5563',
                        fontWeight: 600
                      }}
                    >
                      {outfit.region}
                    </span>
                  </div>

                  <p style={{ fontSize: '12px', color: '#4b5563', margin: '3px 0 4px', lineHeight: '1.3' }}>
                    {outfit.description}
                  </p>

                  <div style={{ fontSize: '11.5px', color: unlocked ? '#15803d' : '#b45309', fontWeight: 600 }}>
                    {unlocked ? (
                      <span>🔓 متاح ومفتوح للإرتداء</span>
                    ) : (
                      <span>🔒 شرط الفتح: {outfit.unlockRequirement} (نقاطك الحالية: {totalEduScore})</span>
                    )}
                  </div>
                </div>

                {/* Equip / Locked Button */}
                <div>
                  {isEquipped ? (
                    <span
                      style={{
                        display: 'inline-block',
                        background: '#16a34a',
                        color: '#ffffff',
                        padding: '6px 14px',
                        borderRadius: '8px',
                        fontSize: '12px',
                        fontWeight: 700
                      }}
                    >
                      ✓ مفعّل
                    </span>
                  ) : unlocked ? (
                    <button
                      type="button"
                      onClick={() => onSelectOutfit(outfit.id)}
                      style={{
                        padding: '6px 14px',
                        fontSize: '12.5px',
                        fontWeight: 700,
                        background: '#2563eb',
                        color: '#ffffff',
                        borderRadius: '8px',
                        border: 'none',
                        cursor: 'pointer'
                      }}
                    >
                      ارتداء الزي
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled
                      style={{
                        padding: '6px 12px',
                        fontSize: '12px',
                        fontWeight: 600,
                        background: '#94a3b8',
                        color: '#ffffff',
                        borderRadius: '8px',
                        border: 'none',
                        cursor: 'not-allowed'
                      }}
                    >
                      🔒 مغلق
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer */}
        <div style={{ borderTop: '1px solid var(--bd)', paddingTop: '10px', textAlign: 'center' }}>
          <button
            type="button"
            onClick={onClose}
            style={{ width: '100%', maxWidth: '240px', padding: '8px 16px', background: '#334155', color: '#ffffff', borderRadius: '8px', border: 'none', cursor: 'pointer', fontWeight: 700 }}
          >
            تأكيد والعودة للمضمار
          </button>
        </div>
      </div>
    </div>
  );
};
